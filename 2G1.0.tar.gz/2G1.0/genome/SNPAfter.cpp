#ifndef __SNPAfter_cpp__
#define __SNPAfter_cpp__

//#include <string.h>
//#include <cstdio>




//using namespace UTILS;


namespace BIOS {




/* _____________________________________________________*/

SNPPos GetTotalSNPs(char* filesample)
{
SNPPos totalSNPs;
char filePos[256], fileRSPos[256];
ChangeExtension(filesample, filePos, "pou");
ChangeExtension(filesample, fileRSPos, "rs");
stringList*sourcePositions;
if (!existFile(filePos) && !existFile(fileRSPos))
throw BadFormat("SNPAfter::GetTotalSNPs");

if (existFile(filePos))
{
sourcePositions=new stringList(filePos);
totalSNPs=sourcePositions->size();
zap(sourcePositions);
return totalSNPs;
}
sourcePositions=new stringList(fileRSPos);
totalSNPs=sourcePositions->size();
zap(sourcePositions);
return totalSNPs;
}

} // end namespace

#endif

/* End of file: SNPAfter.h */
