/* File: CoupleGenotype.h */


#ifndef __CoupleSNPGenotype_cpp__
#define __CoupleSNPGenotype_cpp__

//#include <string.h>
//#include <cstdio>

//#include "../commonc++/vector.h"

//#include "PairGenotype.h"

namespace BIOS {


/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/


///////////////////
//// public ////////
///////////////////



/*____________________________________________________________ */


CoupleSNPGenotype::CoupleSNPGenotype (CoupleSNPGenotype * Source): PairSNPGenotype(Source->getMotherGenotype(), Source->getFatherGenotype())
{
	motherGenotype =Source->getMotherGenotype();
	fatherGenotype =Source->getFatherGenotype();
}
/*____________________________________________________________ */

CoupleSNPGenotype::CoupleSNPGenotype (Diplotype  Source1, Diplotype Source2): PairSNPGenotype(Source1, Source2)
{
	motherGenotype =Source1;
	fatherGenotype =Source2;
}

/*____________________________________________________________ */

Diplotype CoupleSNPGenotype::getFatherGenotype ()
{
return fatherGenotype;
}

/*____________________________________________________________ */

Diplotype CoupleSNPGenotype::getMotherGenotype ()
{
return motherGenotype;
}


};  // End of Namespace

#endif

/* End of file: Genotype.h */




