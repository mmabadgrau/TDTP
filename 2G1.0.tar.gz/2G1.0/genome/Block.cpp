/* File: Block.cpp */


#ifndef __Block_cpp__
#define __Block_cpp__



namespace BIOS {




ostream& operator<<(ostream& out, Block& p)
  {
out <<p.IniPos << "-" << p.LastPos<<"\n";
    return out;
  }
}// end namespace

#endif

/* End of file: block.h */
