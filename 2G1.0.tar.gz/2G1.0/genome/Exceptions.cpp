
#ifndef __Excep__
#define __Excep__



using namespace std;




MultiAllelic ma; 

Inconsistent in;

IncorrectAlgorithm ia;




OverflowedSNP ov;






#endif
