/* File: PotentialList.cpp */


#ifndef __PotentialList_cpp__
#define __PotentialList_cpp__

using namespace std;

namespace BIOS
{

PotentialList::~PotentialList(){};
/*
PotentialList::PotentialList(const char* filename, const char* tokens, char outputSeparator, bool delimiter):Container<vector, PotentialTable*>()
  {
throw NonImplemented("PotentialList(const char* filename, const char* tokens, char outputSeparator, bool delimiter)");
 }
*/
};  // Fin del Namespace
//

#endif
