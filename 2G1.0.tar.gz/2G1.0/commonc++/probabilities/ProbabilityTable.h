/* File: ProbabilityTable.h */


#ifndef __ProbabilityTable_h__
#define __ProbabilityTable_h__




using namespace std;


namespace BIOS
{





/*_______________________________________________________________*/

typedef VarsTable<Prob> ProbabilityTable;

   /*______________________________________________________*/

}
  
#endif
