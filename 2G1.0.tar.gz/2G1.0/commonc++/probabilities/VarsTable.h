/* File: VarsTable.h */


#ifndef __VarsTable_h__
#define __VarsTable_h__


//#include "../MLSample.h"

using namespace std;


namespace BIOS
{
class CPT;
 
  template <class T> class VarsTable: public MultidimensionalTable<T> //
  {//
    
  public:
  
  int totalSample; 
  intList *varList;
   
 
  //  ostream& operator<<(ostream& out);
//    virtual string print();
   // virtual void normalize();
    VarsTable();
    VarsTable(VarsTable &source);
    VarsTable(MultidimensionalTable<T> &source);
    template <class U> VarsTable(VarsTable<U>& source);
     VarsTable(intSample*  sample, intList *varList, intList* dimensionList, ListOfAttributes* listOfAttributes);//, intSample::NodePointer first=NULL, intSample::NodePointer last=NULL);
 VarsTable(intSample*  sample, intList *varList, intList* dimensionList, ListOfAttributes* listOfAttributes, floatList* alphaNumerators, float alphaDenominator);//, intSample::NodePointer first=NULL, intSample::NodePointer last=NULL);
 //   VarsTable(floatMLSample*  sample, intList *varList, intList* dimensionList, floatList* alphaNumerators, float alphaDenominator);//, floatSample::NodePointer first=NULL, floatSample::NodePointer last=NULL);
     void set(intSample*  sample, intList *varList, intList* dimensionList, ListOfAttributes* listOfAttributes);//, intSample::NodePointer first=NULL, intSample::NodePointer last=NULL);

  //  void set(intSample*  sample, intList *varList, intList* dimensionList);//, intSample::NodePointer first=NULL, intSample::NodePointer last=NULL);

 void set(intSample*  sample, intList *varList, intList* dimensionList, ListOfAttributes* listOfAttributes, floatList* alphaNumerators, float alphaDenominator);//, intSample::NodePointer first=NULL, intSample::NodePointer last=NULL);


int getTotalSample();
    void set(intList *varList, int totalSample);
    void set(VarsTable *source);
    void set();
    void set(intList* varList, intList* dimensionList); 
 //   CPT* makeConditional(intList *conditionalVarList);
    Prob getConditionalProbability(int* values, int conditionalSize, bool udefined=false);

    void initialize(T value);
  void initialize(double value1, double value2);
 
   // VarsTable(MultidimensionalTable<T> &source);
    VarsTable(intList *varList, intList* dimensionList);
    ~VarsTable();
  //  virtual void setTotalCounts();
    VarsTable* marginalize(intList* sourceVarList);
    VarsTable* operator*(VarsTable* source);
    VarsTable* operator*(T source);
     VarsTable* product(VarsTable* source, bool product);
    VarsTable* operator/(VarsTable* source);
   // virtual Prob getProbability(int* values);
   // virtual Prob getProbability(int* values, bool plain=true);
 // Prob getProbability(int pos, bool plain=true);
    //void addValue(int pos, double numerator, double denominator);
    void setValue(int pos, double numerator, double denominator);
    void setValue(int pos, T);
    virtual void setProductValue(int pos, T numerator, T denominator, bool product);
    void setTotalSample(int totalSample);
    void empty();
    VarsTable<double>* operator*(CPT* source);
    VarsTable<double>* convertToPotential();
   bool operator<(VarsTable<double>& source){cout <<"VarTable::operator< Not implemented yet"; end();};
  bool operator>(VarsTable<double>& source){"VarTable::operator> Not implemented yet"; end();};
  intList* addMissingVarList(intList* vars, intList* inputPattern, ListOfAttributes* listOfAttributes);
 VarsTable* getConditional(intList* conditionalVars);
 static VarsTable* fromString(string s);
int GetSize()
{
//cout <<"no sense";
return 0;
}

  };
  
  typedef VarsTable<double> PotentialTable;

}
#endif
