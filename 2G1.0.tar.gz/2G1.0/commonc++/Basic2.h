
#ifndef __Basic2_h__
#define __Basic2_h__


using namespace std;

namespace BIOS
{


  //void print(char* filename);

  //R/template <class T, template <class T> class Cont> 
   template <class Cont, class T> 
  bool empty(Container<Cont, T>* lista);


  //  stringList*  getList (char * genotypebuf, char* tokensSource);

  stringVector*  getStringVector (char * genotypebuf, const char* tokensSource, int len);

  //R/template <class T, template <class T> class Cont> 
  template <class Cont, class T> 
  Container<Cont,T>*  getContainer (char * genotypebuf, char* tokensSource);

  // intList* getNumbers (char* input);
  //  template <class T> Container<T, list>* createList(T* array, int length);

}
// end namespace

//#include "basic.cpp"
#endif


