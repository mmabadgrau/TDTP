/* File: HeteroPair.h */


#ifndef __HeteroPair_cpp__
#define __HeteroPair_cpp__



using namespace std;

namespace BIOS {


           template < class P, class Q> HeteroPair<P,Q>::HeteroPair(P f, Q s) {First=f; Second=s;};
           template < class P, class Q> HeteroPair<P,Q>::HeteroPair(HeteroPair<P, Q>* p) {First=p->First; Second=p->Second;};
           template < class P, class Q> HeteroPair<P,Q>::HeteroPair() {};
           template < class P, class Q> HeteroPair<P,Q>::~HeteroPair() {};
											template < class P, class Q> void 	HeteroPair<P,Q>::empty() {zap (First); zap(Second);};
	   template < class P, class Q> bool HeteroPair<P,Q>::operator>(const HeteroPair<P, Q>& p) {if (First>p.First || First==p.First && Second>p.Second) return true; else return false;};
	   template < class P, class Q> bool HeteroPair<P,Q>::operator<(const HeteroPair<P, Q>&p) {if (First<p.First|| First==p.First && Second<p.Second) return true; else return false;};
	   template < class P, class Q> bool HeteroPair<P,Q>::operator==(HeteroPair<P, Q>p) {if (First==p.First && Second==p.Second) return true; else return false;};
           template < class P, class Q> void HeteroPair<P,Q>::setValues(P f, Q s) {First=f; Second=s;};
	   template < class P, class Q> P HeteroPair<P,Q>::getFirst(){return First;};
	   template < class P, class Q> Q HeteroPair<P,Q>::getSecond(){return Second;};

/*______________________________________________________*/

 template <class T, class U> HeteroPair<T, U>* HeteroPair<T, U>::fromString(string s)
{
throw NonImplemented("static HeteroPair* fromString(string s)");
}
/*______________________________________________________*/

template<class T, class U> ostream& operator<<(ostream& out, HeteroPair<T, U>*& HeteroPair)
{
 
out << "(" << *HeteroPair.First <<", " << *HeteroPair.Second <<")";

return out;
  }

/*______________________________________________________*/

template<class T, class U> ostream& operator<<(ostream& out, HeteroPair<T, U>& HeteroPair)
{
 
out << "(" << HeteroPair.First <<", " << HeteroPair.Second <<")";

return out;
  }



}//end namespace
#endif
