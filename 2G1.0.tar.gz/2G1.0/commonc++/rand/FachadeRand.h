#ifndef __FachadeRand_h__ 
#define __FachadeRand_h__ 

#include "Uniform.h"
#include "Binomial.h"
//#include "Binomial.cpp"
#include "Multinomial.h"
//#include "Multinomial.cpp"
#include "gamma.h"
#include "chiSquare.h"
#include "weightedChiSquare.h"
#include "poisson.h"
//#include "poisson.c"
#include "ranbinom.h"
//#include "Uniform.cpp"
//#include "ranbinom.c"
#include "rng.h"
//#include "rng.c"
#include "gammln.h"
//#include "gammln.c"
#include "expdev.h"
//#include "expdev.c"
#endif
