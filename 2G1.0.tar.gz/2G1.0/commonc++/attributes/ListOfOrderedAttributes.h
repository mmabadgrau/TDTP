/* File: ListOfOrderedAttributes.h */


#ifndef __ListOfOrderedAttributes_h__
#define __ListOfOrderedAttributes_h__




//using namespace UTILS;


namespace BIOS
{



  /************************/
  /* ListOfOrderedAttributes DEFINITION */
  /************************/


  /**
          @memo ListOfOrderedAttributes 
   
  	@doc
   
      @author Maria Mar Abad Grau
  	@version 1.0
  */

// template <class T, template <class T> class Cont> class ListOfOrderedAttributes: public Set<Attribute, ListOfOrderedAttributes>

//template <class T, template <class T> class Cont> class Sample: public ListOfPointers<Container<T, Cont> >

//template <Attribute, ListOfPointers> class ListOfOrderedAttributes
// template <class T> class vector
//template <class T, template <class T> class Cont> class ListOfOrderedAttributes
//template <> Container<Attribute, ListOfPointers> class ListOfOrderedAttributes

//template<class T, template<class T> class Cont> class ListOfOrderedAttributes<Attribute, ListOfPointers>

  class ListOfOrderedAttributes: public ListOfAttributes
  {


  
  public:

floatList* positionsVector;

Attribute* Pop();


    ListOfOrderedAttributes(char* texto, bool verbosity, int metadata=1);
    ListOfOrderedAttributes(ListOfOrderedAttributes & vectorOfOrderedAttributes, bool verbosity=false);
    ListOfOrderedAttributes(ListOfAttributes & vectorOfAttributes, bool verbosity=false);

    ListOfOrderedAttributes();
    ~ListOfOrderedAttributes();
ListOfOrderedAttributes* clone();
ListOfOrderedAttributes* select();
float getAlphaDenominator(BayesType bayesType, float alpha, intList *varList, intList *conditionalVarList);

 float getDistance(int att, int att2);
   void readPositions(char* filename);
string getName();

  ListOfOrderedAttributes* GetDiscreteListOfAttributes();
  void GetDiscreteListOfAttributes(ListOfOrderedAttributes* vectorOfDiscreteOrderedAttributes);

ListOfOrderedAttributes* copyAttributesWithPositionsIn(intList* columns, bool isThis);


    float getWeight(int att, int att2);
    float getBasicDistance(int att, int att2);
    float getMaxBasicDistance(int att);
    Pair<int> getExtremes(int att, float maxDistance);
template <class T> float getDistance(Container<vector<T>, T> * pattern1, Container<vector<T>, T> * pattern2, bool noclass, DistanceMethodClass distanceMethodClass, int classPosition){cout <<"ListOfOrderedAttributes::getDistance not implemented yet";end();};
 

     };  // End of class ListOfOrderedAttributes

/*______________________________________________________*/
/*
    ostream& operator<<(ostream& out, Set<Attribute, ListOfPointers>& vectora)
  {
   Set<Attribute, ListOfPointers>::iterator p=vectora.getFirst();
   out <<"\n";
 while (p!=NULL)
    {
         out << *vectora.getElement(p);
         p=vectora.getNext(p); 
        out <<"\n";
    }
   
    return out;
  }
*/
}
;  // Fin del Namespace

#endif
//#include "ListOfOrderedAttributes.cpp"

/* Fin Fichero: ListOfOrderedAttributes.h */
