#ifndef TextFile_h//
#define TextFile_h//





/**
 *
 * @author mabad
 */

namespace BIOS {

class TextFile  {
    
    char fileName[256];
    int totalLines;
bool input;
    public:
		
		~TextFile(){if (input) InputFile.close(); else OutputFile.close();};
		TextFile(char fileName[256], bool input=true, int filePos=0);
		void OpenOutput();
void print();
bool eof();
int getTotalLines();
stringVector* readLine(const char* tokensSource="\t ,\n\r"); 
};

ostream& operator<<(ostream& out, TextFile& l)
{
throw NonImplemented("ostream& operator<<(ostream& out, TextFile& l)");
}; 
    
} // end namespace
#endif
