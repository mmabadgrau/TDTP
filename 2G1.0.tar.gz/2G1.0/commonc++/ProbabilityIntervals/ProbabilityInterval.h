/* File: ProbabilityInterval.h */


#ifndef __ProbabilityInterval_h__
#define __ProbabilityInterval_h__



using namespace std;

namespace BIOS {



 class ProbabilityInterval: public Pair<Prob>
  {
public:
           ProbabilityInterval(Prob f, Prob s);
           ProbabilityInterval(ProbabilityInterval* p);
 	   void setValues(Prob f, Prob s);
  };
/*
template <> ProbabilityInterval* Container<vector, ProbabilityInterval*>::readElement ( ifstream * source, char* tokens )
{
cout << "ProbabilityInterval* Container<vector, ProbabilityInterval*>::readElement not implemented  yet";
end();
};
*/
}//end namespace


#endif
