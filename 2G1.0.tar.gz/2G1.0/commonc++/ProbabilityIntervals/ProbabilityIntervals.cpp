#ifndef ProbabilityIntervals_h//
#define ProbabilityIntervals_h//



namespace BIOS 
{






/*______________________________________________________*/

Prob ProbabilityIntervals::min(Prob a, Prob b, Prob c)
{
if (a<=b && a<=c) return a;
else if (b<=a && b<=c) return b;
else return c;
}

/*______________________________________________________*/

Prob ProbabilityIntervals::min(Prob a, Prob b)
{
if (a<=b) return a;
else return b;
}
/*______________________________________________________*/

double ProbabilityIntervals::sumLower(Container<vector, ProbabilityInterval*>* maxEntropyDistribution)
{
double result=0;
Container<vector, ProbabilityInterval*>::iterator p=maxEntropyDistribution->getFirst();
while(p!=maxEntropyDistribution->end())
{
result=result+maxEntropyDistribution->getElement(p)->getFirst().convert();
p=maxEntropyDistribution->getNext(p);
}
return result;
}
/*______________________________________________________*/

int ProbabilityIntervals::minLower(Container<vector, ProbabilityInterval*>* maxEntropyDistribution, intList* positions)
{
double min=1;
int pos=0;
for (int i=0;i<maxEntropyDistribution->size();i++)
if (positions->getElement(i)!=-1)
if (maxEntropyDistribution->getElement(i)->getFirst().convert()<=min)
{
pos=i;
min=maxEntropyDistribution->getElement(i)->getFirst().convert();
}
return pos;
}
/*______________________________________________________*/

int ProbabilityIntervals::secondMinLower(Container<vector, ProbabilityInterval*>* maxEntropyDistribution, int pos, intList* positions)
{
double min=1;
int pos2=-1;
for (int i=0;i<maxEntropyDistribution->size();i++)
if (positions->getElement(i)!=-1)
if (i!=pos)
if (maxEntropyDistribution->getElement(i)->getFirst().convert()<=min)
{
pos2=i;
min=maxEntropyDistribution->getElement(i)->getFirst().convert();
}
return pos2;
}
/*______________________________________________________*/

int ProbabilityIntervals::totalMin(Container<vector, ProbabilityInterval*>* maxEntropyDistribution, intList* positions)
{
int pos=minLower(maxEntropyDistribution, positions);
int total=0;
for (int i=0;i<maxEntropyDistribution->size();i++)
if (positions->getElement(i)!=-1)
if (maxEntropyDistribution->getElement(i)->getFirst().convert()==maxEntropyDistribution->getElement(pos)->getFirst().convert())
total++;
return total;
}
/*______________________________________________________*/
Container<vector, ProbabilityInterval*>* ProbabilityIntervals::getMaxEntropy()
{
Container<vector, ProbabilityInterval*>* maxEntropyDistribution=new Container<vector, ProbabilityInterval*>(*this), *resultDistribution=NULL;
intList* positions=new intList(this->size());
getMaxEntropy(maxEntropyDistribution, resultDistribution, positions);
zap(maxEntropyDistribution);
zap(positions);
return  resultDistribution;
}
/*______________________________________________________*/

void ProbabilityIntervals::getMaxEntropy(Container<vector, ProbabilityInterval*>* maxEntropyDistribution, Container<vector, ProbabilityInterval*> *resultDistribution, intList* positions)
{
Prob li, ui, lf, lr, li2;
//intList* positions=new intList(this->GetSize());
zap(resultDistribution);
resultDistribution=new Container<vector, ProbabilityInterval*>(*maxEntropyDistribution);
double sum=sumLower(maxEntropyDistribution);
if (sum<1)
{
 for (int i=0; i<maxEntropyDistribution->size(); i++)
  if (maxEntropyDistribution->getElement(i)->getFirst().convert()==maxEntropyDistribution->getElement(i)->getSecond().convert()) positions->changeElementAtPos(-1, i);

//ProbabilityInterval pi;
int mini=minLower(maxEntropyDistribution, positions), mini2=secondMinLower(maxEntropyDistribution, mini, positions),
totalM=totalMin(maxEntropyDistribution, positions);
lf=maxEntropyDistribution->getElement(mini2)->getFirst();
lr=maxEntropyDistribution->getElement(mini)->getFirst();
for (int i=0; i<maxEntropyDistribution->size();i++)
{
 li=maxEntropyDistribution->getElement(i)->getFirst();
 ui=maxEntropyDistribution->getElement(i)->getSecond();
if (i==mini)
{
 if (mini2==-1) 
 li2=min(ui-li, Prob(1-sum, totalM));
 else if (lf==lr) li2=min(ui-li,Prob(1-sum,totalM)); else li2=min(ui-li,lf-lr,Prob(1-sum,totalM));
 ProbabilityInterval* pi=new ProbabilityInterval(Prob(li+li2), ui);
 maxEntropyDistribution->removeNode(i); 
 maxEntropyDistribution->insertElementAtPos(pi,i); 
}
}
//cout << *maxEntropyDistribution;
getMaxEntropy(maxEntropyDistribution, resultDistribution, positions);
}
}
/*
ProbabilityInterval* readElement ( ifstream * source, char* tokens )
{
cout << "ProbabilityInterval* readElement not implemented  yet";
end();
};
*/
/*______________________________________________________*/
/*
template<class T> ostream& operator<<(ostream& out, BayesScore<T>& lista)
{
 
//out << *lista.sample;

return out;
  }
*/
} // end namespace

#endif
