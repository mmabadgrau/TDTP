#ifndef MeasureCompetition_h//
#define MeasureCompetition_h//



namespace BIOS 
{


//////

template <template <class T> class M, class U> class MeasureCompetition

{ 
	
protected:

BayesType bayesType;
float alpha;

   
public:

Container<vector<Pair<intList*>*>, Pair<intList*>* >* listOfParticipants; 

Container<vector<HeteroPair<float, int> >, HeteroPair<float, int> >*results;

MeasureCompetition(Container<vector<Pair<intList*>*>, Pair<intList*>* >* listOfParticipants, BayesType bayesType=MLE, float alpha=0);

void makeRound(struct VectorSample<U>::Class* sample, ListOfAttributes* listOfAttributes);

HeteroPair<float, int> getWinner();

};//

/*______________________________________________________*/

template <template <class T> class M, class U>
 ostream& operator<<(ostream& out, MeasureCompetition<M, U>& lista);

  
} // end namespace
#endif
