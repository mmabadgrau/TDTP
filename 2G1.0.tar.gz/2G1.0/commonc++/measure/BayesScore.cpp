#ifndef BayesScore_cpp//
#define BayesScore_cpp//



namespace BIOS 
{

/*______________________________________________________*/

template<class T> BayesScore<T>::BayesScore(BayesType bayesType, float alpha): DependenceMeasure<T>(bayesType, alpha)
{


//if (alpha==0) this->alpha=1;
//if (bayesType==MLE) this->bayesType=UBalpha;
}


/*______________________________________________________*/

template<class T> bool BayesScore<T>::better(double m1, double m2)
{
return m1>m2;
}


/*______________________________________________________*/

template <class T> double BayesScore<T>::getMeasure(CPT *s1, CPT* s2) throw (BadSize)
{
cout <<"BayesScore<T>::getMeasure not defined yet";
end();
}
/*______________________________________________________*/

template<> double BayesScore<int>::getMeasure(CPT *pt, CPT* priors) throw (BadSize)
{
//This implementation should be used only to compute y->x versus x\indep y, with y being a set of attributes and x only 1 attribute
//So we only compute Bayes score for node x in the network
// If y=NULL, we compute score for x\indep y
//if not, we compute score for y->x
// it is used in log scale

//cout <<*pt;
//if (priors!=NULL)
//cout <<*priors;
try
{
Prob freq, prior;
ProbabilityTable* s1=pt->getProbabilityTable(), *marginals=pt->getMarginals(), *conditionals=pt->getConditionals();
if (conditionals!=NULL)
if (marginals->getDimension()!=conditionals->getDimension()-1) throw BadSize("BayesScore::getMeasure()");

//if (conditionals!=NULL)
// cout << " " << *conditionals->varList <<"\n";
//  cout << " " << *marginals->varList <<"\n";
int pTotalMods=1, xTotalMods=s1->dimensionList->getElement(0);
if (conditionals!=NULL) pTotalMods=marginals->getSize(); // totalParentConfigurations
double num=0, den=0;
int* pos=NULL;//, *pos2=NLL;
//cout <<*pt;
//cout << *priors;
for (int j=0;j<pTotalMods;j++)// for each parent configuration
 {
  pos=s1->getPositions(j);
  freq=pt->getValue(pos);
  prior=priors->getValue(pos);
    
if (freq.getDenominator()!=0)
{
num=num+lgamma(prior.getDenominator());
//cout <<"\nnum: " << lgamma(prior.getDenominator()) <<"\n";
den=den+lgamma(prior.getDenominator()+freq.getDenominator());
//cout <<"\nden: " << prior.getDenominator()+freq.getDenominator() <<"\n";
for (int k=0;k<xTotalMods;k++)
{
     pos[0]=k;
 //   cout << pt->getValue(pos).print() <<"\n";
 if (pt->getValue(pos).getDenominator()!=0)
 {
    num=num+lgamma(pt->getValue(pos).getNumerator()+priors->getValue(pos).getNumerator());
//    cout <<"\nnumIn: " << pt->getValue(pos).getNumerator()+priors->getValue(pos).getNumerator() <<"\n";
    den=den+lgamma(priors->getValue(pos).getNumerator());
  //  cout <<"\ndenIn: " << priors->getValue(pos).getNumerator() <<"\n";
}
//cout <<"\nnum inside: " << pt->getValue(pos).getNumerator()+priors->getValue(pos).getNumerator();
//cout <<"\nden inside: " << priors->getValue(pos).getNumerator();
}
}
zap(pos);

}
//cout <<"\nnum: " << num <<", den: " << den <<"\n";
//cout <<"\nresult is " << num-den <<"\n";
//return -(num-den);// it should be num-den but we change the sign to make de measure positive
return (num-den);
}
catch (NonProb mv){mv.PrintMessage("BayesScore::getMeasure");end();}
  }

/*______________________________________________________*/
/*
template<> double BayesScore<int>::getMeasure(CPT *pt, CPT* priors)
{
//This implementation should be used only to compute y->x versus x\indep y
//So we only compute Bayes score for node x in the network
// If y=-1, we compute score for x\indep y
//if not, we compute score for y->x
// it is used in log scale

//cout <<*pt;
//cout <<*priors;
ProbabilityTable* s1=pt->getProbabilityTable();
int xTotalMods=s1->dimensionList->GetElement(0);
double num=0, den=0;
int* pos=NULL;//, *pos2=NLL;
//cout <<*pt;
for (int j=0;j<s1->getSize()/xTotalMods;j++)
 {
   pos=s1->getPositions(j);
if (pt->getValue(pos).getDenominator()!=0)
{
//cout <<"\nnum is " << priors->getValue(pos).getDenominator();
//cout <<"\nden: " << priors->getValue(pos).getDenominator()+s1->getValue(pos).getDenominator();
num=num+lgamma(priors->getValue(pos).getDenominator());
den=den+lgamma(priors->getValue(pos).getDenominator()+s1->getValue(pos).getDenominator());
for (int k=0;k<xTotalMods;k++)
{
    pos[0]=k;
 //cout << pt->getValue(pos).print() <<"\n";
  
    num=num+lgamma(pt->getValue(pos).getNumerator()+priors->getValue(pos).getNumerator());
    den=den+lgamma(priors->getValue(pos).getNumerator());
//cout <<"\nnum inside: " << pt->getValue(pos).getNumerator()+priors->getValue(pos).getNumerator();
//cout <<"\nden inside: " << priors->getValue(pos).getNumerator();
}
}
zap(pos);

}
//cout <<"\nresult is " << num-den;
return (num-den);

  }
  */
  
  /*______________________________________________________*/

template<class T> ostream& operator<<(ostream& out, BayesScore<T>& lista)
{
 
//out << *lista.sample;

return out;
  }

} // end namespace
#endif
