#ifndef Correlation_cpp//
#define Correlation_cpp//

namespace BIOS 
{
/*
template <class T> Correlation<T>::Correlation(int classNum, MLSample<T>* sample, BayesType bayesType, float alpha): DependenceMeasure<T>(bayesType, alpha)
{
this->sample=new MLSample<T>(*sample);
correlationMatrix=new DiagonalTable<double>(sample->listOfAttributes->GetSize());
correlationMatrix->initialize(maxreal);
this->classVar=new intList();
this->classVar->insertElement(classNum);
this->feature1=new intList();
this->feature2=new intList();
this->classNum=classNum;
}
/*______________________________________________________*/

template <class T> Correlation<T>::~Correlation()
{
zap(correlationMatrix);
zap(classVar);
zap(feature1);
zap(feature2);
};

/*______________________________________________________*/
/*
template <class T>  double Correlation<T>::getMeasure(intList* varList)
{
float featureClass=0, featureFeature=0; 
intList::iterator p=varList->getFirst(), p2;
SymmetricalUncertainty<T>* symmetricalUncertainty= new SymmetricalUncertainty<T>();
while (p!=varList->end())
{
feature1->insertElement(varList->getElement(p));
if (correlationMatrix->getValue(classNum, feature1->getFirstElement())>=maxreal)
correlationMatrix->setValue(classNum, feature1->getFirstElement(), symmetricalUncertainty->getMeasure(sample, classVar, feature1));
featureClass=featureClass+correlationMatrix->getValue(classNum, feature1->getFirstElement());
p2=varList->getNext(p);
while (p2!=varList->end())
{
feature2->insertElement(varList->getElement(p2));
if (correlationMatrix->getValue(feature1->getFirstElement(), feature2->getFirstElement())==maxreal)
correlationMatrix->setValue(feature1->getFirstElement(), feature2->getFirstElement(), symmetricalUncertainty->getMeasure(sample, feature1, feature2));
featureFeature=featureFeature+correlationMatrix->getValue(feature1->getFirstElement(), feature2->getFirstElement());
p2=varList->getNext(p2);
feature2->Pop();
}
p=varList->getNext(p);
feature1->Pop();
} 
return featureClass/sqrt(varList->size()+featureFeature);
};//
/*______________________________________________________*/

template<class T> ostream& operator<<(ostream& out, Correlation<T>& lista)
{
 
out << *lista.sample;

return out;
  }

  
} // end namespace
#endif
