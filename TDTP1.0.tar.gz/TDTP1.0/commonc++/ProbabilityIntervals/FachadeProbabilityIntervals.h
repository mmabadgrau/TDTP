#ifndef __FachadeProbabilityIntervals_h__ 
#define __FachadeProbabilityIntervals_h__ 


#include "ProbabilityInterval.h"

#include "ProbabilityIntervals.h"

#endif
