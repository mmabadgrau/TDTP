#ifndef DependenceMeasure_h//
#define DependenceMeasure_h//



namespace BIOS 
{


//////

template <class T> class DependenceMeasure: public Measure<T>

{ 
	
   
public:



    DependenceMeasure(BayesType bayesType=MLE, float alpha=0);
    ~DependenceMeasure(){};

// get marginal measure of varList or conditional measure of varlList given conditionalVarList (depending whether is null or not)

 double getMeasure(typename VectorSample<T>::Class* sample, ListOfAttributes* listOfAttributes, intList* varList, intList* conditionalVarList=NULL);
 double getLDMeasure(typename VectorSample<T>::Class* sample, ListOfAttributes* listOfAttributes, intList* varList, intList* conditionalVarList);
     double getMeasure(CPT* sample, CPT* priors=NULL)
{
throw NonImplemented("DependenceMeasure:getMeasure");
};//{cout <<"DependenceMeasure getMeasure not implemented yet"; end();};

     bool better(double m1, double m2)
{
throw NonImplemented("DependenceMeasure:better");
};//{cout <<"DependenceMeasure better not implemented yet"; end();};
     bool betterPair(HeteroPair<float, int>m1,     HeteroPair<float, int>m2);
};//

//template<> double DependenceMeasure<int>::getMeasure(intSample* sample, ListOfAttributes* listOfAttributes, intList* varList, intList* conditionalVarList);
//template<> double DependenceMeasure<int>::getLDMeasure(intSample* sample, ListOfAttributes* listOfAttributes, intList* varList, intList* conditionalVarList);

/*______________________________________________________*/

template<class T> ostream& operator<<(ostream& out, DependenceMeasure<T>& lista);


  
} // end namespace
#endif
