#ifndef __FachadeMeasure_h__ 
#define __FachadeMeasure_h__ 





#include "MeasureTypeClass.h"
#include "Measure.h"
#include "MeasureCompetition.h"
#include "DependenceMeasure.h"
#include "MLEst.h"
#include "Entropy.h"
#include "MDL.h"
#include "BayesScore.h"
#include "EmpiricalRisk.h"
#include "Correlation.h"
#include "InformationGain.h"
#include "SymmetricalUncertainty.h"

#endif
