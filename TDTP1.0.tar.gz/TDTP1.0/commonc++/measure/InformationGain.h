#ifndef InformationGain_h//
#define InformationGain_h//



namespace BIOS 
{


//////

template <class T> class InformationGain: public DependenceMeasure<T>

{ 
	
   
public:


    InformationGain();
InformationGain(BayesType bayesType=MLE, float alpha=0);
bool better(double m1, double m2);
double getMeasure(CPT *s1, CPT* priors=NULL);
//double getMeasure(MLSample<T>* sample, intList* varList, intList* conditionalVarList=NULL);

};//

/*______________________________________________________*/

template<class T> ostream& operator<<(ostream& out, InformationGain<T>& lista);

  
} // end namespace
#endif
