
#ifndef __WeightedChiSquared_c__
#define __WeightedChiSquared_c__

namespace BIOS
{

  
/*_______________________________________________________________*/
/*
double pdfWeightedChiSquared(double x, int df)
{
// is this corrent? 
double h=df/(double)2;
if (x<=0) return 0.0;
return (std::pow(x, h-1)*exp(-x/2))/(std::pow(2,h)*gamma(h));
}

/*_______________________________________________________________*/

double pdfTestWeightedChiSquare(double x, doubleList* weights) throw (NonProb)
// it computes an approximation of p value p(w>x), with w being the weighted chi square distribution, weight vector and df degrees of freedom:
//pr(sum weight*x_i^2 > x) where x_i ~N(0,1) and sum weights=1
// computes as the maximum between 1-sum d_i * gammai(1/(2d_i), x/(2d_i) and pdfchi^2(weights->size()) for x/(prod d_i)^(1/n) 
{

 double result=0, dZero, G, delta;
 double DS=1;
 
 // it computes G(x)
double totalWeights=0;
 for (doubleList::iterator it=weights->begin(); it<weights->end(); it++)
 {
 dZero=0.5/weights->getElement(it);
 result=result+weights->getElement(it)*gammai(dZero, x*dZero);
 DS=DS*weights->getElement(it);
totalWeights=totalWeights+weights->getElement(it);
 }
if (totalWeights>(1+zero) || totalWeights<(1-zero))
 throw NonProb("pdfTestWeightedChiSquare", totalWeights); 
 // it computes H(x)
 //G=1-pdfTestChiSquare(x/std::pow(DS, 1/weights->size()), weights->size());
 //if (G<result) result=G;, does not work. Using G>result no differences than ignoring G
 return 1-result;
}
/*_______________________________________________________________*/

double pdfTestWeightedChiSquare2(double x, doubleList* weights, int df)
// it computes an approximation of p value given x (weighted chi square value), weight vector and df degrees of freedom:
//pr(sum weight*x_i^2 > x) where x_i ~N(0,1) and sum weights=1
// computes as the maximum between 1-sum d_i * gammai(1/(2d_i), x/(2d_i) and pvalue of chi^2(weights->size()) for x/(prod d_i)^(1/n) 
{

 double result=0, dZero, G, delta;
 double DS=1;
 
 // it computes G(x)
 for (doubleList::iterator it=weights->begin(); it<weights->end(); it++)
 {
 dZero=0.5/weights->getElement(it);
 result=result+weights->getElement(it)*gammai(dZero, x*dZero);
 DS=DS*weights->getElement(it);
 }
 return 1-result;
}
/*_______________________________________________________________*/
/*
double cdfWeightedChiSquared(double x, int df)
{
double h=df/(double)2;
return BIOS::gammai(h,x/2)/(h);
}

/****************************************************************************/
/*
double weightedChiTest (double* observed, double*expected, int df)
// it computes p value given the df+1 absolute frequencies and the df+1 expected values
{
double chi=0;
for (int i=0;i<=df;i++)
{
if (expected[i]==0) throw NanValue("chiTest");
 chi=chi+std::pow(observed[i]-expected[i],2)/expected[i];
}
return pdfTestWeightedChiSquared(chi, df);
}

/****************************************************************************/

}
#endif
