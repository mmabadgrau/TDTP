
#ifndef __chiSquare_h__
#define __chiSquare_h__

namespace BIOS
{

  const double BIGX = 20.0;  
/*_______________________________________________________________*/

double pdfChiSquare(double x, int df);
/*_______________________________________________________________*/

double poz(double z) ;


/*_______________________________________________________________*/
double ex(double x);
/*_______________________________________________________________*/

double pdfTestChiSquare(double x, int df);

/*_______________________________________________________________*/

double cdfChiSquare(double x, int df);

//****************************************************************************80

double chiTest (double* observed, double*expected, int df);
}
#endif
