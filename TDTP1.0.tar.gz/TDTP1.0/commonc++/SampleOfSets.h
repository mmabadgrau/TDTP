#ifndef SampleOfSets_h//
#define SampleOfSets_h//



namespace BIOS 
{

// not sure if this class should work for both sample of sets of primitive data and sample of sets of class data (heap data)
template<class T>
    class SampleOfSets: public Container<vector<Container<set<T>, T>*>, Container<set<T>,T>*>
{
 
  public:
  
  
    intList* getBlankets (Container<set<T>,T>* otherSet);

   Container<set<T>, T>* getUnionOfIntersections ();


   intList* getOptimalMaxIntersection (Container<set<T>, T>* otherSet);
 
   int getOptimalBlanket (Container<set<T>, T>* otherSet);
   int getMaxIntersection (Container<set<T>, T>* otherSet);

    
   SampleOfSets(SampleOfSets &source):Container<vector<Container<set<T>, T>*>, Container<set<T>,T>*>(source){};
   SampleOfSets():Container<vector<Container<set<T>, T>*>, Container<set<T>,T>*>(){};
   ~SampleOfSets(){};
   SampleOfSets<T>* getCommonNodes (Container<set<T>, T>* otherSet);
   
   Container<set<T>, T>* jointSets ();


};

/*______________________________________________________*/

template<class T> ostream& operator<<(ostream& out, SampleOfSets<T>& lista);
  
  



} // end namespace
#endif
