/* File: Set.h */


#ifndef __Set_cpp__
#define __Set_cpp__



/**
    @memo Declaration of a ListOfPointers (FIFO)
    @doc
    */

//using namespace UTILS;

namespace BIOS
{

  /************************/
  /* ListOfPointers DEFINITION */
  /************************/


  /**
          @memo ListOfPointers 
   
  	@doc
          Definition:
          A Cont of ListOfPointers's features 
   
          Memory space: O(SizeP), which SizeP being the number of elements in the ListOfPointers
   
      @author Maria M. Abad Grau
  	@version 1.0
  */
//template <class T> typedef  AssociateContainer<Cont, T> AssociateContainer<Cont, T>;


// template <class T> class Set: public AssociateContainer<Cont, T>
//   {





/*____________________________________________________________ */

 
   //R/template <template<class> class Cont, class T>
/*
   template <class T>  
   Set<T>::Class* Set<T>::Class::removeSubsets ()
    {
     typename Container<set, T>::iterator p=this->GetFirst(), pNext, p2=NULL;
      bool found;
      while (p!=this->end())
      {
      p2=this->GetFirst();
      found=false;
      while(p2!=this->end() && !found)
      {
      if (p!=p2 && this->GetElement(p)->includes(this->GetElement(p2)))
      {
      p2=this->removeNode(p2);
      found=true;
      }
      else p2=this->GetNext(p2);
      }
      p=this->GetNext(p);
      }
    }
    /*___________________________________________________________*/

/*
    template <class T>  
    Set<T>::Class* Set<T>::Class::getCommonNodes (Set<T>::Class* otherSet)
    {
      if (otherSet==NULL)
      {
        cout <<"Error in Set::getCommonNodes, argument is NULL";
        end();
      }
      Container<set, T>* commonSet=new Container<Cont, T>();
      Container<set, T>* orderedSet1=NULL;
      Container<set, T>* orderedSet2=NULL;
      // choose this shortest list
      if (this->GetSize()>otherSet->GetSize())
      {
        orderedSet1=new Container<Cont, T>(*this);
        orderedSet2 =new Container<Cont, T>(*otherSet);
      }
      else
      {
        orderedSet1=new Container<Cont, T>(*otherSet);
        orderedSet2 =new Container<Cont, T>(*this);
      }
      T* element=NULL;
      typename Container<Cont, T>::iterator p=orderedSet1->GetFirst(), pNext, p2=NULL;
      
      while (p!=orderedSet1->end())
      {
        element=orderedSet1->GetElement(p);
	if (element==orderedSet1->end())
	{
	cout <<"EERRR";
	end();
	}
	//cout <<"\nfinding element" << element->print() <<" in bag:" << orderedSet2->print();
        p2=orderedSet2->findElement(element);
        if (p2!=orderedSet2->end())
        {
          commonSet->insertElement(element);
          orderedSet2->removeNode(p2);
        }
        p=orderedSet1->GetNext(p);
      }
      
      zap(orderedSet1);
      zap(orderedSet2);
      return commonSet;
    }


 
/*______________________________________________________*/
/*
  template <class T>  ostream& operator<<(ostream& out, Set<T>::Class& lista)
  {
   typename Container<set, T>::Class::iterator p=lista.GetFirst();
   while (p!=lista.end())
   {
      out << *lista.GetElement(p);
      p=lista.GetNext(p); 
      if (p!=lista.end()) out <<"; ";
   }
   
   return out;
  }
*/


    

}; // end namespace
#endif

//#include "ListOfPointers.cpp"

/* Fin Fichero: ListOfPointers.h */
