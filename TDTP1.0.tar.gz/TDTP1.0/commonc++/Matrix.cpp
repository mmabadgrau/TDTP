/* File: Matrix.h */


#ifndef __Matrix_cpp__
#define __Matrix_cpp__


using namespace std;

namespace BIOS
{



 
    /*______________________________________________________*/

    Matrix::Matrix()
    {
     cout <<"Error in Matrix";
     end();
    };
/*______________________________________________________*/


   Matrix::~Matrix(){};


  /*______________________________________________________*/

     Matrix::Matrix(intList* dimensionList):BidimensionalTable<double>()
    {
    };
    /*______________________________________________________*/

     Matrix::Matrix(int xDim, int yDim):BidimensionalTable<double>(xDim, yDim)
    {
    };

/*___________________________________________________*/

Matrix*  Matrix::operator* (Matrix* other)
{
// it computes vectorial product between this and other
if (getYDim()!=other->getXDim())
{
cout << "Error in Matrix product";
end();
}
double value;
Matrix* result=new Matrix(getXDim(), other->getYDim());
for (int i=0; i<result->getXDim(); i++)
for (int j=0; j<result->getYDim(); j++)
{
value=0;
for (int k=0; k<getYDim(); k++)
value=value+getValue(i, k)*other->getValue(k, j);
result->setValue(i, j, value);
}
return result;
}


/*___________________________________________________*/

Matrix*  Matrix::getSquaredMatrix ()
{
// it computes vectorial product between this and transformed this

double value;
Matrix* result=new Matrix(getXDim(), getYDim());
for (int i=0; i<result->getXDim(); i++)
for (int j=0; j<result->getYDim(); j++)
{
value=0;
for (int k=0; k<getYDim(); k++)
value=value+getValue(i, k)*getValue(j, k);
result->setValue(i, j, value);
}
return result;
}


  /*______________________________________________________*/

  template <class T> ostream& operator<<(ostream& out, Matrix& p)
  {
  out << "\t\t|\t";
      for (int i=0; i<p.dimensionList->getElement(1);i++)
        out << i << "\t|\t";
      out <<"\n";
      for (int i=0; i<p.dimensionList->getElement(1);i++)
      out <<"_____________________";
out <<"\n";
  for (int j=0; j<p.dimensionList->getFirstElement();j++)
{
out  << "\t" <<  j << "\t|\t";
  for (int i=0; i<p.dimensionList->getElement(1);i++)
   out << p.getValue(j,i) <<"\t|\t";
out <<"\n";
}
out <<"\n";
return out;
  };
}
#endif
