#ifndef AttPattern_h//
#define AttPattern_h//



using namespace std;


namespace BIOS {



/************************/
/* ListOfLists DEFINITION */
/************************/


/**
        @memo AttPattern 

	@doc

    @author Maria Mar Abad Grau
	@version 1.0
*/


/*______________________________________________________*/

   ostream& operator<<(ostream& out, AttPattern& attPattern)
  {

         out << attPattern.print() <<"\n";
    return out;
  }



}// end namespace
#endif
