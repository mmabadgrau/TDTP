
#ifndef __basic_h__
#define __basic_h__
/*
#include<sstream>
#include <sys/stat.h>  
*/
//#include <iostream>
//#include <cassert>
//#include <fstream>
/*#include <string>
#include <iostream>
#include <cmath>
#include <stdio.h>//
#include "ExceptionsBasic.h"
#include <values.h>
*/
//#define maxint ((int)(~(unsigned int)HIBITI))

using namespace std;

#define  maxint MAXINT //
#define  maxline 100000//
#define maxreal MAXFLOAT // 1.7E+38//
#define zero 0.1E-6 //
//#define round(x) (x<0?ceil((x)-0.5):floor((x)+0.5)) //

namespace BIOS {




typedef enum  {
	equal=0,
	lower=-1, 
	greater=1
	
} ComparisonType;

	typedef enum {
		MLE=0, 
			UBalpha=1, 
			MarginalBayes=2,
			equilibrium=3,
			BDistanceUniform=4,
			BDistanceSymmetrical=5,
			BDistanceMarginal=6
			
	} BayesType; 


extern ofstream OutputFile, OutputFile2, OutputFile3, OutputFile4;
extern ifstream InputFile, InputFile2, InputFile3, InputFile4;

/*
 ofstream OutputFile();
 ofstream OutputFile2();
 ofstream OutputFile3();
 ofstream OutputFile4();
 ifstream InputFile();
 ifstream InputFile2();
 ifstream InputFile3();
 ifstream InputFile4();
*/
typedef int uli;

struct FreqAndVal
  {
	  double value;
	  double frequency;
/*


  bool operator>(const struct FreqAndVal& p) {if (frequency>p.frequency || frequency==p.frequency && value>p.value) return true; else return false;};
	 bool operator<(const struct FreqAndVal& p) {if (frequency<p.frequency|| frequency==p.frequency && value<p.value) return true; else return false;};
	 bool operator==(struct FreqAndVal& p) {if (frequency==p.frequency && value==p.value) return true; else return false;};

*/

  } ;


//typedef HeteroPair<long long int, frequency


	//template <class T> T* ExtractList(T object, int indexVector[], int size);//
 // template <class T> void print(T val);
//string print (double e);
void replaceAll(string &source, string oldPattern, string newPattern);
void print(char* filename);
void FileAppend (char* forigen, char* fdestino);




//template <class T>T* getPointerToObject(T argument); //it returns the pointer itself for pointers to class types, a pointer to the argument otherwise


//template <template <class T, typename _Alloc=std::allocator<T> > class Cont, class T>
//T& Container<Cont, T>::iterator::getElement();


	
	/*____________________________________________________*/

bool isNAN(double val);

 /*______________________________________________________*/
	template <class T>
		void reorderValues(T* array, int size, T* pos,  T* targetArray);

 //   template <class T> ofstream& operator<<(ofstream& out, const T& p);
template <class T>
	void disperseValues(T* array, int size, T* pos, T* targetArray, int sizeTarget);
  int getLineSize (ifstream * source);
 //   template <class T> int compare(const void *arg1, const void *arg2);
//template <class T> bool compare(const T arg1, const T arg2);
//template<class T> bool compareinvPointer(const T&arg1, const T& arg2);
//template<class T> bool compare(const T* &arg1, const T* & arg2);
 // virtual template <class T> ostream& operator<<(ostream& out, T& clase);

//template<class T> struct Compare;
//template<class T> struct CompareInv;

//template <class T> int compareinv(const T*&arg1, const T*& arg2);



template <class T> bool comparePointer(const T& arg1, const T& arg2);
template <class T> bool compare(const T& arg1, const T& arg2);
//template <class T> bool compare(const T* arg1, const T* arg2);

//template <class T> bool compare(const T*& arg1, const T*& arg2);
//template <class T> bool compareInvPointer(const T& arg1, const T& arg2);
template <class T> bool compareInv(const T& arg1, const T& arg2);
  //  	template<class T> int comparePointer(const void *arg1, const void *arg2);
	//template<class T> int compareinvPointer(const void *arg1, const void *arg2);

void OpenOutput(const char* filename, ofstream* OutputFile);
void OpenOutputAdd(char* filename, ofstream* OutputFile);
	void OpenOutputBasic(const char* filename, ofstream* OutputFile, bool add) throw (ErrorFile);
void OpenInput(const char* FileName, ifstream* InputFile);
	
int GetLineLength (char * FileName);
int pow (int base, int exp);
int pow (int base, int exp);
double log_2 (double numero);//
int getGauss (int num);
double pdfChiSquare(double x, int df);
double pdfTestChiSquare(double x, int df);
double ddfChiSquare(double x, int df);
double chiTest (double* observed, double*expected, int df);
void CheckFile(char* filename, bool exists=true);

template <class T> string tos(T i);
template <class T> T fromString(T i, string s);
string tos(double i, int integerPart, int decimalPart);

void end();

  char* CaptureLine (ifstream * source);
template <class T> T sum (T* array, unsigned int length);
template <class T> void change (T & val1, T  & val2);//swap
template <class T> T * Initialize(int size, T val);
template <class T>
void InitializeList(T* list, int size, T val);
template <class T> bool IsOne (T value);

bool existFile (const char* namefile);

int maxlong ();
bool IsAZero(unsigned int column, unsigned int pos);
unsigned int GetTotalColumns (char* filename);

template <class T> void zap(T & x);
template <class T> void zap(T *& x);
//template <class T> void empty(T & x);
template <class T> void emptyObject(T *& x);
//template <class T> void deepZap(T & x);

template <class T> void zaparr(T & x);

template <class T> void zaparr(T & x, int size);

long factorial(long n);

double getAccuraciesSampleSD(int num, int total);

double getAccuraciesSampleVariance(int num, int total);

/*_______________________________________________________________*/

long product(long first, long last);

/*_______________________________________________________________*/

double combinations(long n, long m);

/*_______________________________________________________________*/

bool isANumber (const char* cad);

/*_______________________________________________________________*/

bool isAnInteger (const char* cad);
float GetMean (float * values, int size);
template <class T> T GetMean (Pair<T>* values, int size, bool first=true);
float GetSampleSD (float * values, int size);
template <class T> void normalize (T * values, int size) throw (ZeroValue);
int median(int * ip, int  size);
bool IsOne(double number);
double percentile(double * ip, int size, double perc);
double permile(double *ip, int size, double permile);
double proportion(double *ip, int size, int scale, double prop);
double percentile(struct FreqAndVal * ip, int  size, double perc);
template <class T> T maxi(T a, T b);
double max(struct FreqAndVal a, struct FreqAndVal b);
template <class T> T mini(T a, T b);
template <class T> T GetExtreme(T* array, int size, bool IsMax=true);
template <class T> int GetExtremePos(T* array, int size, bool IsMax=true);
template <class T> T GetMax(T* array, int size);
template <class T> T GetMin(T* array, int size);
template <class T> int GetMaxPos(T* array, int size);
template <class T> int GetMinPos(T* array, int size);
void ChangeExtension (char* FileSource, char*FileTarget, const char* Extension);
char* GetFileExtension (char* FileSource);
char* getFilePath (const char* FileSource);
char* removeDir (const char* FileSource);

char* getFilename (const char* FileSource);

void ChangeFilename (char* FileSource, char*FileTarget, char* newname);
char* AddFilename (char* FileSource, char* chunk);
void AddFilename (char* FileSource, char* FileTarget, char* chunk);
bool HasThisExtension (char* FileSource, const char* Extension, unsigned short int ExtensionLength);
//void CaptureLine (ifstream * source, char* genotypebuf);
char* GetLine (ifstream * source);
int GetLineLength (char * FileName);
int GetTotalColumns2(char * FileName);
void NextLine (ifstream* InputFile);
void splitword (char * out, char *in, char stop);

/*______________________________________________________________*/

void fileCopy (char* forigen, char* fdestino);


void CopyWithoutChar (char * out, char *in, char rem);

/*---------------------------------------------------------------*/
int getTotalLines (const char * FileName);

/*____________________________________________________________ */


template <class T>
		void collapseValues(T* array, int size, T* pos, T* targetArray, int sizeTarget);
	
		
	bool isAFloat (const char* cad);

long int GetFileSize(char* nomfich);

int GetStringLinePosition (char* FileName, char* string);



}
// end namespace

//#include "basic.cpp"
#endif


