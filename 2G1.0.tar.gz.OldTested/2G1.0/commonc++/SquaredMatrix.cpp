/* File: SquaredMatrix.h */


#ifndef __SquaredMatrix_cpp__
#define __SquaredMatrix_cpp__


using namespace std;

namespace BIOS
{


 
    /*______________________________________________________*/

    SquaredMatrix::SquaredMatrix()
    {
     cout <<"Error in SquaredMatrix";
     end();
    };
/*______________________________________________________*/


  SquaredMatrix::~SquaredMatrix(){};


 
    /*______________________________________________________*/

    SquaredMatrix::SquaredMatrix(int xDim):Matrix(xDim, xDim)
    {
    };

/*___________________________________________________*/

double SquaredMatrix::getTrace ()
{
double value=0;
for (int i=0; i<getXDim(); i++)
value=value+getValue(i, i);
return value;
}


  /*______________________________________________________*/

  template <class T> ostream& operator<<(ostream& out, SquaredMatrix& p)
  {
  out << "\t\t|\t";
      for (int i=0; i<p.dimensionList->getElement(1);i++)
        out << i << "\t|\t";
      out <<"\n";
      for (int i=0; i<p.dimensionList->getElement(1);i++)
      out <<"_____________________";
out <<"\n";
  for (int j=0; j<p.dimensionList->getFirstElement();j++)
{
out  << "\t" <<  j << "\t|\t";
  for (int i=0; i<p.dimensionList->getElement(1);i++)
   out << p.getValue(j,i) <<"\t|\t";
out <<"\n";
}
out <<"\n";
return out;
  };
}
#endif
