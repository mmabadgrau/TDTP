#ifndef BayesScore_h//
#define BayesScore_h//



namespace BIOS 
{


//////

template <class T> class BayesScore: public DependenceMeasure<T>
{ 

   
public:

bool better(double m1, double m2);
double getMeasure(CPT *s1, CPT* priors) throw (BadSize);
BayesScore(BayesType bayesType, float alpha);
~BayesScore(){};  
};//

/*______________________________________________________*/

template<class T> ostream& operator<<(ostream& out, BayesScore<T>& lista);

  
} // end namespace
#endif
