#ifndef __FachadeMeasureC_h__ 
#define __FachadeMeasureC_h__ 




#include "Measure.cpp"
#include "MeasureCompetition.cpp"

#include "DependenceMeasure.cpp"
#include "MLEst.cpp"
#include "Entropy.cpp"
#include "BayesScore.cpp"
#include "EmpiricalRisk.cpp"
#include "MDL.cpp"
#include "Correlation.cpp"
#include "InformationGain.cpp"
#include "SymmetricalUncertainty.cpp"

#endif
