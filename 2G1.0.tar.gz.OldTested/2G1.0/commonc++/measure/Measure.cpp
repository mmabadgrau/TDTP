#ifndef Measure_cpp//
#define Measure_cpp//



namespace BIOS 
{


/*______________________________________________________*/

template<class T>  Measure<T>::Measure(BayesType bayesType, float alpha) 
{
this->alpha=alpha;
this->bayesType=bayesType;
//set(sample);
}
/*______________________________________________________*/
/*
template<class T> void Measure<T>::set(MLSample<T>* sample) 
{
this->sample=sample;
  }
*/
/*______________________________________________________*/

template<class T> ostream& operator<<(ostream& out, Measure<T>& lista)
{
 
out << *lista.sample;

return out;
  }
  
} // end namespace
#endif
