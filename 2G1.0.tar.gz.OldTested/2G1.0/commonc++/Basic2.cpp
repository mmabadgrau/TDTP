
#ifndef __Basic2_cpp__
#define __Basic2_cpp__


#include "Basic2.h"
using namespace std;

namespace BIOS
{


//R/template <class T, template <class T> class Cont> 
template <class Cont, class T> 
bool empty(Container<Cont, T>* lista)
{
   return lista==NULL || lista->size()==0;
}


/* _____________________________________________________*/

stringVector*  getStringVector (char * genotypebuf2, const char* tokensSource, int len)
{
char genotypebuf[len+1];
if (genotypebuf==NULL) return NULL;
stringVector* strList=NULL;
  
strcpy(genotypebuf, genotypebuf2);
    char tokens[10];


    if (tokensSource==NULL) strcpy(tokens, "\t, \n\r");
else
    if (strstr(tokensSource, ",\"")!=NULL ||
strstr (tokensSource, "\",")!=NULL)
{
string st=string(tokensSource);
replaceAll(st, string("\","), string("\t"));
replaceAll(st, string(",\""), string("\t"));
strcpy(tokens, st.c_str());
strcpy(genotypebuf, genotypebuf+1);//remove first char (double quote mark)
genotypebuf[strlen(genotypebuf)-1]='\0'; // remove last char
string st2=string(genotypebuf);
string oldS=string("\",\""), newS=string("\t");
replaceAll(st2, oldS, newS);
strcpy(genotypebuf,st2.c_str());
}
else strcpy(tokens, tokensSource);
    string s;
    char *cad;
    cad = strtok (genotypebuf2, tokens);
int i=0;
while (cad!=NULL) // && cad[0]!='\n')// && cad[0]!='\r' && cad[0]!='/')
    {
        if (i==0) strList=new stringVector();
        s=string(cad);
        strList->insertElement(s);
        cad = strtok (NULL, tokens);
        i++;
	   };
return strList;
  };


/* _____________________________________________________*/

}
// end namespace

//#include "basic.cpp"
#endif


