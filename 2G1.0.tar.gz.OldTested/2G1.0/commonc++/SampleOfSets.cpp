#ifndef SampleOfSets_h//
#define SampleOfSets_h//



namespace BIOS 
{


template<class T> ostream& operator<<(ostream& out, SampleOfSets<T>& lista)
  {
  typename SampleOfSets<T>::NodePointer p=lista.GetFirst();
 while (p!=NULL)
    {
         out << *lista.getElement(p);
         p=lista.GetNext(p); 
        if (p!=NULL) out <<"\n";
    }
   
    return out;
  }

  
  



} // end namespace
#endif
