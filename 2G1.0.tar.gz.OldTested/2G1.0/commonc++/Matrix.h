/* File: Matrix.h */


#ifndef __Matrix_h__
#define __Matrix_h__


using namespace std;

namespace BIOS
{

  /////////////////////////////////////////
  class Matrix: public BidimensionalTable<double> //
  {//
    // it is a xD table with position numbers first in deep vars. Example: 2x2 table. Position numbers 0,1,2,3 are respectively t[0,0], t[0,1], t[1,0], t[1,1]
  public:

 
    /*______________________________________________________*/

    Matrix();
/*______________________________________________________*/


  ~Matrix();


  /*______________________________________________________*/

    Matrix(intList* dimensionList);
    /*______________________________________________________*/

    Matrix(int xDim, int yDim);

/*___________________________________________________*/

Matrix* operator* (Matrix* other);


/*___________________________________________________*/

Matrix* getSquaredMatrix ();
};
  /*______________________________________________________*/

  template <class T> ostream& operator<<(ostream& out, Matrix& p);
}
#endif
