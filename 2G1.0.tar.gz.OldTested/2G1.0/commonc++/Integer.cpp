/* File: Integer.h */


#ifndef __Integer_cpp__
#define __Integer_cpp__




using namespace std;


namespace BIOS
{
/*______________________________________________________*/

   ostream& operator<<(ostream& out, Integer& i)
  {
  out << i.position;
      
    return out;
  };




}
;  // Fin del Namespace

#endif

/* Fin Fichero: Integer.h */
