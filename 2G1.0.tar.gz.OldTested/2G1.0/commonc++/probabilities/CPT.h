/* File: CPT.h */


#ifndef __CPT_h__
#define __CPT_h__




using namespace std;


namespace BIOS
{
class PriorTable;
//extern class PriorTable;
 class CPT
  {//
protected:
VarsTable<Prob> *marginals, *conditionals, *distr;
// as an example with only 2 vars: marginals contain p(K) while conditionals p(A/K), first A and then K
public:
//float getAlphaDenominator(ListOfAttributes* listOfAttributes, BayesType, bayesType, float alpha, floatList* positionsVector, intList *varList, intList *conditionalVarList);
bool prior;
void empty();
    string print();
    CPT(CPT &source);
    CPT(intSample*  sample, intList *varList, intList *conditionalVarList, intList* dimensionList, BayesType bayesType, float alpha, ListOfAttributes* listOfAttributes);//floatList* alphaNumerators, float alphaDenominator, intSample::NodePointer first=NULL, intSample::NodePointer last=NULL);
    CPT(intList *conditionalVarList, PriorTable *priorTable);
    CPT();
    ~CPT();
    VarsTable<Prob>* marginalize();
//    Prob getProbability(int* values, float alphaNumerator, float alphaDenominator);
//    Prob getProbability(int pos, float alphaNumerator, float alphaDenominator);
    Prob getValue(int* values);
    Prob getValue(int pos);

  //  VarsTable<Prob>* getProbability();
    int* getPositions(int i);
    int getDimension();
    int getSize();
    intList* getDimensionList();
    int getPos(int* positions);
    void setMarginals(VarsTable<Prob>* marginals);
    void setConditionals(VarsTable<Prob>* conditionals);
   VarsTable<Prob>* getMarginals();
    VarsTable<Prob>* getConditionals();
   PriorTable* getPriorMarginals();
    PriorTable* getPriorConditionals();
VarsTable<double> *convertToPotential();
VarsTable<Prob>* getProbabilityTable();
PriorTable* getPriorProbabilityTable();
int getTotalSample();
void addPrior(CPT& priors);
};

}
#endif

