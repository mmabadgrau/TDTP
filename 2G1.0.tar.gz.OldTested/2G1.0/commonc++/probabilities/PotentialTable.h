/* File: PotentialTable.h */


#ifndef __PotentialTable_h__
#define __PotentialTable_h__


using namespace std;


namespace BIOS
{






typedef VarsTable<double> PotentialTable;




}
#endif
