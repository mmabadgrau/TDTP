#ifndef __FachadeProbabilitiesC_h__ 
#define __FachadeProbabilitiesC_h__ 




#include "ProbabilityTable.cpp"
#include "AlleleProbabilityTable.cpp"

#include "SampleTable.cpp"
#include "VarsTable.cpp"
//#include "PriorTable.cpp"
#include "CPT.cpp"


#include "PotentialTable.cpp"
#include "PotentialList.cpp"
#include "BidimensionalVarsTable.cpp"





#include "AlleleCPT.cpp"


#endif
