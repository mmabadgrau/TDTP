/* File: ProbabilityInterval.h */


#ifndef __ProbabilityInterval_h__
#define __ProbabilityInterval_h__



using namespace std;

namespace BIOS {



           ProbabilityInterval::ProbabilityInterval(Prob f, Prob s):Pair<Prob>(f, s)  {if (f>s) {cout <<"\nError, not a probability interval"; end();}};
           
           ProbabilityInterval::ProbabilityInterval(ProbabilityInterval* p): Pair<Prob>(p) {First=p->First; Second=p->Second;};
           
 	   void ProbabilityInterval::setValues(Prob f, Prob s) 
 	   {
 	   if (f>s) 
 	   {cout <<"\nError, not a probability interval"; end();} 	   
 	   Pair<Prob>::setValues(f,s);
 	   };

/*
template <> ProbabilityInterval* Container<vector, ProbabilityInterval*>::readElement ( ifstream * source, char* tokens )
{
cout << "ProbabilityInterval* Container<vector, ProbabilityInterval*>::readElement not implemented  yet";
end();
};
*/
}//end namespace


#endif
