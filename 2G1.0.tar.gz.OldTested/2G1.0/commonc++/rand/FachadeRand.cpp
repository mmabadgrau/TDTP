#ifndef __FachadeRandC_h__ 
#define __FachadeRandC_h__ 


#include "Binomial.cpp"

#include "Multinomial.cpp"

#include "poisson.c"

#include "Uniform.cpp"
#include "ranbinom.c"

#include "rng.c"

#include "gammln.c"

#include "gamma.c"


#include "expdev.c"
#include "chiSquare.c"
#include "weightedChiSquare.c"
#endif
