/* File: Multinomial.h */


#ifndef __Multinomial_h__
#define __Multinomial_h__



namespace BIOS {


/************************/
/* Multinomial STATISTIC*/
/************************/


/**
        @memo Multinomial

	@doc
        Definition:
        Multinomial distribution of size Size 

        Memory space: O(Size). 

        @author Maria M. Abad
	@version 1.0
*/


 
class Multinomial: public Binomial  {


protected:
    /** @name Implementation of class Multinomial
        @memo Private part.
    */


double* Probs;
/*********************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/

/* PUBLIC FUNCTIONS (INTERFACE) */

public:


Multinomial(int n, int size, double* probs);
~Multinomial();
void setAllValues();
int setValue();
};  // End of class Multinomial




};  // End of Namespace

#endif

/* End of file: Multinomial.h */




