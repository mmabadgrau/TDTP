
/* File: MultimarkerMeasuresByBlocks.h */


#ifndef __MultimarkerMeasuresByBlocks_h__
#define __MultimarkerMeasuresByBlocks_h__



/*______________________________________________________________________________*/



namespace BIOS {

class MultimarkerMeasuresByBlocks

{

public:

doubleList** getPermutationResults (TrioCountersHapUAndT *TM, int totalPermutations, int totalPermutationMeasures, bool maxHap, intList* ignoreMeasures);

void updateMeasures (TrioCountersHapUAndT *TM, int totalPermutations, int totalMeasures, int totalPermutationMeasures, int subblockSize, const int * const pos, const double * const measures, double **measuresP, int iniBlock, bool maxHap, intList* ignoreMeasures, bool useOnlyKnownDistributions, bool onlyHetero) throw (NonProb,NonDefined);

void printResults (int totalMeasures, int size, const int* const totalOverlaps, const int* const totalOverlapsLogTDT, double **measuresP, intList* ignoreMeasures=NULL);

void getMeasures (char* filename, stringSample* blocks,  int windowOffset, int width, bool knownPhase, PhaseAlg phaseAlg, EMDistributions emDistributions, EMRestriction emRestriction, int totalMeasures, int totalPermutationMeasures, int totalPermutations, AlleleOrderType alleleOrderType, int totalSNPs, bool maxHap, intList* ignoreMeasures, bool useOnlyKnownDistributions, bool onlyHetero)  throw (OutOfRange<long long int>, OutOfRange<int>, OutOfRange<int>, NonProb, NoMemory, NonDefined, ZeroValue);

};


} // end namespace

#endif




