/* File: block.h */


#ifndef __block_h__
#define __block_h__



namespace BIOS {


/************************/
/* block SNP*/
/************************/


/**
        @memo block

	@doc
        Definition:
        An array SampleValues of Size values

        Memory space: O(size). 

        @author Maria M. Abad
	@version 1.0
*/





 class BlockList : public Container<vector<Block*>, Block*>{


protected:
    /** @name Implementation of class block
        @memo Private part.
    */

   bool * ListUsedSNPs;

   
	SNPPos TotalSNPs;
  
	float MaxWidth; 
     
	//void OrderBlockByPos();


//	void ReadElement (ifstream * source, unsigned long int size){};


/*********************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/


      
/* PUBLIC FUNCTIONS (INTERFACE) */

   public:

	void WriteBlocks(char* filename);

	BlockList(char* filename);
BlockList();
~BlockList();

};  // End of class block



/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/

//////////// privates /////////////

 
template<> Block* Container<vector<Block*>, Block*>::readElement (ifstream * source, const char* tokens, int* pos, int size);
 


};  // End of Namespace

#endif

/* End of file: BlockList.h */




