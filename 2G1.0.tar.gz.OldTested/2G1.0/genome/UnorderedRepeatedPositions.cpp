/* File: UnorderedRepeatedPositions.cpp */

#ifndef __UnorderedRepeatedPositions_cpp__
#define __UnorderedRepeatedPositions_cpp__



#include "UnorderedRepeatedPositions.h"


//using namespace std;
//using namespace string;

using namespace std;


namespace BIOS {



/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/
// private

/*___________________________________________________________ */

PosS UnorderedRepeatedPositions::ReadElement (ifstream * is)
{
	/*
    unsigned long int size=20;
	struct PosS posS;
	sscanf(CaptureLine(is, size), "%f", posS.pos);
	return posS;
	*/
}

/*____________________________________________________________ */

void UnorderedRepeatedPositions::SetFilePos ()
{

SNPPos i=0;
iterator IndPosition=getFirst();
while (IndPosition!=end())
{
getElement(IndPosition)->filepos=i;
IndPosition=getNext(IndPosition);
i++;
}

}

///////////////////
//// public ////////
///////////////////

/*____________________________________________________________ */

UnorderedRepeatedPositions::UnorderedRepeatedPositions(char* filen):VirtualPositions(filen)
{
}

/*____________________________________________________________ */

void UnorderedRepeatedPositions::CheckFilename(char* filename)
{
if (strncmp(strtok(filename+2, ".")-2, "pos", 3)!=0)
{
	cout <<"File pos is required";
	exit (0);
}
}

/*____________________________________________________________ */

void UnorderedRepeatedPositions::PrintRepeatedPositions ()
 {
order(true);
 // OrderUnorderedRepeatedPositions();

  
  char* filepos2;

 if ((filepos2=new char[128])==NULL)
		 throw NoMemory();

 ChangeExtension (filename, filepos2, "poo\0");
 
 PrintPositions(filepos2);
 
 }

/*____________________________________________________________ */
/*
void UnorderedRepeatedPositions::OrderUnorderedRepeatedPositions()
{
 SNPPos i=0, TotalSNPs=GetTotalSNPs();

 iterator IndPosition=getFirst();

 cout << "Sorting SNPs by UnorderedRepeatedPositions...\n";
	
 PosS *ListPos;
 if ((ListPos=new PosS[TotalSNPs])==NULL)
  throw NoMemory();

 while (IndPosition!=NULL)
 {
  ListPos[i]=GetPointerToElement(IndPosition);
  IndPosition=getNext(IndPosition);
  i++;
 }
 qsort ((void*)ListPos, TotalSNPs, sizeof (*ListPos), comparedouble);

bool OrderedUnorderedRepeatedPositions=true, found;
i=0;

IndPosition=getFirst();

while (IndPosition!=NULL)
{
 IndPosition->element=ListPos[i];
 IndPosition=getNext(IndPosition);  
 i++;
}

delete ListPos;
}
*/
/*____________________________________________________________ */

SNPPos UnorderedRepeatedPositions::GetTotalSNPs()
{
 return size();
}
/*__________________________________________________________*/

void UnorderedRepeatedPositions::CheckRangeSNP(SNPPos SNP)
{
SNPPos TotalSNPs=GetTotalSNPs();
try
{
	if (SNP>=TotalSNPs)
		throw OverflowedSNP();
}
		 catch (OverflowedSNP ov) {
		 ov.PrintMessage(SNP);}

}



};  // Fin del Namespace

#endif

/* Fin Fichero: UnorderedRepeatedPositions.h */
