#ifndef TUMLTest_h//
#define TUMLTest_h//



namespace BIOS {




//class InputTUI;


////////////////////////////

class TUMLTest: public GenomeMLTest 
{

/** This class is used as a generalization of any sample (ML Sample, genetic samples, etc.) so that they all can be divided in order to use tests, classifier or any other measure using different testting comfigurations (cross-validation, holdout, training).
*/



private:


 HapExtractionConfiguration* hapExtractionConfiguration;
 bool useOnlyHetero;


public:

//TUMLTest(char* fileSample, TestModeClass *testMod);
TUMLTest(char* fileSample, TestModeClass *testMod, HapExtractionConfiguration* hapExtractionConfiguration, int totalPermutations, bool useOnlyHetero, bool testModeForInsideMeasure);
~TUMLTest();
virtual GenericCounts* getCounts(GenericSample* ts, int* pos, int size);
virtual GenericSample* getSample(char* file, int* iniPos, int size);
};

} // end namespace
#endif

