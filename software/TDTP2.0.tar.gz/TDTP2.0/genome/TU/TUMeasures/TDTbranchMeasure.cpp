#ifndef __TDTbranchMeasure_cpp__
#define __TDTbranchMeasure_cpp__





namespace BIOS {

	TDTbranchMeasure::TDTbranchMeasure(TUCounts* tuCounts, int k, int side, double minFreq):TUMeasure(tuCounts)
	{

		this->k = k;
		this->tuCounts = tuCounts;
		this->side = side;
// 		this->positions = positions;
// 		this->length = length;
	
	};

	double TDTbranchMeasure::getPVal()
	{

		TDTbranchSimpleMeasure * left = new TDTbranchSimpleMeasure(NULL, k);
		TDTbranchSimpleMeasure * right = new TDTbranchSimpleMeasure(NULL, k);
		//CompositeTUMeasure *c = new CompositeTUMeasure(tuCounts,(TUMeasure*)left,(TUMeasure*) right,(double)10);
		CompositeTUMeasure *c = new CompositeTUMeasure(tuCounts,left,right);
		//left->setTUCounts( tuCounts );
		double p = c->getPVal();

/*		delete left->tuCounts;
		delete right->tuCounts;

		delete left;
		delete right;*/
		delete c;

		return p;

	}
/*
	double TDTbranchMeasure::getMinPVal( HaplotypeTUCountsVector *v , bool toLeft)
	{
		double tdt_z,  tdt_p,  tdt_p_min;

		SetOfPartitions * partitions;
		partitions = SetOfPartitions::splitVector( v, k, toLeft );		

		for (int p=0; p < partitions->size(); p++){
			TDTtable *t = new TDTtable( (*partitions)[p] ) ;
				tdt_z = t->getStatistic();
			delete t;

			tdt_p = pdfTestChiSquare( tdt_z , k - 1); // Get p

			if ( p==0)
				tdt_p_min = tdt_p;

			if ( tdt_p < tdt_p_min)
				tdt_p_min = tdt_p;	


		}

		delete partitions;

		return tdt_p_min;

	}

	double TDTbranchMeasure::getPVal()
	{
		double p_right, p_left;

		HaplotypeTUCountsVector *v_left, *v_right;

		//cout << *v << endl;
//		v->split(v_left, v_right, 5);
		v->chopInHalf( v_left, v_right );
		//cout << *v_left << endl;
		//cout << *v_right << endl;

		if ( side == BOTH_SIDES || side == RIGHT_SIDE){
			// Calcualte p value of the right side
			p_right = getMinPVal(v_right);
		}
	
		if ( side == BOTH_SIDES || side == LEFT_SIDE){
			// Calculate p value of the left side
			p_left = getMinPVal(v_left, true);
		}

		if ( side == BOTH_SIDES){
			// Return product of both sides 
			return p_right * p_left;
		}
		else{
			if ( side == RIGHT_SIDE){ 
				// return right side
				return p_right;
			}
			else{
				// return left side
				return p_left;
			}
		}
				

		HaplotypeTUCountsVector::Delete(v_left);
		HaplotypeTUCountsVector::Delete(v_right);
	
	}
*/

	string TDTbranchMeasure::getName(){
		return string("TDTbranch-"  + tos(k) );
	};


/*_________________________________________________________________*/

  TDTbranchMeasure* TDTbranchMeasure::getNewMeasure(TUCounts* tuCounts, TUCounts** training, TUCounts** test)
{
}
/*_________________________________________________________________*/

		TDTbranchMeasure::TDTbranchMeasure()
{
		};
/*_________________________________________________________________*/

		TDTbranchMeasure::~TDTbranchMeasure(){
  //tuCounts=NULL;
		};
/*_________________________________________________________________*/

		double TDTbranchMeasure::getStatistic(){
			throw NonImplemented("TDTbranchMeasure::getStatistic()");
		};
/*_________________________________________________________________*/

		stringList* TDTbranchMeasure::getHeadFile(){
throw NonImplemented("TDTbranchMeasure::getHeadFile()");
		};
/*_________________________________________________________________*/

		TDTbranchMeasure* TDTbranchMeasure::clone(){
 return new TDTbranchMeasure(*this);
		};

/*_________________________________________________________________*/



/*_________________________________________________________________*/

		TUCounts* TDTbranchMeasure::getTUCounts(){
  return tuCounts;
		};

/*_____________________________________________________________*/


		void TDTbranchMeasure::print(ostream& out){
 throw NonImplemented(" TDTbranchMeasure::print(ostream& out)");
		};

/*_____________________________________________________________*/

  TDTbranchMeasure* TDTbranchMeasure::fromString(string s){throw NonImplemented("TDTbranchMeasure::fromString(string s)");};


};

#endif
