#ifndef GenomeMLTest_cpp//
#define GenomeMLTest_cpp//






//using namespace UTILS;

namespace BIOS {

GenomeMLTest::GenomeMLTest(char* fileSample, TestModeClass *testMod, int totalPermutations, int jointRows, bool testModeForInsideMeasure):GenericMLTest(fileSample, testMod, 3, testModeForInsideMeasure)// 3 is to say that information in each sample file has to be split together in trios (trio samples)
{
try
{
this->totalPermutations=totalPermutations;
}
catch (BasicException& be){be.addMessage("\ncalled from GenomeMLTest::GenomeMLTest(char* fileSample, TestModeClass *testMod, int totalPermutations, int jointRows):GenericMLTest(fileSample, testMod, 3)"); throw;};
}
/*___________________________________________________________ */

int GenomeMLTest::getRealNumberOfAtts()
{
return (totalAtts-7)/2;
} 
/*___________________________________________________________ */

GenomeMLTest::~GenomeMLTest()
{
}

} // end namespace
#endif
