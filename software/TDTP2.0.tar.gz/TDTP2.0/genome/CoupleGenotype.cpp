/* File: CoupleGenotype.h */


#ifndef __CoupleGenotype_cpp__
#define __CoupleGenotype_cpp__

//#include <string.h>
//#include <cstdio>

//#include "../commonc++/vector.h"

//#include "PairGenotype.h"

namespace BIOS {


/**********************************/
/* DEFINITIONS OF THE FUNCTIONS */
/**********************************/


///////////////////
//// public ////////
///////////////////



/*____________________________________________________________ */


CoupleGenotype::CoupleGenotype (PairGenotype * Source): PairGenotype(Source)
{
	MotherGenotype =Source->getFirstGenotype();
	FatherGenotype =Source->getSecondGenotype();
}
/*____________________________________________________________ */

CoupleGenotype::CoupleGenotype (Genotype * Source1, Genotype * Source2): PairGenotype(Source1, Source2)
{
	MotherGenotype =Source1;
	FatherGenotype =Source2;
}
/*____________________________________________________________ */

CoupleGenotype::~CoupleGenotype ()
{
}


};  // End of Namespace

#endif

/* End of file: Genotype.h */




