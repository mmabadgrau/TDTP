/* File: RepeatedPositions.h */

#ifndef __RepeatedPositions_h__
#define __RepeatedPositions_h__

//#include <string>
//#include <math.h>
//#include <cassert>

//#include "fstream.h"

//#include <iostream>//
//#include <cassert>//
//#include <cstring>//
//#include <cstdio>//
//#include <cstdlib>//
//#include <cmath>//
//#include <ctime>//
//#include <malloc.h>//
//#include <fstream>//





//#include "VirtualPositions.cpp"


//using namespace std;
//using namespace string;


namespace BIOS {


/************************/
/* positions DEFINITION */
/************************/

/**
        @memo positions for SNPs

	@doc
        Definition:
        This class is only used to remove repeated positions.

        Memory space: O(TotalSNPs), which TotalSNPs being the number of SNPs in file.

        @author Maria M. Abad
	@version 1.0
*/

	class RepeatedPositions: public VirtualPositions
	 {


		void CheckRepeated();

	//	PosS ReadElement (ifstream * is);

/***************************************************************/
/***     ASSOCIATED FUNCTIONS     ***/
/*********************************************************************/

	void CheckFilename(char* filename);

      /* PUBLIC FUNCTIONS (INTERFACE) */


      public:

		  RepeatedPositions(char* filename);

      /**
         @memo Write a new file with resolved phase.
         @param filename: the filename where results will be written
         Time complexity O(TotalSNPs*Size)

      */

 /**
         @memo Constructor 
         @doc
          Allocate memory an initialize to null.
          Complexity O(1).

      */

        void PrintOrderedUnrepeatedPositions();

		double getPosition(SNPPos SNP);

};  // End of class positions





};  // Fin del Namespace

#endif

/* Fin Fichero: positions.h */
