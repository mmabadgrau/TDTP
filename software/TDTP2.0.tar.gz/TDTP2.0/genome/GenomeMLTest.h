#ifndef GenomeMLTest_h//
#define GenomeMLTest_h//



namespace BIOS {




//class InputTUI;


////////////////////////////

class GenomeMLTest: public GenericMLTest 
{

/** This class is used as a generalization of any sample (ML Sample, genetic samples, etc.) so that they all can be divided in order to use tests, classifier or any other measure using different testting comfigurations (cross-validation, holdout, training).
*/



protected:



int totalPermutations;


virtual int getRealNumberOfAtts();


public:

//GenomeMLTest(char* fileSample, TestModeClass *testMod);
GenomeMLTest(char* fileSample, TestModeClass *testMod, int totalPermutations, int jointRows, bool testModeForInsideMeasure);
~GenomeMLTest();
};

} // end namespace
#endif

