/* File: AmbiguousArray.h */
//prr

#ifndef __GenotypeArray_h__
#define __GenotypeArray_h__
/*
#include <sys/stat.h>
#include <iostream>
#include <cassert>
#include <fstream>
//#include <individual.h>
#include <string>
#include <iostream>
//#include <math.h>
#include <cmath>
#include <stdio.h>//
#include "ExceptionsBasic.h"
#include "basic.h"
#include "list.h"
*/
using namespace std;

namespace BIOS
{

  /////////////////////////////////////////
  class GenotypeArray: public AmbiguousArray //
  {//
 

 allele** allAlleles;





  public:

 int* totalAlleles;

    GenotypeArray();
    GenotypeArray(intList* dimensionList, int iniPos, int* totalAlleles, allele** allAlleles);
      GenotypeArray(GenotypeArray &source);
    ~GenotypeArray();
 allele getAllele(int pos, int val);


 string getHaplotype(long long int key, MultidimensionalEmptyTable<int>* haplotypeTable);
 string getHaplotype(long long int key);

}; // end class
   


  

}
#endif
