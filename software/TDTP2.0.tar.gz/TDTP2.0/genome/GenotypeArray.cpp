/* File: AmbiguousArray.h */
//prr

#ifndef __GenotypeArray_cpp__
#define __GenotypeArray_cpp__
/*
#include <sys/stat.h>
#include <iostream>
#include <cassert>
#include <fstream>
//#include <individual.h>
#include <string>
#include <iostream>
//#include <math.h>
#include <cmath>
#include <stdio.h>//
#include "ExceptionsBasic.h"
#include "basic.h"
#include "list.h"
*/
using namespace std;

namespace BIOS
{

/*_____________________________________________________________*/

GenotypeArray::GenotypeArray():AmbiguousArray(){};

/*_____________________________________________________________*/

    GenotypeArray::GenotypeArray(intList* dimensionList, int iniPos, int* totalAlleles, allele** allAlleles):AmbiguousArray(dimensionList)
{
try
{
this->totalAlleles=new int[dimensionList->size()];
this->allAlleles=new allele*[dimensionList->size()];
for (int i=0; i< dimensionList->size(); i++)
{
this->totalAlleles[i]=totalAlleles[iniPos+i];
this->allAlleles[i]=new allele[this->totalAlleles[i]];
for (int j=0; j< this->totalAlleles[i]; j++)
 this->allAlleles[i][j]=allAlleles[i+iniPos][j];
}
}
catch (BasicException & be) {be.addMessage("\ncalled from GenotypeArray(intList* dimensionList, int iniPos, int* totalAlleles, allele** allAlleles):AmbiguousArray(dimensionList)"); throw;};
};

/*_____________________________________________________________*/

      GenotypeArray::GenotypeArray(GenotypeArray &source): AmbiguousArray(source)
{
this->totalAlleles=new int[dimensionList->size()];
this->allAlleles=new allele*[dimensionList->size()];
for (int i=0; i< dimensionList->size(); i++)
{
this->totalAlleles[i]=source.totalAlleles[i];
this->allAlleles[i]=new allele[this->totalAlleles[i]];
for (int j=0; j< this->totalAlleles[i]; j++)
 this->allAlleles[i][j]=source.allAlleles[i][j];
}
};
/*_____________________________________________________________*/

    GenotypeArray::~GenotypeArray()
{
for (int i=0; i< dimensionList->size(); i++)
zaparr(allAlleles[i]);
zaparr(totalAlleles);
zaparr(allAlleles);
};

/*_____________________________________________________________*/

 allele GenotypeArray::getAllele(int pos, int val)
{
if (abs(val)==5) return (allele)5;
return allAlleles[pos][val];
};
/*_____________________________________________________________*/

 string GenotypeArray::getHaplotype(long long int key)
{
intList* dimList=new intList();
for (int i=0; i<this->totalDimensions; i++)
 dimList->insertElement(totalAlleles[i]);
MultidimensionalEmptyTable<int>* haplotypeTable=new MultidimensionalEmptyTable<int>(dimList);
zap(dimList);
string result=getHaplotype(key, haplotypeTable);
zap(haplotypeTable);
return result;
};
/*_____________________________________________________________*/

 string GenotypeArray::getHaplotype(long long int key, MultidimensionalEmptyTable<int>* haplotypeTable)
{
intList* posList=haplotypeTable->getPosList(key);
string result=string();
for (int i=0; i<this->totalDimensions;i++)
result=result+tos(getAllele(i, posList->getElement(i)));
zap(posList);
return result;
};




  

}
#endif
