
#ifndef __Basic2_cpp__
#define __Basic2_cpp__


#include "Basic2.h"
using namespace std;

namespace BIOS
{


//R/template <class T, template <class T> class Cont> 
template <class Cont, class T> 
bool empty(Container<Cont, T>* lista)
{
   return lista==NULL || lista->size()==0;
}
 /*_______________________________________________________________*/

  longLongList* getIndividualNumbers (char* input)
  {
longLongList* result=new longLongList();
stringList* vals=getStringVector(input, ","), *list2;
char value[100];
for (int i=0;i<vals->size();i++)
{
strcpy(value, vals->getElement(i).c_str());

 list2=getStringVector(value, ":");
if (list2->size()>2){cout << "Error in argument, character ':' is allowed only once\n";end();
}
if (atoi(list2->getFirstElement().c_str())==-1 || atoi(list2->getLastElement().c_str())==-1)
{cout << "Error in argument, -1 is not allowed in an interval\n";end();}
if (atoi(list2->getFirstElement().c_str())>atoi(list2->getLastElement().c_str()))
{cout << "Error in argument, is not a correct interval\n";end();}
if (list2->size()==1)
 result->insertElement(atol(list2->getFirstElement().c_str()));
zap(list2);
 }
return result;
}
 /*_______________________________________________________________*/

  PairOfLongsVector* getConsecutiveNumbers (char* input)
  {
// a list with pairs of values: first and last
PairOfLongsVector* result=new PairOfLongsVector();
stringList* vals=getStringVector(input, ","), *list2;
char value[100];
PairOfLongs *pair;
for (int i=0;i<vals->size();i++)
{
strcpy(value, vals->getElement(i).c_str());

 list2=getStringVector(value, ":");
if (list2->size()>2){cout << "Error in argument, character ':' is allowed only once\n";end();
}
if (atoi(list2->getFirstElement().c_str())==-1 || atoi(list2->getLastElement().c_str())==-1)
{cout << "Error in argument, -1 is not allowed in an interval\n";end();}
if (atoi(list2->getFirstElement().c_str())>atoi(list2->getLastElement().c_str()))
{cout << "Error in argument, is not a correct interval\n";end();}
if (list2->size()==2)
{
 pair=new PairOfLongs(atol(list2->getFirstElement().c_str()), atol(list2->getLastElement().c_str()));
 result->insertElement(pair);
}
zap(list2);
 }
return result;
}

 /*_______________________________________________________________*/

  longLongList* getNumbers (char* input)
  {
longLongList* result=new longLongList();
stringList* vals=getStringVector(input, ","), *list2;
char value[100];
for (int i=0;i<vals->size();i++)
{
strcpy(value, vals->getElement(i).c_str());

 list2=getStringVector(value, ":");
if (list2->size()>2){cout << "Error in argument, character ':' is allowed only once\n";end();
}
if (atoi(list2->getFirstElement().c_str())==-1 || atoi(list2->getLastElement().c_str())==-1)
{cout << "Error in argument, -1 is not allowed in an interval\n";end();}
if (atoi(list2->getFirstElement().c_str())>atoi(list2->getLastElement().c_str()))
{cout << "Error in argument, is not a correct interval\n";end();}
for (long long int j=atol(list2->getFirstElement().c_str());j<=atol(list2->getLastElement().c_str());j++)
{
 result->insertElement(j);
}
zap(list2);
 }
return result;
}


/* _____________________________________________________*/

stringVector*  getStringVector (char * genotypebuf2, const char* tokensSource)
{
if (genotypebuf2==NULL) return NULL;
char *genotypebuf=new char[strlen(genotypebuf2)+1];

stringVector* strList=NULL;
strcpy(genotypebuf, genotypebuf2);
    char tokens[10];

    if (tokensSource==NULL) 
strcpy(tokens, "\t, \n\r");
else
{
    if (strstr(tokensSource, ",\"")!=NULL ||
strstr (tokensSource, "\",")!=NULL)
{
string st=string(tokensSource);
replaceAll(st, string("\","), string("\t"));
replaceAll(st, string(",\""), string("\t"));
strcpy(tokens, st.c_str());
strcpy(genotypebuf, genotypebuf+1);//remove first char (double quote magetrk)
genotypebuf[strlen(genotypebuf)-1]='\0'; // remove last char
string st2=string(genotypebuf);
string oldS=string("\",\""), newS=string("\t");
replaceAll(st2, oldS, newS);
strcpy(genotypebuf,st2.c_str());
}
else strcpy(tokens, tokensSource);
}

    string s;
    char *cad;
    cad = strtok (genotypebuf, tokens);
int i=0;
while (cad!=NULL) // && cad[0]!='\n')// && cad[0]!='\r' && cad[0]!='/')
    {
        if (i==0) strList=new stringVector();
        s=string(cad);

        
        strList->insertElement(s);
        cad = strtok (NULL, tokens);
        i++;
	   };
  zaparr(genotypebuf);
return strList;
  };


/* _____________________________________________________*/

}
// end namespace

//#include "basic.cpp"
#endif


