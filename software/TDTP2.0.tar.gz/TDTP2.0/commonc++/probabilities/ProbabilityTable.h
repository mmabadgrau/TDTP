/* File: ProbabilityTable.h */


#ifndef __ProbabilityTable_h__
#define __ProbabilityTable_h__




using namespace std;


namespace BIOS
{





/*_______________________________________________________________*/

typedef VarsTable<Prob> ProbabilityTable;

 // template<>  ProbabilityTable* ProbabilityTable::marginalize(intList* sourceVarList);
  template<> void ProbabilityTable::set(intSample*  sample, intList *varList, intList* dimensionList, ListOfAttributes* listOfAttributes, floatList* alphaNumerator, float alphaDenominator) throw (OutOfRange<long long int>);


   /*______________________________________________________*/

}
  
#endif
