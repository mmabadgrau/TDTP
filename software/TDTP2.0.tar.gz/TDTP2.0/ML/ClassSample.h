#ifndef ClassSample_h//
#define ClassSample_h//

//#include "../commonc++/list.h"
#include "Sample.h"

namespace BIOS {

typedef unsigned int ClassValue;

////////////////////////////
template <class T> class ClassSample: public list<T> {

private:

//// methods


public:

ClassSample(char texto[128], int classPos);
};//


/*___________________________________________________________________*/

template <class T> ClassSample<T>::ClassSample(char texto[128], int classPos=-1)
{
Sample<T> *sample;
sample=new Sample<T>(texto);

if (classPos==-1) classPos=sample->getElement(sample->getFirst())->size();
this=sample->CopyColumn(classPos);
};

} // end namespace
#endif
