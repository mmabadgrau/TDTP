/* File: ClassClassAttribute.h */

#ifndef __ClassAttribute_h__
#define __ClassAttribute_h__

//#include "../../commonc++/ficheros.h"
//#include "../commonc++/list.h"
//#include "Attribute.cpp"
#include "ListOfAttributes.cpp"

//using namespace UTILS;

namespace BIOS {

 

/************************/
/* ClassAttribute DEFINITION */
/************************/


/**
        @memo ClassAttribute for SNPs

	@doc
   

    @author Maria M. Abad
	@version 1.0
*/

  class ClassAttribute: public Attribute   {

    
  public:

//	  ClassAttribute(Modalidades* modalidades);

        void SetClassAttribute(Attribute *attribute);


	  ClassAttribute(char* texto);

	  ClassAttribute();

//	  ClassAttribute(char nombre[20], list<char[40]>* modalidades, unsigned int tipo_distancia, floatList *puntos);

	  void SetName();


//	  ~ClassAttribute(){};


	  unsigned int GetTotalClasses();


};

};  // Fin del Namespace

#endif

//#include "ClassAttribute.cpp"
/* Fin Fichero: ClassAttribute.h */
