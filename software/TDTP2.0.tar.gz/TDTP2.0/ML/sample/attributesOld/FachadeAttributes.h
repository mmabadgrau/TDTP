#ifndef __FachadeAttributes_h__ 
#define __FachadeAttributes_h__ 

//#include "../probabilities/FachadeProbabilities.h"
#include "Attribute.h"
//#include "ClassAttribute.cpp"
#include "ListOfAttributes.h"
#include "ListOfOrderedAttributes.h"
// end namespace

//#include "Front.cpp"
#endif
