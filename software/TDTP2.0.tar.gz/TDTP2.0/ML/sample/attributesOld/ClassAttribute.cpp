/* File: ClassClassAttribute.cpp */


#ifndef __ClassAttribute_cpp__
#define __ClassAttribute_cpp__



#include "ClassAttribute.h"


//using namespace UTILS;


namespace BIOS {

 

/************************/
/* ClassAttribute DEFINITION */
/************************/


/**
        @memo ClassAttribute 

	@doc
   

    @author Maria M. Abad Grau
	@version 1.0
*/

 

/*_______________________________________________________________*/

ClassAttribute::ClassAttribute():Attribute()
{
attribute.name="class\0";
};
/*____________________________________________________________ */


void ClassAttribute::SetClassAttribute(Attribute *source)
{
   this->Attribute::SetName(source->GetName());
   this->SetModalidades(source->GetModalidades());
   this->SetTipoDistancia(source->GetTipoDistancia());
   this->SetIntervals(source->GetIntervals());
}
/*_______________________________________________________________*/

ClassAttribute::ClassAttribute(char* texto):Attribute()
{
ListOfAttributes *listOfAttributes;
listOfAttributes=new ListOfAttributes(texto, "mas");
Attribute *attribute;
attribute=new Attribute(*listOfAttributes->GetElement(listOfAttributes->GetLast()));
SetClassAttribute(attribute);
delete listOfAttributes;
};
/*_______________________________________________________________*/

void ClassAttribute::SetName()
{
attribute.name="class\0";
};
/*____________________________________________________________*/

unsigned int ClassAttribute::GetTotalClasses()
{
 return GetTotalModalidades();
}
};  // Fin del Namespace

#endif

/* Fin Fichero: ClassAttribute.cpp */
