/* File: ListOfAttributes.h */


#ifndef __ListOfAttributes_h__
#define __ListOfAttributes_h__

//#include <iostream.h>
//#include <cassert>
//#include <fstream.h>
//#include "string.h"

//#include <cstdio>

//#include "../../../commonc++/ListOfPointers.cpp"
//#include "../../../commonc++/ficheros.cpp"
//#include "selection/SelMode.h"

//#include "Sample.h"
//#include "Selection.h"


//using namespace UTILS;


namespace BIOS
{



  /************************/
  /* ListOfAttributes DEFINITION */
  /************************/


  /**
          @memo ListOfAttributes 
   
  	@doc
   
      @author Maria Mar Abad Grau
  	@version 1.0
  */

// template <class T, template <class T> class Cont> class ListOfAttributes: public Set<Attribute, ListOfAttributes>

//template <class T, template <class T> class Cont> class Sample: public ListOfPointers<Container<T, Cont> >

//template <Attribute, ListOfPointers> class ListOfAttributes
// template <class T> class list
//template <class T, template <class T> class Cont> class ListOfAttributes
//template <> Container<Attribute, ListOfPointers> class ListOfAttributes

//template<class T, template<class T> class Cont> class ListOfAttributes<Attribute, ListOfPointers>

  class ListOfAttributes: public Set<Attribute, ListOfPointers>
  {

    // T can be Attribute, InputAttribute or ClassAttribute


    /* PUBLIC FUNCTIONS (INTERFACE) */

  private:
 VerbosityClass verbosity;


    // char* readID(ifstream* is, int i);

   // Set<Attribute, ListOfPointers>* listOfAttributes;
    void setDistance(Attribute* attribute, char* buffer);
    void setName(Attribute* attribute, char* buffer);
    void setModalidades(Attribute* attribute, char* buffer);

    void readAttributesFromData(char* texto);
  
  public:

//floatList* positionsVector;
    int getTotalModalidades(int att);

float getAlphaDenominator(BayesType bayesType, float alpha, intList *varList, intList *conditionalVarList);

//floatList* getAlphaNumerator(BayesType bayesType, float alpha, intList *varList, intList *conditionalVarList, int size);
   virtual Attribute* Pop(){Set<Attribute, ListOfPointers>::Pop();};
     ListOfAttributes* select();
  intList* getSelection();
virtual float getDistance(int att, int att2){};
//vi   void readPositions(char* filename);

   // bool hasID;
    intList* getDiscretePositions(floatList* attPattern);
    floatList* getPositions(stringList* attPattern);
    intList* getDiscretePositions(stringList* attPattern);
  virtual ListOfAttributes* copyAttributesWithPositionsIn(intList* columns, bool isThis=true);

   // bool itHasID(){return hasID;};
    bool allSelected();
    bool isDiscretized();
    template <class T> stringList* getStringPattern(list<T>* attPattern);
    ListOfAttributes(char* texto, VerbosityClass verbosity, int metadata=1);
    ListOfAttributes(ListOfAttributes & listOfAttributes, VerbosityClass verbosity);
    virtual ListOfAttributes* clone();
    ListOfAttributes();
    Set<AttPattern, ListOfPointers>* getSetOfAttPattern(intList* pattern);
    template <class T> bool isMissing(list<T>* l) throw (BadSize);
    virtual ~ListOfAttributes();
    unsigned int GetTotalAttributes();
    template <class T> float getDistance(Container<T, list> * pattern1, Container<T, list> * pattern2, bool noclass, DistanceMethodClass distanceMethodClass, int classPosition);
    list<bool>* setMissingPositions(floatList* pattern);
    unsigned int getTotalSelectedAttributes();
    void ReadAttributes(char* fileMas);
    int GetClassAttribute();
    bool* getSelected();
    bool* getDiscrete();
    bool isContinuous();
    void CrearFicheroMas (char texto[256]);
    void CrearFicheroNombres (char texto[256], int classNumber=-1, bool discretized=false, bool select=false);
    virtual ListOfAttributes* GetDiscreteListOfAttributes();
    virtual void GetDiscreteListOfAttributes(ListOfAttributes* listOfDiscreteAttributes);

    void removeIntervals();
    void removeSelection();
    void selectAll();
    virtual void select(intList* attList);
    intList* getDimensionList(intList* vars);
    virtual float getWeight(int att, int att2){cout <<"Error in ListOfAttributes::getWeight"; end();};
    virtual float getBasicDistance(int att, int att2){cout <<"Error in ListOfAttributes::getBasicDistance, check whether .pos file exists"; end();};
    virtual float getMaxBasicDistance(int att){cout <<"Error in ListOfAttributes::getMaxBasicDistance"; end();};
    virtual Pair<int> getExtremes(int att, float maxDistance){cout <<"Error in ListOfAttributes::getExtremes"; end();};
    virtual string getName();


     };  // End of class ListOfAttributes

/*______________________________________________________*/

    ostream& operator<<(ostream& out, Set<Attribute, ListOfPointers>& lista)
  {
   Set<Attribute, ListOfPointers>::NodePointer p=lista.GetFirst();
   out <<"\n";
 while (p!=NULL)
    {
         out << *lista.GetElement(p);
         p=lista.GetNext(p); 
        out <<"\n";
    }
   
    return out;
  }

}
;  // Fin del Namespace

#endif
//#include "ListOfAttributes.cpp"

/* Fin Fichero: ListOfAttributes.h */
