#ifndef __FachadeProbabilitiesC_h__ 
#define __FachadeProbabilitiesC_h__ 




#include "ProbabilityTable.h"
#include "AlleleProbabilityTable.h"

#include "SampleTable.h"
#include "VarsTable.cpp"
#include "PriorTable.h"
#include "CPT.cpp"


#include "PotentialTable.h"



#include "PotentialList.h"


#include "AlleleCPT.cpp"


#endif
