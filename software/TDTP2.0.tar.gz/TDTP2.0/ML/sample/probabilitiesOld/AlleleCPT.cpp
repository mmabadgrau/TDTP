/* File: AlleleCPT.cpp */


#ifndef __AlleleCPT_cpp__
#define __AlleleCPT_cpp__


#include "AlleleCPT.h"

using namespace std;

namespace BIOS
{


  /*______________________________________________________*/

  AlleleCPT::AlleleCPT(intMLSample*  sample, intList *varList, intList *conditionalVarList, intList* dimensionList, BayesType bayesType, float alpha):CPT()
   {

prior=false;
float alphaDenominator=sample->listOfAttributes->getAlphaDenominator(bayesType, alpha, varList, conditionalVarList); 
AlleleProbabilityTable* pT= new AlleleProbabilityTable(sample, varList, dimensionList, NULL,  alphaDenominator);
if (!empty(conditionalVarList))
{
this->marginals=pT->marginalize(conditionalVarList);
this->conditionals=pT->getConditional(conditionalVarList);
}
else 
{
this->marginals=new ProbabilityTable(*pT);
this->conditionals=NULL;
}
zap(pT);
distr=getProbabilityTable();


  };
}//end namespace



#endif
