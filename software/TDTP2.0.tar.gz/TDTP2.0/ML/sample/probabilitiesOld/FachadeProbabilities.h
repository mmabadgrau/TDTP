#ifndef __FachadeProbabilities_h__ 
#define __FachadeProbabilities_h__ 



#include "VarsTable.h"



//#include "ProbabilityTable.h"

//#include "SampleTable.h"
//#include "VarsTable.cpp"
//#include "PriorTable.h"
#include "CPT.h"


//#include "PotentialTable.h"


//#include "CPT.cpp"


#include "PotentialList.h"
#include "PotentialList.cpp"

//#include "AlleleProbabilityTable.h"
#include "AlleleCPT.h"
//#include "AlleleCPT.cpp"


#endif
