/* File: ProbabilityTable.cpp */


#ifndef __PotentialTable_cpp__
#define __PotentialTable_cpp__


#include "PotentialTable.h"

using namespace std;

namespace BIOS
{


 
/*_______________________________________________________________*/

 basicValue=1;
 
 /*_______________________________________________________________*/

 
  Prob PotentialTable::getProbability(int* values)
  {
   return Prob(this->getValue(values)*(totalCounts+alpha), totalCounts+alpha);
   }
/*_______________________________________________________________*/



}
#endif
