/* File: SampleTable.h */


#ifndef __SampleTable_h__
#define __SampleTable_h__




using namespace std;


namespace BIOS
{

/*_______________________________________________________________*/
/*
  template<> Prob VarsTable<int>::getProbability(int j, bool plain)
  {
cout <<"VarsTable<int>::getProbability(int, bool) not implemented yet";
 end();
}
/*_______________________________________________________________*/
/*
  template<> Prob VarsTable<int>::getProbability(int* value, bool plain)
  {
 cout <<"VarsTable<int>::getProbability not implemented yet";
 end();
   }

/*_______________________________________________________________*/

/*
  template<> void VarsTable<int>::normalize()
  {
  	int total=0;
		for (int i=0;i<size;i++)
		total=total+table[i];
		for (int i=0;i<size;i++)
                if (total==0) table[i]=totalSample/size;
		else if (total!=totalSample)
		{
		cout <<"Error in PotentialTable::normalize(), total is " << total <<" while total sample is " << totalSample;
		end();
		}
	//	else table[i]=table[i]/total;
 // BIOS::normalize(table, size);
   // for (int i=0;i<size;i++)
   //  setValue(i, getValue(i), totalCounts);
}
 /*______________________________________________________*/

  template<> void VarsTable<int>::set(intMLSample*  sample, intList *varList, intList* dimensionList)//,   intSample::NodePointer first, intSample::NodePointer last)
  {
   set(varList, 0);
    intMLSample* filteredSample=sample->copyColumns(varList, false); //copy using the order in the argument

//cout <<"\nBEFORE:" << filteredSample->getSize();
    filteredSample->removeMissingPatterns();

//cout <<"AFTER:" << filteredSample->getSize();
//cout << *varList;
//if (varList->GetFirstElement()==20)
//cout <<"\nvaelist is " << *varList <<" and " << *filteredSample->sample->GetFirstElement();
//end();
    totalSample=filteredSample->getSize();

    if (totalSample==0)
    {
      cout <<"Error when building probability table for vars " << *varList <<". There are not any complete individual";
      end();
    }
    intSample::NodePointer p=filteredSample->sample->GetFirst();
    int* pos;
    intList* pattern;
    initialize(0);

    int i=0;

    while (p!=NULL)
    {
      pattern=filteredSample->sample->GetElement(p);
      pos=pattern->getTable();
      addValue(this->getPos(pos), 1);
      p=filteredSample->sample->GetNext(p);
      zaparr(pos);
      i++;
    }

   zap(filteredSample);
//    this->setTotalCounts();
   //   cout <<"\nll"<<this->print();

    //  cout <<"totalcounts" << this->getTotalCounts();
  };

typedef VarsTable<int> SampleTable;

};

#endif
