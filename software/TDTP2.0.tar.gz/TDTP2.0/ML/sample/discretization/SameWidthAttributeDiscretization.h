#ifndef SameWidthAttributeDiscretization_h //
#define SameWidthAttributeDiscretization_h //

//////

//using namespace UTILS;


namespace BIOS  {





  class SameWidthAttributeDiscretization: public AttributeDiscretization
  {
  protected:

   int totalIntervals;
 
  public:

    //       SameWidthAttributeDiscretization(Classifier<float>* classifier, bool half, bool puntos, bool parada);

    //	SameWidthAttributeDiscretization (){}; //

 void discretization(floatSample::iterator first, floatSample::iterator last)
{
float firstElement=sample->sample->getFirstElement()->getFirstElement();
float width=(sample->sample->getLastElement()->getFirstElement()-firstElement)/(float)totalIntervals;
//end();
for (int i=0; i<totalIntervals-1;i++)
intervals->insertElement(firstElement+width*(i+1));
}

    SameWidthAttributeDiscretization (floatMLSample* sample, int minNumberOfInstancesPerInterval=-1):AttributeDiscretization(sample, minNumberOfInstancesPerInterval)
{
this->totalIntervals=sample->getSize()/this->minNumberOfInstancesPerInterval;
}; //
    floatList* GetIntervals();
    
    ~SameWidthAttributeDiscretization(); //


  };


}
#endif

//#include "SameWidthAttributeDiscretization.cpp"
