#ifndef __FachadeDiscretization_h__ 
#define __FachadeDiscretization_h__ 

#include "DiscModeClass.h"//
#include "Discretization.h"

#include "AttributeDiscretization.h"

#include "SameWidthAttributeDiscretization.h"
#include "SameFrequencyAttributeDiscretization.h"
#include "IterativeDiscretization.h"
#include "EntropyAttributeDiscretization.h"


// end namespace

//#include "Front.cpp"
#endif
