#ifndef __BackDiscretization_h__ 
#define __BackDiscretization_h__ 

#include "Discretization.cpp"


#include "AttributeDiscretization.cpp"
#include "IterativeDiscretization.cpp"


#include "EntropyAttributeDiscretization.cpp"

// end namespace

//#include "Front.cpp"
#endif
