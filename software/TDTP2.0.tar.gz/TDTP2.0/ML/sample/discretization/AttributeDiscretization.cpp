#ifndef AttributeDiscretization_cpp //
#define AttributeDiscretization_cpp //


//#include "AttributeDiscretization.h"
//////

//using namespace UTILS;


namespace BIOS
{


  /*____________________________________________________________________________________________*/

  AttributeDiscretization::AttributeDiscretization(floatMLSample* sample, int minNumberOfInstancesPerInterval)

  {
this->sample=sample;
//this->sample->sample->order(true);
this->sample->sample->sort(true);


    intervals=new Valores();

this->minNumberOfInstancesPerInterval=minNumberOfInstancesPerInterval;
if (minNumberOfInstancesPerInterval==-1)
 this->minNumberOfInstancesPerInterval=5;
if (this->minNumberOfInstancesPerInterval<1)
{
cout <<"Error in IterativeDiscretization::IterativeDiscretization()";
end();
}
  
  }
  /*____________________________________________________________________________________________*/

  AttributeDiscretization::~AttributeDiscretization()
  {
  }
  /*____________________________________________________________________________________________*/

  floatList* AttributeDiscretization::GetIntervals()
  {
    return intervals;
  };

 


 

}

#endif
