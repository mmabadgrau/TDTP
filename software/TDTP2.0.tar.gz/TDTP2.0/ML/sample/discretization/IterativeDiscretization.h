#ifndef IterativeDiscretization_h //
#define IterativeDiscretization_h //

#include<cstdio>//
#include<cstdlib>//
#include<cmath>//
#include<iostream>//
#include<iomanip>//
#include<fstream>//
#include "AttributeDiscretization.cpp"
//////

//using namespace UTILS;


namespace BIOS {

class IterativeDiscretization: public AttributeDiscretization
{
protected:



//Classifier<float>* classifier;
//Valores * intervals;



bool half, puntos, parada;

floatSample::iterator cutPair;
Valores* pattern;

floatSample::iterator getCutPair(floatSample::iterator first, floatSample::iterator last, bool isFirst);

virtual double getJointMeasure(floatSample::iterator first, floatSample::iterator last, floatSample::iterator between){return -1;};

virtual double getMeasure(floatSample::iterator first, floatSample::iterator last){return -1;};


virtual double getMargen2(intMLSample* currentSample, int position){cout <<"IterativeDiscretization::getMargen2, not implemeted"; end();}; ;

virtual double getMargen1(intMLSample* currentSample){cout <<"IterativeDiscretization::getMargen2, not implemeted"; end();}; ;




public:

IterativeDiscretization(floatMLSample* MLSample, bool half, bool puntos, bool parada, int maxNumberOfIntervals=-1);
// IterativeDiscretization(Classifier<float>* classifier):AttributeDiscretization(classifier);

IterativeDiscretization();

void discretization(floatSample::iterator first, floatSample::iterator last);

~IterativeDiscretization(); //


};


}

#endif
