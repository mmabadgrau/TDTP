#ifndef GenericSample_cpp//
#define GenericSample_cpp//






//using namespace UTILS;

namespace BIOS
{

  /*___________________________________________________________ */
  /*

  GenericSample::GenericSample(char* fileSample, TestModeClass *testMod)
  {
  fileName=fileSample;
  this->testMod=testMod;
  wholeSample=NULL;
  }
  /*___________________________________________________________ */

  intSet* GenericSample::selectPositions (int foldSize, Sampling* sampling, int index, int jointRows)
  {
    intSet* result=new intSet();
    int basicPos;
    for (int i=0;i<foldSize;i++)
      for (int j=0; j<jointRows; j++)
        result->insertElement (sampling->Pos[index*foldSize+i]*jointRows+j);
    return result;
  }
  /*___________________________________________________________ */

  int GenericSample::divideSample (string timeMark, char* fileSample, TestModeClass* testMod, int jointRows)
  {
  try
  {
if (testMod->tm==tTraining) return getTotalColumns (fileSample);
    stringList* wholeSample=new stringList (fileSample);
    stringList* newSample, *trainingSample, *testSample;
    char filename[512], filename2[512], block[512], *noFilePath=NULL;
    string extension;
    intSet* indexVector=NULL;
    Sampling *sampling=new Sampling (wholeSample->size() /jointRows, false);
    stringList* row=getStringVector ( (char*) wholeSample->getElement (0).c_str(), " \t,");
    int totalAtts=row->size();
    zap (row);
    int foldSize, resto= (wholeSample->size() /jointRows) %testMod->numberOfFolds;
    if (testMod->numberOfFolds>wholeSample->size() /jointRows && testMod->tm==tCrossValidation)
      throw BadFormat ("error in GenericSample");
    if (testMod->tm==tLeaveOneOut) testMod->numberOfFolds=wholeSample->size() /jointRows;
    for (int i=0;i<testMod->numberOfFolds;i++)
    {
      foldSize= (wholeSample->size() /jointRows) /testMod->numberOfFolds;
      if ( (resto>0) && (i<resto) ) foldSize=foldSize+1;
      if (testMod->tm==tHoldout || testMod->tm==tHalfTraining) foldSize= (wholeSample->size() /jointRows) /2;
      indexVector=selectPositions (foldSize, sampling, i, jointRows);
//cout <<"ind: " << *indexVector <<"\n";
      trainingSample=wholeSample->clone();
      testSample=trainingSample->extractElementsWithPositionsIn (indexVector);
      if (testMod->tm==tHalfTraining)
      {
        zap (testSample);
        testSample=trainingSample->clone();
      }
			char * fileSampleNoPath = removeDir( fileSample);
	changeExtension ( fileSampleNoPath, filename, (timeMark+string ("dat") +tos (i) ).c_str() );
	changeExtension (fileSampleNoPath, filename2, (timeMark+string ("test") +tos (i) ).c_str() );
	
	strcpy (block, fileSampleNoPath);
	strcat (block, "temp");
	strcat (block, timeMark.c_str());

	delete fileSampleNoPath;
  
      time_t start, end;
 
  time (&start);
      
      while (fileExists (filename) || fileExists (filename2) || fileExists (block) )
      {
        time (&end);
      if (difftime(end, start)>300) 
{
      if (fileExists (filename) ) throw AlreadyExist(filename, "int GenericSample::divideSample (char* fileSample, TestModeClass* testMod, int jointRows)");
      if (fileExists (filename2) ) throw AlreadyExist(filename2, "int GenericSample::divideSample (char* fileSample, TestModeClass* testMod, int jointRows)");
      if (fileExists (block) ) throw AlreadyExist(block, "int GenericSample::divideSample (char* fileSample, TestModeClass* testMod, int jointRows)");
      }
      }
      OpenOutput (block, &OutputFile);
      OutputFile.close();
      //if (fileExists(block)) cout << "exists " << block <<"\n";
      for (int k=0;k<2;k++)
      {
        if (k==0) {newSample=trainingSample; OpenOutput (filename, &OutputFile);}
        else {newSample=testSample; OpenOutput (filename2, &OutputFile);};
        newSample->setOutputSeparator ('\n');
        OutputFile << *newSample;
        OutputFile.close();
        zap (newSample);
      }
      unlink (block);
		//unlink (filename);
		//unlink (filename2);
      zap (indexVector);
      zaparr(noFilePath);
    }
    zap (sampling);
    zap (wholeSample);
    return totalAtts;
    }
        catch (BasicException& be) {be.addMessage ("\ncalled from GenericSample::divideSample (char* fileSample, TestModeClass* testMod, int jointRows)");throw;};
  }


  /*___________________________________________________________ */
  /*
  GenericSample::~GenericSample()
  {
  }


  /*___________________________________________________________ */



} // end namespace
#endif
