#ifndef MLSample_h//
#define MLSample_h//


#include "../classifier/AlgTypeClass.h"

namespace BIOS 
{



template <class T> class MLGenotypeSampl: public MLSample<T>

{ 
public:

floatList* positionsVector;

 /*____________________________________________________________________________________ */

  float getSNPDistance(int att, int att2)
  {
if (positionsVector==NULL)
{
cout <<"Error in MLGenotypeSample::getSNPDistance(), distancesVector is null";
end();
}
float distance=1;
if (positionsVector->getElement(att)!=-1 && positionsVector->getElement(att2))!=-1)
{
distance=fabs(positionsVector->getElement(att)-positionsVector->getElement(att2))/(float)100000;
//cout <<"\ndistance " << distance; //positions->getElement(parents[att]->getFirstElement());
distance=(1-exp(-distance));
//cout <<"\nNewdistance " << distance <<"\n";
}
return distance;
}
}

typedef MLPositionSample<int> intMLPositionSample;
typedef MLPositionSample<float> floatMLPositionSample;
typedef MLPositionSample<double> doubleMLPositionSample;
typedef MLPositionSample<string> stringMLPositionSample;

  
} // end namespace
#endif
