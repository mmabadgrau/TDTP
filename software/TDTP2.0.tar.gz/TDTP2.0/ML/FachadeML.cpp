#ifndef __FachadeML_cpp__ 
#define __FachadeML_cpp__ 


#include "../commonc++/Fachade.h"
#include "../genome/FachadeGenoma.h"
#include "FachadeML.h"



#include "../commonc++/Fachade.cpp"
#include "../genome/FachadeGenoma.cpp"



#include "userInterface/FachadeUserInterfaceC.h"

#include "sample/discretization/FachadeDiscretizationC.h"

#include "Graphs/FachadeGraphsC.h"
#include "BN/FachadeBNC.h"


#include "sample/FachadeSampleC.h"
#include "classifier/FachadeClassifierC.h"

#include "sample/selection/FachadeSelection.h"

#include "sample/FachadeSample.h"

//#include "sample/attributes/FachadeAttributesC.h"

#endif
