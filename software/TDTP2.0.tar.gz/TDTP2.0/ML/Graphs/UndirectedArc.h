/* File: UndirectedArc.h */


#ifndef __UndirectedArc_h__
#define __UndirectedArc_h__

using namespace std;

namespace BIOS
{


  /************************/
  /* UndirectedArc DEFINITION */
  /************************/

  /**
          @memo UndirectedArc 
   
  	@doc
   
      @author Maria Mar Abad Grau
  	@version 1.0
  */


  template <class T, class U=int> class UndirectedArc: public Arc<T, U>
  {
 typedef  typename Set<T>::Class::iterator PNode;
 
  public:


	  UndirectedArc():Arc<T, U>(){};


    UndirectedArc(float w, PNode f, PNode s, U* description=NULL):Arc<T, U>(w,f,s, description){};
    UndirectedArc(UndirectedArc<T, U> & a):Arc<T, U>(a){};
 //   UndirectedArc(Arc<T> & a, PNode p1, PNode p2):Arc<T>(a, p1, p2){};
    ~UndirectedArc(){};

    UndirectedArc* clone()
{
return new UndirectedArc(*this);
}

/*
    bool operator<(UndirectedArc & arc)
    {
     return this->weight<arc.weight;
    };

    bool operator>(UndirectedArc & arc)
    {
      return this->weight>arc.weight;
    };
*/

    bool operator==(UndirectedArc & undirectedArc)
    {
return ((undirectedArc.first==this->first && undirectedArc.second==this->second) 
|| (undirectedArc.first==this->second && undirectedArc.second==this->first)) && this->weight==undirectedArc.weight;    };


UndirectedArc* fromString (string source)
{
throw NonImplemented("UndirectedArc::fromString (string source)");
 };


  };  // End of class UndirectedArc


typedef UndirectedArc<Node*, void> SimpleUndirectedArc;

typedef Set<SimpleUndirectedArc*>::Class SetOfSimpleUndirectedArcs;


};  // Fin del Namespace

#endif

/* Fin Fichero: UndirectedArc.h */
