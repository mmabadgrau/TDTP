#ifndef __FachadeGraphs_h__ 
#define __FachadeGraphs_h__ 

#include "Arc.h"
#include "DirectedArc.h"
#include "UndirectedArc.h"
#include "Node.h"
#include "Clique.h"
#include "SeparatorContent.h"

#include "Separator.h"
#include "Graph.h"
#include "UGraph.h"
#include "AcyclicGraph.h"
#include "UTree.h"

#include "DAG.h"
#include "UnchordGraph.h"
#include "Polytree.h"
#include "SingleAncestorGraph.h"
#include "Tree.h"




#include "CompleteGraph.h"

#include "CompleteUG.h"

#include "TriangulatedUG.h"


// end namespace

//#include "Front.cpp"
#endif
