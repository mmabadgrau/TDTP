/* File: CompleteUG.h */


#ifndef __CompleteUG_h__
#define __CompleteUG_h__


namespace BIOS
{
  /************************/
  /* CompleteUG DEFINITION */
  /************************/
  /**
          @memo CompleteUG 
   
  	@doc
   
      @author Maria Mar Abad Grau
  	@version 1.0
  */
// We wanted to use:
//template <class T>  typedef typename CompleteGraph<UndirectedArc, T> CompleteUG<T>;
// As Template Typedef is not allowed we use this trick
template<class T, class U=int>
  struct CompleteUG
  {
    typedef CompleteGraph<UndirectedArc, T, U> Class;
  };

typedef CompleteUG<Node*, int>::Class SimpleCompleteUG;

};  // Fin del Namespace

#endif

/* Fin Fichero: CompleteUG.h */
