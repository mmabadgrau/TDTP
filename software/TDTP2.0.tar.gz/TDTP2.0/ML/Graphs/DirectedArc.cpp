/* File: DirectedArc.h */


#ifndef __DirectedArc_cpp__
#define __DirectedArc_cpp__


using namespace std;


namespace BIOS
{


  /**
          @memo DirectedArc 
   
  	@doc
   
      @author Maria Mar Abad Grau
  	@version 1.0
  */



template <class T, class U>DirectedArc<T,U>::DirectedArc(float w, PNode f, PNode s, U* description):Arc<T, U>(w,f,s, description){this->directed=true;};


    template <class T, class U>DirectedArc<T,U>::DirectedArc(DirectedArc<T, U> & a):Arc<T, U>(a){this->directed=true;};


 template <class T, class U> DirectedArc<T,U>* DirectedArc<T,U>::clone()
{
return new  DirectedArc<T,U>(*this);
}


};  // Fin del Namespace

#endif

/* Fin Fichero: DirectedArc.h */
