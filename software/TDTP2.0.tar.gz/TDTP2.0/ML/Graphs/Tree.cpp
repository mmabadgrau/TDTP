/* File:
Tree.h */


#ifndef __Tree_cpp__
#define __Tree_cpp__

//using namespace UTILS;


namespace BIOS
{
  /************************/
  /* Tree DEFINITION */
  /************************/
  /**
          @memo Tree 
   
  	@doc
   
      @author Maria Mar Abad Grau
  	@version 1.0
  */


 /*______________________________________________________________________________________*/

/*
template<> SingleAncestorGraph<DirectedArc, Clique*, SeparatorContent>::SingleAncestorGraph(SingleAncestorGraph<DirectedArc, Clique*, SeparatorContent> & source): UnchordGraph<DirectedArc, Clique*, SeparatorContent>(source)
  {
this->root=source.root;
nodes=new SetOfCliques(*source.nodes);
  };
*/

 /*______________________________________________________________________________________*/
/*
  template <> SingleAncestorGraph<DirectedArc, Clique*, SeparatorContent>::~SingleAncestorGraph()
  {
zap(nodes);

//for (SingleAncestorGraph<DirectedArc, Clique*, SeparatorContent>::iterator it=begin(); it!=end(); it++)
// zap ();
  };
*/

};  // Fin del Namespace

#endif

/* Fin Fichero: Tree.h */
