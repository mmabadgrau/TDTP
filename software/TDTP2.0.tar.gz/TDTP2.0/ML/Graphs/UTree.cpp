/* File: UTree.cpp */


#ifndef __UTree_cpp__
#define __UTree_cpp__



namespace BIOS
{


  /************************/
  /* UTree DEFINITION */
  /************************/


  /**
          @memo UTree 
   
  	@doc
   
      @author Maria Mar Abad Grau
  	@version 1.0
  */


    /*_____________________________________________________________________________________*/
/*
     template <template<class T> class ULink, class T> template <class V, class W> Tree<V, W>* UTree<ULink, T>::getDirectedTree(U* root)
    {
    cout <<"HH" << this->print();
end();
      Polytree<V,W>* pt=this->getPolytree(), *pt2=NULL;
      pt2=pt->getAsATree(root);
      Tree<V,W> *t=new Tree<V,W>(*pt2, root);
      zap(pt);
      zap(pt2);
      return t;
     };


  /*_____________________________________________________________________________________*/
/*
template <template<class T, class U> class Link, class T, class U> 
Graph<Link, T, U>* AcyclicGraph<Link, T, U>::getDirectedTree(T& root)
    {
cout << "AcyclicGraph<Link, T, U>::getDirectedTree is not defined\n";
};

  /*_____________________________________________________________________________________*/

template <template<class T, class U> class Link, class T, class U> 
template <template<class V, class W> class DLink, class V, class W> 
SingleAncestorGraph<DLink, T, U>* AcyclicGraph<Link, T, U>::getDirectedTree(T& root)
    {
cout << "AcyclicGraph<Link, T, U>::getDirectedTree is not defined\n";
};

     /*_____________________________________________________________________________________*/
/*
//template <template<class T, class U> class Link, class T, class U> 
//template <template<class V, class W> class Link2, class V, class W> 
template < class T, class U>
template < class V, class W>
     typename Tree<T, U>::Class* UTree<T, U>::Class::getDirectedTree(T& root)
    {
      typename Polytree<T, U>::Class* pt=this->getPolytree(), *pt2=NULL;
      pt2=pt->getAsATree(root);
      zap(pt);
      typename Tree<T, U>::Class *t=new Tree<T,U>::Class::SingleAncestorGraph(*pt2, root);
      

      zap(pt2);
      return t;
     };
     /*_____________________________________________________________________________________*/
/*
     template <template<class T> class ULink, class T> template <template<class U> class DLink, class U>  Tree<DLink, T>* UTree<ULink, T>::getDirectedTree(T& root, DLink<U>* typeLink)
    {
      Polytree<DLink, T>* pt=this->getPolytree(), *pt2=NULL;
      pt2=pt->getAsATree(root);
      Tree<DLink,T> *t=new Tree<DLink,U>(*pt2, root);
      
      zap(pt);
      zap(pt2);
      return t;
     };
  
    /*_____________________________________________________________________________________*/
/*
     template <template<class T> class ULink, class T> template <template<class U> class DLink, class U> Polytree<DLink,T>* UTree<ULink, T>::getPolytree(DLink<U>* typeLink)
    {
         Polytree<DLink,T>* polytree=new Polytree<DLink,T>();
	 polytree->nodes=this->nodes;
      ULink<T>* arc=NULL; 
      DLink<T> *newArc=NULL;
      typename UTree<ULink, T>::iterator p=this->getFirst();
      while (p!=this->end())
      {
        arc=getElement(p);
        newArc=new DLink<T>(*arc);
        polytree->insertElement(newArc);
        p=this->getNext(p);
      }
      return polytree;
      
    };
      /*_____________________________________________________________________________________*/
/*
     template <template<class T> class ULink, class T> Polytree<ULink, T>* UTree<ULink, T>::getPolytree()
    {
         Polytree<ULink, T>* polytree=new Polytree<ULink, T>();
	 	 polytree->nodes=this->nodes;
      T* arc=NULL; 
      T *newArc=NULL;
      typename UTree<T, U>::iterator p=this->getFirst();
cout <<"UTREE: " << this->print();
end();
      while (p!=NULL)
      {
        arc=getElement(p);
        newArc=new T(*arc);
	cout <<"Inserting arc" << arc->print();
        polytree->insertElement(newArc);
	zap(newArc);
        p=this->getNext(p);
      }
 end();
 
      return polytree;
      
    };
    
    
    /*_____________________________________________________________________________________*/
/*
     template <template<class T> class ULink, class T> void UTree<ULink, T>::insertElement(T* arc, bool checkIntegrity)
    {
       if ((checkIntegrity && !formALoop(arc)) || !checkIntegrity)
        UGraph<ULink, T>::insertElement(arc);
    };

 */

};  // Fin del Namespace

#endif

/* Fin Fichero: UTree.h */
