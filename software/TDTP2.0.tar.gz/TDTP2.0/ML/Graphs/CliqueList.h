/* File: CliqueList.h */


#ifndef __CliqueList_h__
#define __CliqueList_h__

//#include <iostream.h>
//#include <cassert>
//#include <fstream.h>
//#include "string.h"

//#include <cstdio>

//#include "../../commonc++/rational.h"
//#include "../Attribute.h"
//#include "../Classifier.h"
#include "Graph.h"






//using namespace UTILS;


namespace BIOS {


/************************/
/* CliqueList DEFINITION */
/************************/


/**
        @memo CliqueList 

	@doc

    @author Maria Mar Abad Grau
	@version 1.0
	
	A CliqueList is a graph with at most one directed arc between a pair of nodes. 
*/


	 class CliqueList: public Sample<int> {

	protected:



      public:

		   typename intList::iterator findClique(int i)
	 {
			   return findFinalElement(i);
		   }
/*
		  typename intList::iterator findClique(int i)
	 {
		 intList* clique;
		 int val;
		 this->iterator p=this->getFirst();
		 intList::iterator pE;
		 while (p!=NULL)
		 {
			 clique=getElement(p);
			  pE=	clique->find(i);
		     if (element!=NULL return pE;	
			 p=getNext(p);
		 }
		 return NULL;
	 }

*/
	 }


	
};  // End of class CliqueList



};  // Fin del Namespace

#endif

/* Fin Fichero: CliqueList.h */
