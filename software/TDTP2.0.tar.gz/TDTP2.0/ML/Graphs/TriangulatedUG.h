/* File: UGraph.h */


#ifndef __TriangulatedUG_h__
#define __TriangulatedUG_h__


namespace BIOS
{


  /************************/
  /* UGraph DEFINITION */
  /************************/


  /**
          @memo UGraph 
   
  	@doc
   
      @author Maria Mar Abad Grau
  	@version 1.0
  */

//template < template <class _Compare=std::less<T>, class _Alloc= std::allocator<T> >  > 
//template <template <class T, class _Compare=std::less<T>, class _Alloc= std::allocator<T> >  class T>
//typedef   Graph<UndirectedArc,Node*, void> TriangulatedUG;
  


// We wanted to use:
//template <class T>  typedef typename CompleteGraph<UndirectedArc, T> CompleteUG<T>;
// As Template Typedef is not allowed we use this trick
template<class T, class U>
  struct TriangulatedUGB
  {
    typedef Graph<UndirectedArc, T, U> Class;
  };

typedef TriangulatedUGB<Node*, void>::Class TriangulatedUG;


}
;  // Fin del Namespace

#endif

/* Fin Fichero: UGraph.h */
