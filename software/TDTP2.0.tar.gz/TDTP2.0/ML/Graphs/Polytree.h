/* File: Polytree.h */


#ifndef __Polytree_h__
#define __Polytree_h__





//using namespace UTILS;


namespace BIOS
{


  /************************/
  /* Polytree DEFINITION */
  /************************/


  /**
          @memo Polytree 
   
  	@doc
   
      @author Maria Mar Abad Grau
  	@version 1.0
  */



// We wanted to use:
//template <class T>  typedef typename UnchordedGraph<UndirectedArc, T> Polytree<T>;
// As Template Typedef is not allowed we use this trick
template<class T, class U>
  struct Polytree
  {
    typedef UnchordGraph<UndirectedArc, T, U> Class;
  };



 

    /*__________________________________________________________________*/
/*
    Polytree<DLink, T>* getAsATree(T first)
    {
      Polytree<DLink, T> *pt=new Polytree<DLink, T>(*this);
     // cout <<"\nNew tree" <<print();
      pt->redirectAsTree(first);
      return pt;
    }

    /*__________________________________________________________________*/

/*
    void redirectAsTree(T first, T last)
    {
      typename Polytree<DLink,T>::iterator p=this->getFirst();
      T* arc=NULL;
      typename Set<T>::iterator p1=this->nodes->findElement(first), p2;
      if (last!=NULL) p2=this->nodes->findElement(last);
      while (p!=NULL)
      {
       arc=getElement(p);
       if (arc->hasNode(p1) && (last==NULL || !arc->hasNode(p2)))
        {
          if (arc->getSecond()==p1) 
	  {
	  arc->invertNodes();
	  this->redirectAsTree(this->getSecond(arc), this->getFirst(arc));
	  }
        };
	p=this->getNext(p);
      };
    }

    /*__________________________________________________________________*/
};  // Fin del Namespace

#endif

/* Fin Fichero: Polytree.h */
