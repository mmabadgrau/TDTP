/* File: SeparatorContent.h */


#ifndef __SeparatorContent_h__
#define __SeparatorContent_h__


using namespace std;


namespace BIOS
{


  /************************/
  /* EnrichedUndirectedArc DEFINITION */
  /************************/


  /**
          @memo EnrichedUndirectedArc 
   
  	@doc
   
      @author Maria Mar Abad Grau
  	@version 1.0
  */



class SeparatorContent
  {

 
 protected:

 PotentialList* potential;




  NodeSet* commonNodes;
 

  public:



 
    SeparatorContent(PotentialList* potential, NodeSet* commonNodes);

SeparatorContent();

SeparatorContent(SeparatorContent & other);

  	     ~SeparatorContent();

      NodeSet* getCommonNodes();
// string print()   ;
  	void setPotential(PotentialList* potential)   ;
		PotentialList* getPotential()  ;
   	void setCommonNodes(NodeSet* clique)    ;

	  }
  ;  // End of class SeparatorContent
  ostream& operator<<(ostream& out, SeparatorContent& p);
}
;  // Fin del Namespace

#endif

/* Fin Fichero: SeparatorContent.h */
