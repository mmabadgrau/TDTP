/* File: Clique.h */


#ifndef __Clique_h__
#define __Clique_h__

using namespace std;

namespace BIOS
{

  /************************/
  /* Clique DEFINITION */
  /************************/

  /**
          @memo Clique 
   
  	@doc
   
      @author Maria Mar Abad Grau
  	@version 1.0
  */
  
class PotentialList;

  class Clique: public Set<Node*>::Class
  {

typedef  Set<Node*>::Class::iterator iterator;

  protected:

  PotentialList* potentialList;
 
  public:

    
    Clique();

/*________________________________________________*/

    Clique (Clique& clique);
/*________________________________________________*/

    Clique (NodeSet& group);
   
/*________________________________________________*/
	
    virtual ~Clique();

   
/*________________________________________________*/


   virtual Clique* clone();

/*________________________________________________*/

	void setPotentialList(PotentialList* potentialList);
/*________________________________________________*/
    
	PotentialList* getPotentialList()
   ;
	
 /*
________________________________________________________________________________
____*/
 
 double* getProbs(intList* selectedAtts);
  
Clique* fromString (string source){throw NonImplemented("Clique::fromString (string source)"); };

bool operator==(Clique & clique);


  };  // End of class Clique
  
ostream& operator<<(ostream& out, Clique& p);


};  // Fin del Namespace

#endif

/* Fin Fichero: Clique.h */
