/* File: Separator.cpp */


#ifndef __SeparatorContent_cpp__
#define __SeparatorContent_cpp__


using namespace std;


namespace BIOS
{


   
    	/*________________________________________________*/
/*
 string  Separator::print()
    {
   string result="weight:"+this->Arc<Clique>::print();

     if (this->commonNodes!=NULL)
    result=result+"\nCommon nodes:"+this->commonNodes->print();
    if (this->potential!=NULL)
    result=result+"\npotentials:"+this->potential->print();
 
    return result;
    
    }

    	/*________________________________________________*/

SeparatorContent::SeparatorContent()
{
potential=NULL;
commonNodes=NULL;
}
   	/*________________________________________________*/

SeparatorContent::~SeparatorContent()
{
zap(potential);
zap(commonNodes);
}
    	/*________________________________________________*/

SeparatorContent::SeparatorContent(PotentialList* potential, NodeSet* commonNodes)
{
this->potential=NULL;
this->commonNodes=NULL;
if (potential!=NULL) 
{
this->potential=new PotentialList(*potential);
}
if (commonNodes!=NULL) this->commonNodes=new NodeSet(*commonNodes);
}

    	/*________________________________________________*/

SeparatorContent::SeparatorContent(SeparatorContent & separatorContent)
{
potential=NULL;
commonNodes=NULL;
if (&separatorContent!=NULL)
{
if (separatorContent.potential!=NULL) 
{
this->potential=new PotentialList((PotentialList&)*separatorContent.potential);
}
if (separatorContent.commonNodes)
this->commonNodes=new NodeSet(*separatorContent.commonNodes);
}
}
  	/*________________________________________________*/

void SeparatorContent::setPotential(PotentialList* potential)
    {
if (potential==NULL) throw NullValue("SeparatorContent::setCommonNodes(NodeSet* clique)");
      this->potential=new PotentialList(*potential);
    }
	/*________________________________________________*/
    
PotentialList*  SeparatorContent::getPotential()
    {
      return potential;
    }
    	/*________________________________________________*/

void  SeparatorContent::setCommonNodes(NodeSet* clique)
    {
if (clique==NULL) throw NullValue("SeparatorContent::setCommonNodes(NodeSet* clique)");
      this->commonNodes=new NodeSet(*clique);
    }
	/*________________________________________________*/
    
	 NodeSet* SeparatorContent::getCommonNodes()
    {
      return commonNodes;
    }


/*______________________________________________________*/

  ostream& operator<<(ostream& out, SeparatorContent& p)
{

     if (p.getCommonNodes()!=NULL)
    out << "\nCommon nodes:" << *p.getCommonNodes() <<"\n";
    if (p.getPotential()!=NULL)
    out << "\npotentials:" << *p.getPotential() <<"\n";
 
   
	return out;
}

}
;  // Fin del Namespace

#endif

/* Fin Fichero: Separator.h */
