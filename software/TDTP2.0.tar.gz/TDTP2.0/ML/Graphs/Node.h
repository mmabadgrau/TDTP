/* File: Node.h */


#ifndef __Node_h__
#define __Node_h__




using namespace std;


namespace BIOS
{


  /************************/
  /* Node DEFINITION */
  /************************/


  /**
          @memo Node 
   
  	@doc
   
      @author Maria Mar Abad Grau
  	@version 1.0
  */


  class Node: public Integer
  {
	public:
		Node():Integer(){};
		Node(int position):Integer(position){};
		Node(Node & a):Integer(a){};
    virtual ~Node(){};
 Node* clone() {return new Node(*this);};
  
Node* fromString (string source){throw NonImplemented("Node::fromString (string source)"); };

   bool operator==(const Node & node)
    {
     return node.position==position;
    };


  };  // End of class Node

 /*________________________________________________*/
// template <class T, template <class T> class Cont> class Set: public Container<T, Cont>
//Container<int, list>
// template <class T, template <> > string Set<Node>::print(bool forward)

//  template<> 
/*
string Set<Node>::print(bool forward)
  {
    char line[maxline];
    string result;
    Integer* pattern;
    Set<Node>::iterator p;
	p=this->getFirst();
    strcpy(line, "\0");
    int cont=0;
    while (p!=NULL)
    {
        pattern=getElement(p);
        if (strcmp(line, "\0")==0) sprintf(line, "%s,", pattern->print().c_str());
        else sprintf(line, "%s%s,", line, pattern->print().c_str());
        p=this->getNext(p); 
    }
result=string(line);
    return result;  }
*/

/*______________________________________________________*/

    ostream& operator<<(ostream& out, Node& p)
{

out << p.getValue() <<" ";

 
	return out;
}

/*______________________________________________________*/
/*
  template <class T, template <class T> class Cont>  ostream& operator<<(ostream& out, Container<Node, Cont>& c)
{
typename Container<Node, Cont>::iterator p;
while (p!=NULL)
{
   out << *c.getElement(p) <<" - ";
   p=c.getNext(p);
 
}
 return out;
}
*/
};  // Fin del Namespace

#endif

/* Fin Fichero: Node.h */
