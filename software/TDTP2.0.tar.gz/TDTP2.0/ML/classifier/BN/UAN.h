/* File: UAN.h */


#ifndef __UAN_h__
#define __UAN_h__

//#include <iostream.h>
//#include <cassert>
//#include <fstream.h>
//#include "string.h"

//#include <cstdio>

//#include "../commonc++/list.h"
//#include "Attribute.h"
//#include "Classifier.h"

//#include "../../../commonc++/TextFile.h"

//#include "BN.cpp"





//using namespace UTILS;


namespace BIOS {



/************************/
/* UAN DEFINITION */
/************************/


/**
        @memo UAN 

	@doc

    @author Maria M. Abad
	@version 1.0
*/


	class UAN: public BNC {

	


	      /* PUBLIC FUNCTIONS (INTERFACE) */


      public:


		  UAN(floatMLSample* sample, int classPosition, floatList* algorithm, VerbosityClass *verbosity, LossFunction* lossFunction);

		  void set();

	  
   private:		 
	   
	   char fileModel[256];

	   	   char filename[256];



		  void setParents();
		  
//void set();


};  // End of class UAN


};  // Fin del Namespace

#endif

//#include "UAN.cpp"

/* Fin Fichero: UAN.h */
