#ifndef __FachadeClassifierBN_h__ 
#define __FachadeClassifierBN_h__ 

#include "BNC.h"
#include "NB.h"
#include "TAN.h"
#include "AN.h"
#include "UAN.h"



#endif
