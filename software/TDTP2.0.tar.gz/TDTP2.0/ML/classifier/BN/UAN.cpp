/* File: UAN.cpp */


#ifndef __UAN_cpp__
#define __UAN_cpp__

#include "UAN.h"





//using namespace UTILS;


namespace BIOS {



/************************/
/* UAN DEFINITION */
/************************/


/**
        @memo UAN 

	@doc

    @author M. Mar Abad Grau
	@version 1.0
*/

/*____________________________________________________________________________________ */

void UAN::set()
{
undirectedBN->setJunctionTree();
//NB<T>::setClassifier();
//parents=Initialize(ClassAttribute::GetModalidades(), NULL);
}

/*____________________________________________________________________________________ */

void UAN::setParents()
{
parents=new intList*[sample->listOfAttributes->size()];
for (int i=0; i < totalAttributes; i++)//
parents[i]=new intList();
TextFile* textFile= new TextFile(fileModel);
stringList* line;
bool *definedParents= new bool[totalAttributes];
InitializeList(definedParents, totalAttributes, (bool)false);
int att;
int totalLines=textFile->getTotalLines();
for (int l=0;l<totalLines;l++)
{
 line=textFile->readLine(" \t,\n");
 att=atoi(line->getElement((int)0).c_str());
 if (totalAttributes<=att)
  {
 cout <<"Error in UAN::setParents. File " << fileModel << " contains a reference to the inexistent att  " << att;
 end();
 }
 if (sample->listOfAttributes->getElement(att)->isSelected())
 {
 if (definedParents[att]==true)
 {
 cout <<"Error in UAN::setParents. File " << fileModel << " contains at least two definitions of parents for attribute " << att;
 end();
 }
 for (int i=1;i<line->size();i++)
 parents[att]->insertElement(atoi(line->getElement(i).c_str()));
 definedParents[att]=true;
 }
  zap(line);
}
zap(definedParents);
zap(textFile);
for (int i=0; i < totalAttributes; i++)//
parents[i]->sort(true);
};
/*____________________________________________________________________________________ */

UAN::UAN(floatMLSample* sample, int classPosition, floatList* algorithm, VerbosityClass *verbosity, LossFunction* lossFunction):BNC(sample, classPosition, algorithm, verbosity, lossFunction)
{
changeExtension(sample->filename, fileModel, "mod");
//BNC::set();
 }





};  // Fin del Namespace

#endif

/* Fin Fichero: UAN.h */
