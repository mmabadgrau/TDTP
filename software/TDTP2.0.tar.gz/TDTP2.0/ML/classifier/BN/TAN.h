/* File: TAN.h */


#ifndef __TAN_h__
#define __TAN_h__

//#include <iostream.h>
//#include <cassert>
//#include <fstream.h>
//#include "string.h"

//#include <cstdio>
/*
#include "../../../commonc++/Set.h"
#include "../../Graphs/Tree.h"
#include "../../Graphs/CompleteUG.h"
*/
//#include "BN.h"




//using namespace UTILS;


namespace BIOS
{



  /************************/
  /* TAN DEFINITION */
  /************************/


  /**
          @memo TAN 
   
  	@doc
   
      @author Maria Mar Abad Grau
  	@version 1.0
  */


  class TAN: public BNC
  {


  private:


   void setParents2();
    void setParents(doubleList*);

    NodeSet::iterator getSecondParent(NodeSet::iterator it);

    /* PUBLIC FUNCTIONS (INTERFACE) */

  protected:

    TANG* parentalTree;

		NodeSet* orderedAttributes;


    void setMutualConditionalInformation();

    SimpleCompleteUG* getMutualConditionalInformation();

    void setParentalTree();
    
       void setParents();

void getOrder(UTree<Node*, void>* mWST);


  public:


    TAN(floatMLSample* sample, int classPosition, floatList* algorithm, VerbosityClass *verbosity, LossFunction* lossFunction);

    TAN();
    
    virtual void set();


    void set(floatMLSample* sample, int classPosition, floatList* algorithm);


    string print();

 
    ~TAN();





  }
  ;  // End of class TAN




}
;  // Fin del Namespace

#endif

//#include "TAN.cpp"
/* Fin Fichero: TAN.h */
