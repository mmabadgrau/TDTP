/* File: NB.cpp */


#ifndef __NB_cpp__
#define __NB_cpp__

#include "NB.h"





//using namespace UTILS;


namespace BIOS {



/************************/
/* NB DEFINITION */
/************************/


/**
        @memo NB 

	@doc

    @author M. Mar Abad Grau
	@version 1.0
*/





/*____________________________________________________________________________________ */

void NB::setParents()
{

if (parents==NULL)
{
parents=new intList*[totalAttributes];
for (int cont=0; cont < totalAttributes; cont++)//
{
parents[cont]=new intList();
if (cont!=classPosition)
if (sample->listOfAttributes->getElement(cont)->isSelected())
parents[cont]->insertElement(classPosition);
//cout <<"\npar2:" << parents[cont]->getElement((int)0);
}
}
};
/*____________________________________________________________________________________ */

void NB::setParents(floatList* algList)
{
if (algList==NULL || algList->size()<1) throw BadFormat("GBN::setParents(AlgTypeClass");
if (parents==NULL)
{

parents=new intList*[totalAttributes];
intList* varList;
Vector<Pair<intList*>* >::Class* listOfParticipants=NULL;
HeteroPair<float, int>* currentP, *newP;
BayesScore<int>* bayesScore=NULL;
MeasureCompetition<BayesScore, int> * measureCompetition=NULL;
BayesType bayesType=MLE;
float alpha=0;
int maxNumberOfParents;
bool better;
switch ((AlgTypeBN) algList->getFirstElement())
{
case K2: 
if (algList->size()>=2 && algList->getElement(1)>0) maxNumberOfParents=(int)algList->getElement(1); else maxNumberOfParents=totalAttributes-1;
if (algList->size()>=3) bayesType=(BayesType)algList->getElement(2);
if (algList->size()>=4) alpha=(BayesType)algList->getElement(3);

varList=new intList();
for (int cont=0; cont < totalAttributes; cont++)//
{
parents[cont]=new intList();
if (cont!=classPosition)
if (sample->listOfAttributes->getElement(cont)->isSelected())
better=true;
bayesScore=new BayesScore<int>(bayesType, alpha);
varList->insertElement(cont);
currentP=new HeteroPair<float, int>(bayesScore->DependenceMeasure<int>::getMeasure(discreteSample->sample, discreteSample->listOfAttributes, varList, NULL), -1);
while (better && parents[cont]->size()<min(maxNumberOfParents, cont))
{
measureCompetition=new MeasureCompetition<BayesScore, int >(listOfParticipants, bayesType, alpha);
measureCompetition->makeRound(discreteSample->sample, discreteSample->listOfAttributes);
newP=measureCompetition->getWinner();
if (newP->first()<=currentP->first()) better=false;
else 
{
parents[cont]->insertElement(newP->second());
zap(currentP);
currentP=new HeteroPair<float, int>(*newP);
}
zap(measureCompetition);
}
zap(bayesScore);
varList->pop();
}
zap(varList);
break;
default: break;
};
};
};
/*____________________________________________________________________________________ */

NB::~NB()
{
};


/*____________________________________________________________________________________ */

NB::NB()
{

//NB<T>::setClassifier();
//parents=Initialize(ClassAttribute::GetModalidades(), NULL);
}
/*____________________________________________________________________________________ */

void NB::set()
{

setParents();
GBN::set();
 if (GBN::verbosity!=NULL && GBN::verbosity->verbosityR.parameters) printProbabilityTables(); 
//printProbabilityTables();
if (!directMethod) 
{
//cout <<"classpos:" << classPosition <<"\n";
//undirectedBN->setJunctionTree();
undirectedBN->setJunctionTreeNB(classPosition);
}
//NB<T>::setClassifier();
//parents=Initialize(ClassAttribute::GetModalidades(), NULL);
}

/*____________________________________________________________________________________ */
/*
  void NB::setUndirectedBN()
  {
    undirectedBN=new UndirectedBN(discreteSample, alpha, parents, probTables);
  }
/*____________________________________________________________________________________ */

NB::NB(floatMLSample* sample, int classPosition, floatList* algorithm, VerbosityClass*verbosity, LossFunction* lossFunction):BNC(sample, classPosition, algorithm, verbosity, lossFunction)
{
	set();

//cout <<"taotalselecte" << sample->listOfAttributes->getTotalSelectedAttributes();

//printParents();
//exit(0);
   // 

 }

/*___________________________________________________________ */

char* NB::print()
{
sprintf(line, "NB with alpha=%0.2f", alpha);
return line;
}



};  // Fin del Namespace

#endif

/* Fin Fichero: NB.h */
