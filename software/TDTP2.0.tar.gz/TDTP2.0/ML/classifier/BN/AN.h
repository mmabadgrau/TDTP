/* File: AN.h */


#ifndef __AN_h__
#define __AN_h__

//#include <iostream.h>
//#include <cassert>
//#include <fstream.h>
//#include "string.h"

//#include "TAN.h"




using namespace std;


namespace BIOS {



/************************/
/* AN DEFINITION */
/************************/


/**
        @memo AN 

	@doc

    @author Maria Mar Abad Grau
	@version 1.0
*/


	class AN: public TAN {

	private:
	
	SimpleDAG* parentalDAG;


	MeasureType stopCriterion;
	  
	void addParents(int);
	
	bool removeTANParent(int);

	int chooseOptimalAttribute(int position, float &originalAccuracy);

      	void setParents();
      
	void set();

	float getError(int attribute, int newParent=-1, bool withClass=true);

    
	/* PUBLIC FUNCTIONS (INTERFACE) */

     protected:
        
      void setMutualConditionalInformation();
		 
      SimpleCompleteUG* getMutualConditionalInformation();

      public:
 

 
      AN(floatMLSample* sample, int classPosition, floatList* algorithm, VerbosityClass* verbosity, LossFunction* lossFunction);

	  AN();

	//  void set();
     
	  void setParentalDAG();
	  
  	  ~AN();
	  
	  char* print();
		  
		   
		  	


};  // End of class AN




};  // Fin del Namespace

#endif

//#include "AN.cpp"
/* Fin Fichero: AN.h */
