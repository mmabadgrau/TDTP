/* File: EM.cpp */

#ifndef __EM_cpp__
#define __EM_cpp__


#include "EM.h"

//using namespace UTILS;


namespace BIOS {




/*____________________________________________________________________________________ */



/*____________________________________________________________________________________ */

EM::EM(floatMLSample* sample, int att, floatList* parameterList, VerbosityClass* verbosity, LossFunction* lossFunction, int interations):Classifier(sample, att, parameterList, verbosity, lossFunction)
{	
frequencyTable=NULL;
MLEstimations=NULL;
this->iterations=iterations;
};

/*____________________________________________________________________________________ */

EM::EM():Classifier()
{
iterations=1000;
//weightsVector=NULL;
};

/*____________________________________________________________________________________ */

EM::~EM()
{
//zap(weightsVector);
};
/*____________________________________________________________________________________ */


void EM::setMLEstimations()
{
cout <<"Error in EM::setMLEstimations(), not implemented yet";
end();
}
/*____________________________________________________________________________________ */

double* EM::getFrequencies()
{
cout <<"Error in EM::getFrequencies(), not implemented yet";
end();
}

/*____________________________________________________________________________________ */

void EM::runEMAlgorithm(int it)
{
setExpectation();
maximize();
if (it<iterations) runEMAlgorithm(it+1);
}
 /*___________________________________________________________ */

double* EM::GetClassFrequencies(floatList* targetInputPattern)
{
reducedSample=sample.getCompatibleSample(targetInputFile);
setMLEstimations();
runEMAlgorithm();
return getFrequencies();
};





};  // Fin del Namespace

#endif

/* Fin Fichero: EM.cpp */
