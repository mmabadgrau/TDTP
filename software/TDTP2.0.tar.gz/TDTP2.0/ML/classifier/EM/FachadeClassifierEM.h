#ifndef __FachadeClassifierEM_h__ 
#define __FachadeClassifierEM_h__ 



#include "EMClassifier.h"


#include "EMClassifier.cpp"
//#include "DiscreteEMClassifier.cpp"
//#include "EMGenotypes.cpp"

#endif
