#ifndef __FachadeClassifierC_h__ 
#define __FachadeClassifierC_h__ 


#include "BN/FachadeClassifierBNC.h"
#include "c45/C45.cpp"
#include "knn/FachadeClassifierknnC.h"
#include "ClassifierTest.cpp"
#include "Classifier.cpp"
#include "TestModeClass.cpp"
#endif
