#ifndef Pattern_h//
#define Pattern_h//



#include "../commonc++/list.h"
#include "ListOfAttributes.h"

namespace BIOS
{



/************************/
/* ListOfPatterns DEFINITION */
/************************/


/**
        @memo Pattern 

	@doc

    @author Maria M. Abad
	@version 1.0
*/


template<class T> class Pattern: public list<T>
{



public:

Pattern():list<T>()
{};

char* Print();//ListOfAttributes * listOfAttributes, bool *seleccionados);

template <class U> char* Print (list<U> * AttList, bool *seleccionados);


};

/*____________________________________________________________ */


template <class T> template<class U> char* Pattern<T>::Print (list<U> * AttList, bool *seleccionados=NULL)
{
char* line, *stringValue;
U attribute;
stringValue=new char[10];
int TotalValues=Pattern::size();
if ((line=new char [TotalValues*10])==NULL)
	throw NoMemory();

strcpy(line, "\0");
typename Pattern::iterator pp=Pattern::getFirst();
typename list<U>::iterator pA=AttList->getFirst();
float element;
int cont=0;
while (pp!=NULL && pA!=NULL)
{
 if (seleccionados==NULL || seleccionados[cont]==true)
 { 
 element=getElement(pp);
 attribute=AttList->getElement(pA);
 strcpy(stringValue, attribute.GetStringValue(element));
 sprintf(line, "%s%s, ",line, stringValue);
 }
 pp=getNext(pp);
 pA=AttList->getNext(pA);
 cont++;
}

return line;
}


/*
template<class T> char* Pattern<T>::Print (ListOfAttributes * listOfAttributes, bool *seleccionados=NULL)
{
char* line, *stringValue;
InputAttribute attribute;
stringValue=new char[10];
int TotalValues=size();
if ((line=new char [TotalValues*10])==NULL)
	throw NoMemory();

strcpy(line, "\0");
iterator pp=getFirst();
ListOfAttributes::iterator pA=listOfAttributes->getFirst();
float element;
int cont=0;
while (pp!=NULL && pA!=NULL)
{
 if (seleccionados==NULL || seleccionados[cont]==true)
 { 
 element=floatList::getElement(pp);
 attribute=listOfAttributes->getElement(pA);
 strcpy(stringValue, attribute.GetStringValue(element));
 sprintf(line, "%s%s, ",line, stringValue);
 }
 pp=getNext(pp);
 pA=listOfAttributes->getNext(pA);
 cont++;
}

return line;
}
*/
}// end namespace
#endif
