/* File: Classifier.cpp */


#ifndef __Classifier_cpp__
#define __Classifier_cpp__


#include "Classifier.h"//



namespace BIOS
{

  /*__________________________________________________________________________________ */

  Classifier::Classifier()
  {
//distancesVector=NULL;
  };
/*__________________________________________________________________________________ */
/*
 void Classifier::extractDistancesVector(int firstPosition)
{
 if (parameterList->size()!=(firstPosition+totalAttributes))
{
cout <<"Error in Classifier::extractDistancesVector(algorithm, fisrtPosition), physical positions not found in " << *parameterList << "\ntotal is : " << parameterList->size() << " and the total number of attributes is: " << totalAttributes;
end();
}
else 
{
distancesVector=new floatList();
for (int i=0;i<totalAttributes;i++)
distancesVector->insertElement(parameterList->getElement(i+firstPosition));
}

}
   /*__________________________________________________________________________________ */

  void Classifier::set(floatMLSample* sample, int classPosition, floatList* parameterList, VerbosityClass *verbosity, LossFunction* lossFunction)
  {
this->verbosity=verbosity;
this->parameterList=parameterList;
this->sample=new floatMLSample(*sample);

this->classPosition=classPosition;


totalClasses=this->sample->listOfAttributes->getElement(classPosition)->getTotalModalidades();
classAttribute=this->sample->listOfAttributes->getElement(classPosition);

floatList * inputPattern;

if (lossFunction==NULL) 
this->lossFunction=new LossFunction(totalClasses);
else this->lossFunction=new LossFunction(*lossFunction);


    totalAttributes=this->sample->listOfAttributes->GetTotalAttributes();

    totalSelectedAttributes=this->sample->listOfAttributes->getTotalSelectedAttributes();
     try
    {
      inputPattern=(floatList *)this->sample->sample->getElement(sample->sample->getFirst());   

      if (totalAttributes!=inputPattern->size())
           throw BadSize();
	     }
    catch (BadSize bs) {bs.PrintMessage("Classifier::set", totalAttributes, inputPattern->size()); }
this->sample->removePatternsWithMissingAttribute(classPosition);
    };
 
    
    /*__________________________________________________________________________________ */

  Classifier::Classifier(floatMLSample* sample, int classPosition, floatList* parameterList, VerbosityClass *verbosity, LossFunction* lossFunction)
  {
      set(sample, classPosition, parameterList, verbosity, lossFunction);
    }
   
  /*__________________________________________________________________________________ */

  Classifier::~Classifier()
  {
  zap(sample);
zap(lossFunction);
  };
  /*__________________________________________________________________________________ */

  floatMLSample* Classifier::GetSample()
  {
    return (sample);
  };
  /*__________________________________________________________________________________ */

  ListOfAttributes* Classifier::GetAttributeList()
  {
    return (sample->listOfAttributes);
  };
  /*__________________________________________________________________________________ */
/*
  int Classifier::GetClassAttribute()
  {
    return (listOfAttributes->GetClassAttribute());
  };
  /*__________________________________________________________________________________ */
/*
  ClassAttribute* Classifier::GetClassAttributePointer()
  {
    return (classAttribute);
  };

/*__________________________________________________________________________________ */
/*
 int Classifier::GetTrainingMatches()
 {
}


    /*__________________________________________________________________________________ */
/*
  int Classifier::GetTrainingMatches()
  {
    //return the number of correctly classified training patterns

    floatList *inputPattern;
    int classValue;
    floatSample::iterator p=sample->sample->getFirst();
    unsigned int attNumber, i=0;
    while (p!=NULL)
    {
      inputPattern=(floatList *)sample->sample->getElement(p);
      classValue=(int)inputPattern->Pop();
      if (classValue===getDecission(inputPattern)) i++;
      inputPattern->insertElement((float)classValue);
      p=sample->sample->getNext(p);
    }
    return (i);
  };

  /*__________________________________________________________________________________ */
/*
  int Classifier::GetMatches(const floatMLSample* const targetSampleS)
  {
//cout << "target is:" << targetSample->getSize();
    //return the number of correctly classified patterns in the sample
floatMLSample *targetSample=new floatMLSample(*targetSampleS);
    floatList *pattern=NULL;
    int classValue, estimatedClassValue;
    floatSample::iterator p=targetSample->sample->getFirst();
    Attribute *classAttribute=sample->listOfAttributes->getElement(classPosition);
    if (verbosity->getElement(( int)0)>=3)
    {
     cout <<"\n";
         for (int i=0;i<classAttribute->GetTotalModalidades();i++)
            cout <<"\tp(" << classAttribute->GetName()<<"=" << classAttribute->GetStringValue(i)<<")\t";
     cout <<"\n";
     }
int j=0, i=0;
    while (p!=NULL)
    {

      pattern=targetSample->sample->getElement(p);
      classValue=(int)pattern->removeNode(classPosition);

if (classAttribute->isMissing(classValue))
{
cout << "Error in Classifier::";
end();
}

if (verbosity->getElement(( int)0)>=3)
cout << "\n" << j <<": ";

estimatedClassValue==getDecission(pattern);

if (verbosity->getElement(( int)0)>=3)
cout << "\t"  << estimatedClassValue <<" [" << classValue << "]";

  if (classValue!=estimatedClassValue) 
{
//cout << "\t" << j << ": " << estimatedClassValue <<" [" << classValue << "]";
//if (verbosity->getElement(( int)0)>=3)
//cout <<" error";
}
else i++;

    pattern->insertElementAtPos((float)classValue, classPosition);
    p=targetSample->sample->getNext(p);   
j++;
      }
zap(targetSample);
     return (i);
  }
/*__________________________________________________________________________________ */

  BidimensionalTable<float>* Classifier::getDecisionCounts(floatMLSample* targetSample, int stochastic)
  {

    floatList *pattern=NULL;
    int classValue, estimatedClassValue=0;
    floatSample::iterator p=targetSample->sample->getFirst();
    if (verbosity!=NULL && verbosity->verbosityR.individualAccuracy)
    {
     cout <<"\n";
         for (int i=0;i<totalClasses;i++)
            cout <<"p(" << classAttribute->getName()<<"=" << classAttribute->getStringValue(i)<<")\t";
cout <<"p(doubt)\t";
     cout <<"\n";
     }
int j=0;
int pos[2];

BidimensionalTable<float>* decisionCounts=new BidimensionalTable<float>(totalClasses, totalClasses+1);

decisionCounts->initialize();
    while (p!=targetSample->sample->end())
    {
if (verbosity!=NULL && verbosity->verbosityR.progress) 
if (j%100==0) cout << "\nItem " << j+1 << " of " << targetSample->sample->size();
      pattern=targetSample->sample->getElement(p);
      classValue=(int)pattern->getElement(classPosition);

      pattern->removeNode(classPosition);
if (classAttribute->isMissing(classValue)) throw MissingValue("Classifier::getDecisionCounts");
//cout <<"\nsizeb is:" << pattern->size();


estimatedClassValue=getDecision(pattern, stochastic);

if (verbosity!=NULL && verbosity->verbosityR.individualAccuracy)
cout  << j << ": " << estimatedClassValue <<" [" << classValue << "]\n";
pos[0]=classValue;
pos[1]=estimatedClassValue;
decisionCounts->addValue(pos[0], pos[1], 1);

    pattern->insertElementAtPos((float)classValue, classPosition);
    p=targetSample->sample->getNext(p);   
j++;
      }
     return (decisionCounts);
  }

/*__________________________________________________________________________________ */

int Classifier::getDecision (floatList* targetInputPattern, int stochastic) 
{
try
{
double* classFrequencies=getClassFrequencies(targetInputPattern);

if (sum(classFrequencies, totalClasses)!=0)
normalize(classFrequencies, totalClasses);
if (1==0)
if (verbosity!=NULL && Classifier::verbosity->verbosityR.individualAccuracy)
for (int i=0;i<totalClasses;i++)
{
cout << classFrequencies[i] <<"\t" ;
if (sum(classFrequencies, totalClasses)==0) cout <<"\terror: all zero\n";
}
int decision=0;

decision=getDecision(classFrequencies, stochastic);
zaparr(classFrequencies);
return decision;
}
catch (BadFormat& bf){bf.addMessage("\ncalled fromClassifier::getDecision (floatList* ta..."); throw;};
}
/*__________________________________________________________________________________ */

int Classifier::getDecision (double* probs, int stochastic) 
{
double *copyProbs=new double[totalClasses];
for (int i=0;i<totalClasses;i++)
{
 copyProbs[i]=probs[i];
}
Multinomial* multinomial=NULL;
intList* ties=new intList();
if (verbosity!=NULL && Classifier::verbosity->verbosityR.individualAccuracy)
{
 cout << "[";
  for (int i=0;i<=totalClasses;i++)
{
printf("%0.8f", copyProbs[i]);
if (i<totalClasses) cout <<"\t "; else cout << "]\t";
}
}
     int maxClass;
	double max, secondMax=-1;
	bool tie=true;
        maxClass=GetMaxPos(copyProbs, totalClasses);
	max=copyProbs[maxClass];
	ties->insertElement(maxClass);
 	do
	{
	copyProbs[maxClass]=-1;
	maxClass=GetMaxPos(copyProbs, totalClasses);
        if(secondMax==-1) secondMax=copyProbs[maxClass];
	if (copyProbs[maxClass]==max) ties->insertElement(maxClass);
   	else tie=false;
	}
    while (tie==true);
  
    int result=ties->getElement((int) rand()%ties->size());
   zap(ties);
if ((max-secondMax)<lossFunction->decisionThreshold) {zaparr(copyProbs); return totalClasses;}
else if (stochastic) 
{
multinomial=new Multinomial(1, totalClasses, probs);
result=multinomial->getNextValue();
zap(multinomial);
}
zaparr(copyProbs);
return result;
};
/*___________________________________________________________ */

floatList* Classifier::completeMissing(floatMLSample* targetSample, int stochastic)
{
floatList* completedClassValues=new floatList();
floatSample::iterator p;
floatList* pattern;
p=targetSample->sample->getFirst();
int classValue;
//cout << "stochastic:" << stochastic;
   while (p!=targetSample->sample->end())
    {
      pattern=targetSample->sample->getElement(p);
      classValue=(int)pattern->getElement(classPosition);
			pattern->removeNode(classPosition);
if (classAttribute->isMissing(classValue)) 
completedClassValues->insertElement((float)getDecision(pattern, stochastic));
else completedClassValues->insertElement((float)classValue);
  pattern->insertElementAtPos((float)classValue, classPosition);
p=targetSample->sample->getNext(p);   
        }
return completedClassValues;
}
/*__________________________________________________________________________________ */

  int* Classifier::getInferedMissing(floatMLSample* targetSample, int stochastic)
  {
int* allFrequencies=Initialize(totalClasses, 0);
floatList* complete=completeMissing(targetSample, stochastic);

floatList::iterator p=complete->getFirst();

while (p!=complete->end())
    {
      allFrequencies[(int)complete->getElement(p)]++;
p=complete->getNext(p);   
        }
zap(complete);
return allFrequencies;

}

/*___________________________________________________________ */

ClassificationResults* Classifier::getAccuracy(floatMLSample* testSample, int stochastic)
{
// originalSample is the one used to build the classifier without missing class values removed
int* allFrequencies=NULL, *knownFrequencies=NULL;
float size=testSample->getSize();
//cout <<"threshold:" << lossFunction->decisionThreshold;
//cout <<*decisionCounts;
double lost=0, freq;
float uncovered=0;
floatSample::iterator p;
floatList* pattern;
ClassificationResults *results=new ClassificationResults();
int totalMissing=0, classValue;
results->set.true_PredictedTable=getDecisionCounts(testSample, stochastic);
for (int i=0;i<results->set.true_PredictedTable->getSize();i++)
{
lost=lost+results->set.true_PredictedTable->MultidimensionalTable<float>::getValue(i)*lossFunction->lossFunctionTable->MultidimensionalTable<float>::getValue(i);
if ((i+1)%(totalClasses+1)==0)
uncovered=uncovered+results->set.true_PredictedTable->MultidimensionalTable<float>::getValue(i);
//size=size-decisionCounts->getValue(i);
}
MIDistances* mIDistances=NULL;
float mean=((float)size-lost)/(float)size;
results->set.averageAccuracy=mean;
//cout <<"accuracy first is:" << accuracy.First;
results->set.sd=getAccuraciesSampleSD((int)(size-lost), (int)size);
results->set.totalClasses=totalClasses;
//if (results.true_PredictedTable!=NULL)
//cout << *results.true_PredictedTable;
//ClassificationResults* r=new ClassificationResults(results);
return results;
}
};  // Fin del Namespace


#endif



/* Fin Fichero: Classifier.cpp */
