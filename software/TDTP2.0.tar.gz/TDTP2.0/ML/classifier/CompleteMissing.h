#ifndef CompleteMissing_h//
#define CompleteMissing_h//



#include <fstream>
#include <string>
#include <stdio.h>//




namespace BIOS {





////////////////////////////
class CompleteMissing {


/** 
*/
public:

floatSample* completedSample;

CompleteMissing(floatSample* currentSample)
{
this->completedSample=new floatSample(*currentSample);
};
/*_____________________________________________________________*/

void completeAttribute(int attPosition, floatList* completedValues)
{
floatSample::iterator p=completedSample->getFirst();
floatList::iterator p2=completedValues->getFirst();
floatList* pattern;
    while (p!=completedSample->end())
    {
      pattern=completedSample->getElement(p);
      pattern->changeElementAtPos(completedValues->getElement(p2), attPosition);
      p=completedSample->getNext(p);   
      p2=completedValues->getNext(p2);
     }
completedSample->getFirstElement()->size();
}

~CompleteMissing()
{
zap(completedSample);
};
};

} // end namespace
#endif

