/* File: prune.h */


#ifndef __prune_h__
#define __prune_h__

#include "defns.h"// C4.5//
#include "types.h"//
#include "c4.5.h"//
#include "build.cpp"//


namespace BIOS {
/*************************************************************************/// 
/*									 */// 
/*	Prune a decision tree and predict its error rate		 */// 
/*	------------------------------------------------		 */// 
/*									 */// 
/*************************************************************************/// 
// 
// 
// 
// 
extern ItemCount	*Weight;// 
// 
Setc45	*PossibleValues=Nil;// 
Boolean	Changed;// 
// 
#define LocalVerbosity(x) if (Sh >= 0 && VERBOSITY >= x)// 
#define Intab(x)     Indent(x, (String)"| ")// 
// 
/*************************************************************************/// 
/*									 */// 
/*	Remove unnecessary subset tests on missing values		 */// 
/*									 */// 
/*************************************************************************/// 
// 
// 
    void CheckPossibleValues(TreeC45 T);

// 
/*************************************************************************/// 
/*									 */// 
/*  Prune tree T, returning true if tree has been modified		 */// 
/*									 */// 
/*************************************************************************/// 
// 
// 
Boolean Prune(TreeC45 T);

// 
// 
// 
// 
/*************************************************************************/// 
/*									 */// 
/*	Estimate the errors in a given subtree				 */// 
/*									 */// 
/*************************************************************************/// 
// 
// 
float EstimateErrors(TreeC45 T, ItemNo Fp, ItemNo Lp, short Sh, Boolean UpdateTree);

}

#endif





