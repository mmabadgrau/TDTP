/* File: C45.h */

#ifndef __C45_h__
#define __C45_h__

//#include <iostream.h>
//#include <cassert>
//#include <fstream.h>
//#include "string.h"
#include <cstring>//
//#include <cstdio>


//#include "defns.h"// C4.5//
//#include "types.h"//


#include "stats.cpp"//
#include "prune.cpp"//
#include "getnames.cpp"//
#include "getdata.cpp"//
#include "besttree.cpp"//
#include "classify.cpp"//


//using namespace UTILS;


namespace BIOS
{

  /************************/
  /* C45 DEFINITION */
  /************************/


  /**
          @memo C45 
   
  	@doc
   
      @author Maria Mar Abad Grau
  	@version 1.0
	
		LocalEntropiaPuntosRiesgo=-5,
	LocalRiesgoPuntosEntropia=-4,	
	LocalEntropiaPuntosEntropia=-3, //C45
	LocalRiesgoPuntosRiesgo=-2,
    LocalMitadEntropia=-1,
	LocalMitadRiesgo=0,
	
  */

class C45: public Classifier
  {

  
bool discretized;

    /* PUBLIC FUNCTIONS (INTERFACE) */

int classPosition;

void freeNode(TreeC45 Node);

  public:

 C45();

    C45(char* texto, int currentClassPosition, VerbosityClass *verbosity);

    C45(floatMLSample* sample, int currentClassPosition, floatList* parameterList,  DiscMode discMod, VerbosityClass *verbosity, LossFunction* lossFunction);
    
     C45(floatMLSample* sample, int currentClassPosition, floatList* parameterList, VerbosityClass* verbosity, LossFunction* lossFunction);
    
    void set(char filename[256], floatMLSample* sample, floatList* algorithm);
    
    void set(char filename[256], int currentClassPosition, int criterion);
 

//    void extractDistancesVector(){};

    ~C45();

    double* getClassFrequencies(floatList* inputPattern);



  };  // End of class C45
};  // Fin del Namespace

#endif

/* Fin Fichero: C45.h */
