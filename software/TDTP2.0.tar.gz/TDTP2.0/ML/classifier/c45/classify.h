#ifndef __classify_h__
#define __classify_h__

#include <iostream>//
#include <fstream>//                                                    
#include <cstring>//
#include <cstdio>//
#include <cstdlib>//
#include <cmath>//

//#include "defns.h"// C4.5//
//#include "types.h"//
//#include "extern.h"//



namespace BIOS {
/*************************************************************************/// 
/*                                                              	 */// 
/*  Determine the class of a case description from a decision tree	 */// 
/*  --------------------------------------------------------------	 */// 
/*                                                              	 */// 
/*************************************************************************/// 
// 
// 
// 
float	*ClassSum=NULL;		/* ClassSum[c] = total weight of class c */// 
// 
// 
// 
/*************************************************************************/// 
/*                                                              	 */// 
/*  Classify a case description using the given subtree by adjusting	 */// 
/*  the value ClassSum for each class					 */// 
/*                                                              	 */// 
/*************************************************************************/// 
// 
// 
    void Classify(Description CaseDesc, TreeC45 T, float Weight);

// 
/*************************************************************************/// 
/*                                                              	 */// 
/*  Categorize a case description using the given decision tree		 */// 
/*                                                              	 */// 
/*************************************************************************/// 
// 
// 
ClassNo Category(Description CaseDesc, TreeC45 DecisionTree); // 
double* getClassFrequenciesInC45(Description CaseDesc, TreeC45 DecisionTree); 

// 
}
#endif
