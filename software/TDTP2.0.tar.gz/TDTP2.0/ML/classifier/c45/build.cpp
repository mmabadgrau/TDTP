/* File: build.cpp */


#ifndef __build_cpp__
#define __build_cpp__


#include "build.h"// //



//using namespace UTILS;


namespace BIOS {
	/*************************************************************************/// 
/*								 	 		 	*/// 
/*    Central tree-forming algorithm incorporating all criteria  	 */// 
/*    ---------------------------------------------------------	 	 */// 
/*								 	 */// 
/*************************************************************************/// 
// 

// 
// 
/*************************************************************************/// 
/*								 	 */// 
/*		Allocate space for tree tables			 	 */// 
/*								 	 */// 
/*************************************************************************/// 
// 
// 
void   InitialiseTreeData()// 
/*  ------------------  */// 
{ // 
    DiscrValue v;// 
    AttributeC45 a;// 
    Tested	= (char *) calloc(MaxAtt+1, sizeof(char));
    Gain	= (float *) calloc(MaxAtt+1, sizeof(float));
    Info	= (float *) calloc(MaxAtt+1, sizeof(float));
    Bar		= (float *) calloc(MaxAtt+1, sizeof(float));
    EmpRisk     = (float *) calloc(MaxAtt+1, sizeof(float));
    Subsets = (short *) calloc(MaxAtt+1, sizeof(short));//
    SplitGain = (float *) calloc(MaxItem+1, sizeof(float));//
    SplitInfo = (float *) calloc(MaxItem+1, sizeof(float));//
    SplitEmpRisk = (float *) calloc(MaxItem+1, sizeof(float));//
    Weight = (ItemCount *) calloc(MaxItem+1, sizeof(ItemCount));//


    Subset = (Setc45 **) calloc(MaxAtt+1, sizeof(Setc45 *));
    ForEach(a, 0, MaxAtt)
    {
        if ( MaxAttVal[a] )//   si es un atributo discreto
	{
	    Subset[a]  = (Setc45 *) calloc(MaxDiscrVal+1, sizeof(Setc45));
	    ForEach(v, 0, MaxAttVal[a])// 
	    {
		Subset[a][v] = (Setc45) malloc((MaxAttVal[a]>>3) + 1);
	    }
	}
    }
    Freq  = (ItemCount **) calloc(MaxDiscrVal+1, sizeof(ItemCount *));// 
    ForEach(v, 0, MaxDiscrVal)// 
    {// 
	Freq[v]  = (ItemCount *) calloc(MaxClass+1, sizeof(ItemCount));// 
    }// 
// 
    ValFreq = (ItemCount *) calloc(MaxDiscrVal+1, sizeof(ItemCount));// 
    ClassFreq = (ItemCount *) calloc(MaxClass+1, sizeof(ItemCount));//
    ContFreq = (ItemCount *) calloc(MaxClass+1, sizeof(ItemCount));// 
    Slice1 = (ItemCount *) calloc(MaxClass+2, sizeof(ItemCount));// 
    Slice2 = (ItemCount *) calloc(MaxClass+2, sizeof(ItemCount));// 
    UnknownRate = (float *) calloc(MaxAtt+1, sizeof(float));// 
// 
    /*  Check whether all attributes have many discrete values  */// 
// 
    MultiVal = true;// 
    if ( ! SUBSET )// 
    {// 
	for ( a = 0 ; MultiVal && a <= MaxAtt ; a++ )// 
	{// 
	    if ( SpecialStatus[a] != IGNORE )// 
	    {// 
		MultiVal = MaxAttVal[a] >= 0.3 * (MaxItem + 1);// 
	    }// 
	}// 
    }// 
}// 
// 
// 
//
/*************************************************************************/// 
/*								 	 */// 
/*		Initialise the weight of each item		 	 */// 
/*								 	 */// 
/*************************************************************************/// 
// 
// 
void    InitialiseWeights()// 

/*  -----------------  */// 
{
    ItemNo i; 

    ForEach(i, 0, MaxItem) 
    {
        Weight[i] = 1.0; 
    }
}
// 
// 
// 
/*************************************************************************/// 
/*								 	 */// 
/*  Build a decision tree for the cases Fp through Lp:		 	 */// 
/*								 	 */// 
/*  - if all cases are of the same class, the tree is a leaf and so	 */// 
/*      the leaf is returned labelled with this class		 	 */// 
/*								 	 */// 
/*  - for each attribute, calculate the potential information provided 	 */// 
/*	by a test on the attribute (based on the probabilities of each	 */// 
/*	case having a particular value for the attribute), and the gain	 */// 
/*	in information that would result from a test on the attribute	 */// 
/*	(based on the probabilities of each case with a particular	 */// 
/*	value for the attribute being of a particular class)		 */// 
/*								 	 */// 
/*  - on the basis of these figures, and depending on the current	 */// 
/*	selection criterion, find the best attribute to branch on. 	 */// 
/*	Note:  this version will not allow a split on an attribute	 */// 
/*	unless two or more subsets have at least MINOBJS items. 	 */// 
/*								 	 */// 
/*  - try branching and test whether better than forming a leaf	 	 */// 
/*								 	 */// 
/*************************************************************************/// 
// 
// 
TreeC45 FormTree(ItemNo Fp, ItemNo Lp, short int criterion)// 
/*   ---------  */// 
{ //


    char a;
    ItemNo i, Kp, Ep;
	ItemNo Group(DiscrValue, ItemNo, ItemNo, TreeC45);// 
    ItemCount Cases, maxval, NoBestClass, KnownCases, TotalItems;
	ItemCount CountItems (ItemNo, ItemNo);// 
    float Factor, margen, BestVal, LowestRisk, OldRisk, Val, AvGain=0, AvRisk=0;
	float Worth(float, float, float);// Worth est  en info
    AttributeC45 Att, BestAtt, Possible=0;// 
    ClassNo c, BestClass;// 
    TreeC45 Node;
	TreeC45 Leaf(ItemCount*, ClassNo, ItemCount, ItemCount);// 
    DiscrValue v;// 
    Boolean PrevAllKnown;// 
//
//    *OldRisk=(float)maxreal;
    Cases = CountItems(Fp, Lp);//
// 
    /*  Generate the class frequency distribution  */// 
// 
    ForEach(c, 0, MaxClass)// 
    {// 
	ClassFreq[c] = 0;// 
    }// 
    ForEach(i, Fp, Lp)// 
    { // 
	ClassFreq[ Class(Item[i]) ] += Weight[i];// 
    } // 
// 
    /*  Find the most frequent class  */// 
// 
    BestClass = 0;// 
    ForEach(c, 0, MaxClass)// 
    {// 
	if ( ClassFreq[c] > ClassFreq[BestClass] )// 
	{// 
	    BestClass = c;// 
	}// 
    }// 
    NoBestClass = ClassFreq[BestClass];// 
// 
    Node = Leaf(ClassFreq, BestClass, Cases, Cases - NoBestClass);// 
// 
    /*  If all cases are of the same class or there are not enough// 
	cases to divide, the tree is a leaf  */// 
// 
//    if ((criterion==-5)||(criterion==-3)||(criterion==-1)||(criterion==1)) //
    if ( NoBestClass == Cases  || Cases < 2 * MINOBJS )//
    { // 
	return Node;// 
    } // 
// 
    Verbosity(1)// 
    	printf("\n%d items, total weight %.1f\n", Lp - Fp + 1, Cases);// 
// 
    /*  For each available attribute, find the information and gain  */// 
// 
    ForEach(Att, 0, MaxAtt) //
    { // 
	Gain[Att] = -Epsilon;// 
        EmpRisk[Att] = (float)maxreal; //
//
	if ( SpecialStatus[Att] == IGNORE ) continue;// 
// 
        if (MaxAttVal[Att] ) // || (criterion==1)) // 
	{// 
	    /*  discrete valued attribute  */// 
// 
	    if ( SUBSET && MaxAttVal[Att] > 2 )// 
	    {// 
                EvalSubset(Att, Fp, Lp, Cases, criterion);// en subset.h
	    }// 
	    else// 
            if ( ! Tested[Att] )//
                EvalDiscreteAtt(Att, Fp, Lp, Cases, criterion);//  en discr.h
	}// 
	else// 
	{ // 
	    /*  continuous attribute  */// 
// 
            EvalContinuousAtt(Att, Fp, Lp, criterion);//    en contin.h
//           cout << "risk att " << Att << ": " << EmpRisk[Att] <<", Fp: " << Fp <<", Lp: " <<Lp <<", criterion: " << criterion;
	} //
// 
	/*  Update average gain, excluding attributes with very many values  */// 
// 
	if ( Gain[Att] > -Epsilon &&// 
	     ( MultiVal || MaxAttVal[Att] < 0.3 * (MaxItem + 1) ) )// 
// quita aquellos atributos que sean casi llaves (unicos)
	{//
	    Possible++;// 
	    AvGain += Gain[Att];//
    //        AvRisk += EmpRisk[Att];// 
	}// 
    } // 
// 
    /*  Find the best attribute according to the given criterion  */// 
//
   OldRisk=Cases-NoBestClass;
   margen = (float)2*((float)Log (MaxClass)-Log (0.1))/(float)Cases; //
   OldRisk = OldRisk+(margen/(float)2)*((float)1+sqrt((float)1+((float)4*(OldRisk)/margen)));


    if (criterion==-5 || criterion==-3 || criterion==-1 || criterion==1 ) // // stop Fayyad o ya discretizados (o discretos)
    BestVal = -Epsilon;// 
    else //
    BestVal= OldRisk;//
    BestAtt = None;//
    AvGain  = ( Possible ? AvGain / Possible : 1E6 );//
  //  AvRisk  = ( Possible ? AvRisk / Possible : 0 );// 

// 
    Verbosity(2)// 
    {// 
	if ( AvGain < 1E6 ) printf("\taverage gain %.3f\n", AvGain);// 
   

//if (AvRisk > 0.0) printf ("\taverage risk %.3f\n", AvRisk);//
 }// 
//

    ForEach(Att, 0, MaxAtt) //

    { // 
    if (((criterion==-5)||(criterion==-3)||(criterion==-1) // algoritmo stop fayyad corte varios
     ||(criterion==1)  // o ya discretizados o discretos
    )) 
    //   || ( MaxAttVal[BestAtt] ))// es discreto, igual que criterion=1
      {
	if ( Gain[Att] > -Epsilon )//
	{ // 
            Val = Worth(Info[Att], Gain[Att], AvGain);// en info.h
	    if ( Val > BestVal ) // 
	    { // 
	        BestAtt  = Att; //
                //cout <<"Mejor: " << Att << "valor: " << Val;
//                cin >> a;
                BestVal = Val;// 
	    } // 
	} //
      }
    else //    algoritmo stop SRM puntos segun varios criterios
     {
      Val=EmpRisk[Att];
     if ( Val < (BestVal) )//

	    { // 
	        BestAtt  = Att; //
//                cout <<"Mejor: " << Att << "valor: " << Val;
//                cin >> a;
                BestVal = Val;// 
	    } //
      }
      }

//
    /*  Decide whether to branch or not  */ // 
// 
    if ( BestAtt != None )// 
    { //
        Verbosity(1)// 
	{// 
	    printf("\tbest attribute %s", AttName[BestAtt]);// 
	    if ( ! MaxAttVal[BestAtt] )// 
	    {// 
		printf(" cut %.3f", Bar[BestAtt]);// 
	    }// 
          //  printf(" inf %.3f gain %.3f val %.3f\n",// 
          //         Info[BestAtt], Gain[BestAtt], BestVal);//
            printf(" risk %.3f oldrisk %.3f val %.3f\n",// 
                   BestVal, OldRisk);// 

	}	// 
// 
	/*  Build a node of the selected test  */// 
// 
        if ( MaxAttVal[BestAtt] )// 
	{// 
	    /*  Discrete valued attribute  */// 
// 
	    if ( SUBSET && MaxAttVal[BestAtt] > 2 )// 
	    {// 
	        SubsetTest(Node, BestAtt);// 
	    }// 
	    else// 
	    {// 
	        DiscreteTest(Node, BestAtt);// 
	    }// 
	}// 
	else// 
	{ // 
	    /*  Continuous attribute  */// 
// 
	    ContinTest(Node, BestAtt);// 
	} // 
// 
	/*  Remove unknown attribute values  */// 
// 
	PrevAllKnown = AllKnown;// 
// 
	Kp = Group(0, Fp, Lp, Node) + 1;// 
	if ( Kp != Fp ) AllKnown = false;// 
	KnownCases = Cases - CountItems(Fp, Kp-1);// 
	UnknownRate[BestAtt] = (Cases - KnownCases) / (Cases + 0.001);// 
// 
	Verbosity(1)// 
	{// 
	    if ( UnknownRate[BestAtt] > 0 )// 
	    {// 
		printf("\tunknown rate for %s = %.3f\n",// 
		       AttName[BestAtt], UnknownRate[BestAtt]);// 
	    }// 
	}// 
// 
	/*  Recursive divide and conquer  */// 
// 
	++Tested[BestAtt];// 
// 
	Ep = Kp - 1;// 
	Node->Errors = 0;// 
// 
	ForEach(v, 1, Node->Forks)// 
	{// 
	    Ep = Group(v, Kp, Lp, Node);// 
// 
	    if ( Kp <= Ep )// 
	    {// 
		Factor = CountItems(Kp, Ep) / KnownCases;// 
// 
		ForEach(i, Fp, Kp-1)// 
		{// 
		    Weight[i] *= Factor;// 
		}// 
//
                Node->Branch[v] = FormTree(Fp, Ep, criterion);//
		Node->Errors += Node->Branch[v]->Errors;// 
// 
		Group(0, Fp, Ep, Node);// 
		ForEach(i, Fp, Kp-1)// 
		{// 
		    Weight[i] /= Factor;// 
		}// 
            }// fin if Kp<Ep
	    else// 
	    {// 
		Node->Branch[v] = Leaf(Node->ClassDist, BestClass, 0.0, 0.0);// 
	    }// 
        }// fin para cada rama
// 
	--Tested[BestAtt];// 
	AllKnown = PrevAllKnown;// 
// 
	/*  See whether we would have been no worse off with a leaf  */// 
// 

    if ((criterion==-5)||(criterion==-3)||(criterion==-1)||(criterion==1)  || (MaxAttVal[BestAtt])) //
    {
        if ( Node->Errors >= Cases - NoBestClass - Epsilon )//
	{ //
	    Verbosity(1)// 
		printf("Collapse tree for %d items to leaf %s\n",// 
	                Lp - Fp + 1, ClassName[BestClass]);// 
// 

	    Node->NodeType = 0;// 
         }
  }
/*
  // se quita porque en variables continuas N_1 es (casos-1) y entonces en
 // discretas y en la situacin actual  (N_0)   es 1
  else // si SRM y atributo elegido es continuo
  {
   if (EmpRisk[BestAtt] >= OldRisk)          

	{ //
	    Verbosity(1)// 
		printf("Collapse tree for %d items to leaf %s\n",// 
	                Lp - Fp + 1, ClassName[BestClass]);// 
// 

	    Node->NodeType = 0;// 
	} //
   } //
*/
  }  // fin si hay un atributo elegido
    else// 
    { // 
	Verbosity(1)// 
	    printf("\tno sensible splits  %.1f/%.1f\n",// 
		   Cases, Cases - NoBestClass);// 
    } // 


//


    return Node; //
} // 
// 
// 
// 
/*************************************************************************/// 
/*								 	 */// 
/*  Group together the items corresponding to branch V of a test 	 */// 
/*  and return the index of the last such			 	 */// 
/*								 	 */// 
/*  Note: if V equals zero, group the unknown values		 	 */// 
/*								 	 */// 
/*************************************************************************/// 
// 
// 
ItemNo Group(DiscrValue V, ItemNo Fp, ItemNo Lp, TreeC45 TestNode)// 
/*     -----  */// 
{// 
    ItemNo i;// 
    AttributeC45 Att;// 
    float Thresh;// 
    Setc45 SS;// 
    void Swap(ItemNo, ItemNo);// 
// 
    Att = TestNode->Tested;// 
// 
    if ( V )// 
    {// 
	/*  Group items on the value of attribute Att, and depending// 
	    on the type of branch  */// 
// 
	switch ( TestNode->NodeType )// 
	{// 
	    case BrDiscr:// 
// 
		ForEach(i, Fp, Lp)// 
		{// 
		    if ( DVal(Item[i], Att) == V ) Swap(Fp++, i);// 
		}// 
		break;// 
// 
	    case ThreshContin:// 
// 
		Thresh = TestNode->Cut;// 
		ForEach(i, Fp, Lp)// 
		{// 
		    if ( (CVal(Item[i], Att) <= Thresh) == (V == 1) ) Swap(Fp++, i);// 
		}// 
		break;// 
// 
	    case BrSubset:// 
// 
		SS = TestNode->Subset[V];// 
		ForEach(i, Fp, Lp)// 
		{// 
		    if ( In(DVal(Item[i], Att), SS) ) Swap(Fp++, i);// 
		}// 
		break;// 
	}// 
    }// 
    else// 
    {// 
	/*  Group together unknown values  */// 
// 
	switch ( TestNode->NodeType )// 
	{// 
	    case BrDiscr:// 
	    case BrSubset:// 
// 
		ForEach(i, Fp, Lp)// 
		{// 
		    if ( ! DVal(Item[i], Att) ) Swap(Fp++, i);// 
		}// 
		break;// 
// 
	    case ThreshContin:// 
// 
		ForEach(i, Fp, Lp)// 
		{// 
		    if ( CVal(Item[i], Att) == Unknown ) Swap(Fp++, i);// 
		}// 
		break;// 
	}// 
    }// 
// 
    return Fp - 1;// 
}// 
// 
// 
// 
/*************************************************************************/// 
/*								 	 */// 
/*	Return the total weight of items from Fp to Lp		 	 */// 
/*								 	 */// 
/*************************************************************************/// 
// 
// 
ItemCount CountItems(ItemNo Fp, ItemNo Lp)// 
/*        ----------  */// 
{// 
    register ItemCount Sum=0.0, *Wt, *LWt;// 
// 
    if ( AllKnown ) return Lp - Fp + 1;// 
// 
    for ( Wt = Weight + Fp, LWt = Weight + Lp ; Wt <= LWt ; )// 
    {// 
	Sum += *Wt++;// 
    }// 
// 
    return Sum;// 
}// 
// 
// 
// 
/*************************************************************************/// 
/*                                                               	 */// 
/*		Exchange items at a and b			 	 */// 
/*									 */// 
/*************************************************************************/// 
// 
// 
void Swap(ItemNo a, ItemNo b)// 
/*   ----  */// 
{// 
    register Description Hold;// 
    register ItemCount HoldW;// 
// 
    Hold = Item[a];// 
    Item[a] = Item[b];// 
    Item[b] = Hold;// 
// 
    HoldW = Weight[a];// 
    Weight[a] = Weight[b];// 
    Weight[b] = HoldW;// 
}// 
// 
}
#endif
