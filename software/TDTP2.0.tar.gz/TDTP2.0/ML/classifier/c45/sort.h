#ifndef __sort_h__
#define __sort_h__

#include <iostream>//
#include <fstream>//                                                    
#include <cstring>//
#include <cstdio>//
#include <cstdlib>//
#include <cmath>//

#include "defns.h"// C4.5//
#include "types.h"//
#include "extern.h"//


namespace BIOS {
/*************************************************************************/// 
/*									 */// 
/*	Sorting utilities						 */// 
/*	-----------------						 */// 
/*									 */// 
/*************************************************************************/// 
// 
// 
// 
// 
// 
/*************************************************************************/// 
/*									 */// 
/*	Sort items from Fp to Lp on attribute a				 */// 
/*									 */// 
/*************************************************************************/// 
// 
// 
    void Quicksort(ItemNo Fp, ItemNo Lp, AttributeC45 Att, void (*Exchange)//
    (register ItemNo, register ItemNo));

}
#endif

