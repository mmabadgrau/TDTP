#ifndef __trees_h__
#define __trees_h__

#include <iostream>//
#include <fstream>//                                                    
#include <cstring>//
#include <cstdio>//
#include <cstdlib>//
#include <cmath>//


//#include "../../commonc++/basic.h"// C4.5//

//#include "defns.h"// C4.5//
//#include "types.h"//
#include "info.cpp"//

namespace BIOS {


/*************************************************************************/// 
/*									 */// 
/*	Routines for displaying, building, saving and restoring trees	 */// 
/*	-------------------------------------------------------------	 */// 
/*									 */// 
/*************************************************************************/// 
// 
// 
// 
// 
#define	Tab		(char*)"|   "// 
#define	TabSize		4// 
#define	Width		80	/* approx max width of printed trees */// 
void ShowBranch(short, TreeC45, DiscrValue);// 
// 
	/*  If lines look like getting too long while a tree is being// 
	    printed, subtrees are broken off and printed separately after// 
	    the main tree is finished	 */// 
// 
short	Subtree;		/* highest subtree to be printed */// 
TreeC45	Subdef[100];		/* pointers to subtrees */// 
// 
FILE	*TRf = 0;//, *fopen(), *fopen(char*, char*);	/* file pointer for tree i/o */// 
char	Fn[500];		/* file name */// 
// 
 
    void Indent(short Sh, String Mark);// 

    void Show(TreeC45 T, short Sh);

    void ShowBranch(short Sh, TreeC45 T, DiscrValue v); 

    void PrintTree(TreeC45 T);// 

    void StreamOut(String s, int n); 

    void OutTree(TreeC45 T);

    void SaveDiscreteNames();

    void SaveTree(TreeC45 T, String Extension);

    void RecoverDiscreteNames();

TreeC45 GetTree(String Extension);

TreeC45 InTree();

    void ReleaseTree(TreeC45 Node);

TreeC45 Leaf(ItemCount *ClassFreq, ClassNo NodeClass, ItemCount Cases, ItemCount Errors);

    void Sprout(TreeC45 Node, DiscrValue Branches);
    int TreeSize(TreeC45 Node);

TreeC45 CopyTree(TreeC45 T);


} 
#endif

