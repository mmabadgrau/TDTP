#ifndef __stats_h__
#define __stats_h__

#include <iostream>//
#include <fstream>//                                                    
#include <cstring>//
#include <cstdio>//
#include <cstdlib>//
#include <cmath>//

#include "defns.h"// C4.5//
#include "types.h"//
#include "extern.h"//

 


namespace BIOS {
/*************************************************************************/// 
/*									 */// 
/*  Statistical routines for C4.5					 */// 
/*  -----------------------------					 */// 
/*									 */// 
/*************************************************************************/// 
// 
// 
//                                                                        // 
/*************************************************************************/// 
/*									 */// 
/*  Compute the additional errors if the error rate increases to the	 */// 
/*  upper limit of the confidence level.  The coefficient is the	 */// 
/*  square of the number of standard deviations corresponding to the	 */// 
/*  selected confidence level.  (Taken from Documenta Geigy Scientific	 */// 
/*  Tables (Sixth Edition), p185 (with modifications).)			 */// 
/*									 */// 
/*************************************************************************/// 
// 
// 
float Val[] = {  0,  0.001, 0.005, 0.01, 0.05, 0.10, 0.20, 0.40, 1.00},// 
      Dev[] = {4.0,  3.09,  2.58,  2.33, 1.65, 1.28, 0.84, 0.25, 0.00};// 
// 
// 
float AddErrs(ItemCount N, ItemCount e);

}
#endif

