#ifndef __getdata_h__
#define __getdata_h__

#include <iostream>//
#include <fstream>//                                                    
#include <cstring>//
#include <cstdio>//
#include <cstdlib>//
#include <cmath>//

//#include "defns.h"// C4.5//
//#include "types.h"//
//#include "extern.h"//
//#include "buildex.i"//
 


namespace BIOS {
/*************************************************************************/ //
/*									 */ //
/*	Get case descriptions from data file				 */ //
/*	--------------------------------------				 */ //
/*									 */ //
/*************************************************************************/ //
 //
 //
 //
#define Inc 2048 //

void GetData(String FileName);

Description GetDescription(FILE *Df);

}
#endif
