/* File: build.h */


#ifndef __build_h__
#define __build_h__

//#include "../../commonc++/basic.h"// C4.5//

//#include "defns.h"// C4.5//
//#include "types.h"//
#include "subset.cpp"//
#include "discr.cpp"//
#include "contin.cpp"//
#include "trees.cpp"//
//using namespace UTILS;


namespace BIOS {
	/*************************************************************************/// 
/*								 	 		 	*/// 
/*    Central tree-forming algorithm incorporating all criteria  	 */// 
/*    ---------------------------------------------------------	 	 */// 
/*								 	 */// 
/*************************************************************************/// 
// 
// 
// 
//
//SUBSET esta  a false (en c4.5.h)
ItemCount// 
	*Weight,	/* Weight[i]  = current fraction of item i */// 
	**Freq,		/* Freq[x][c] = no. items of class c with outcome x */// 
	*ValFreq,	/* ValFreq[x]   = no. items with outcome x */// 
        *ClassFreq,     /* ClassFreq[c] = no. items of class c *///
        *ContFreq;
// 
float// 
	*Gain,		/* Gain[a] = info gain by split on att a */// 
	*Info,		/* Info[a] = potential info of split on att a */// 
	*Bar,		/* Bar[a]  = best threshold for contin att a */// 
        *EmpRisk,
        *UnknownRate;	/* UnknownRate[a] = current unknown rate for att a *///
// 
Boolean// 
	*Tested,	/* Tested[a] set if att a has already been tested */// 
	MultiVal;	/* true when all atts have many values */// 
// 
// 
	/*  External variables initialised here  */// 
// 
extern float// 
	*SplitGain,	/* SplitGain[i] = gain with att value of item i as threshold */// 
        *SplitInfo,     /* SplitInfo[i] = potential info ditto */// 
        *SplitEmpRisk; 
//
extern ItemCount// 
	*Slice1,	/* Slice1[c]    = saved values of Freq[x][c] in subset.c */// 
	*Slice2;	/* Slice2[c]    = saved values of Freq[y][c] */// 
// 
extern Setc45// 
	**Subset;	/* Subset[a][s] = subset s for att a */// 
// 
extern short// 
	*Subsets;	/* Subsets[a] = no. subsets for att a */// 
// 
// 
// 
/*************************************************************************/// 
/*								 	 */// 
/*		Allocate space for tree tables			 	 */// 
/*								 	 */// 
/*************************************************************************/// 
// 
// 
void   InitialiseTreeData();

//
/*************************************************************************/// 
/*								 	 */// 
/*		Initialise the weight of each item		 	 */// 
/*								 	 */// 
/*************************************************************************/// 
// 
// 
void    InitialiseWeights(); 


// 
TreeC45 FormTree(ItemNo Fp, ItemNo Lp, short int criterium);

// 
/*************************************************************************/// 
/*								 	 */// 
/*  Group together the items corresponding to branch V of a test 	 */// 
/*  and return the index of the last such			 	 */// 
/*								 	 */// 
/*  Note: if V equals zero, group the unknown values		 	 */// 
/*								 	 */// 
/*************************************************************************/// 
// 
// 
ItemNo Group(DiscrValue V, ItemNo Fp, ItemNo Lp, TreeC45 TestNode);

// 
/*************************************************************************/// 
/*								 	 */// 
/*	Return the total weight of items from Fp to Lp		 	 */// 
/*								 	 */// 
/*************************************************************************/// 
// 
// 
ItemCount CountItems(ItemNo Fp, ItemNo Lp);

// 
// 
// 
/*************************************************************************/// 
/*                                                               	 */// 
/*		Exchange items at a and b			 	 */// 
/*									 */// 
/*************************************************************************/// 
// 
// 
void Swap(ItemNo a, ItemNo b); 

// 
}
#endif
