/* File: ClassificationFinalResult.h */

#ifndef __ClassificationFinalResults_h__
#define __ClassificationFinalResults_h__



//using namespace UTILS;


namespace BIOS
{

  class ClassificationFinalResults: public ClassificationResults
  {

   

  public:


/*________________________________________________________________________*/
/*
void getEuclideanDistance()
{
}
/*________________________________________________________________________*/

void GetMean (ClassificationResults** array, int size)
{
for (int i=1;i<=4;i++)
ClassificationResults::GetMean(array, size, i);
}


};
 


};  // Fin del Namespace

#endif

/* Fin Fichero: TestModeClass.h */
