#ifndef __FachadeClassifierknnC_h__ 
#define __FachadeClassifierknnC_h__ 



#include "KNN.cpp"
#endif
