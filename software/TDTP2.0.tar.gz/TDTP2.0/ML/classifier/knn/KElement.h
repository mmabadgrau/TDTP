/* File: KElement.h */

#ifndef __KElement_h__
#define __KElement_h__

#include<cstdio>//
#include<cstdlib>//
#include<cmath>//
#include<iostream>//
#include<iomanip>//
#include<fstream>//
#include "../../../commonc++/basic.h"

using namespace std;


namespace BIOS {

class KElement
{

struct KNode
 {
int clas;
int elementPos;
float distance;
 };

public: 

KNode kNode;

public:

KElement(){kNode.clas=-1; kNode.elementPos=-1; kNode.distance=-1;};
~KElement(){};

KElement* clone()
{
return new KElement(*this);
};

void SetClas(int clas) {kNode.clas=clas;};

void SetElementPos(int elementPos) {kNode.elementPos=elementPos;};

void SetDistance(float distance) {kNode.distance=distance;};

float getDistance() {return kNode.distance;}

int GetClas() {return kNode.clas;};

int getElementPos() {return kNode.elementPos;};

bool operator> (KElement & kelementTarget)
{
if (this->kNode.distance > kelementTarget.kNode.distance)
return true;
else return false; 
}
/*________________________________________________________*/

bool operator== (KElement & kelementTarget)
{
if (this->kNode.distance == kelementTarget.kNode.distance)
return true;
else return false; 
}
/*________________________________________________________*/

bool operator< (KElement & kelementTarget)
{
if (this->kNode.distance < kelementTarget.kNode.distance)
return true;
else return false; 
};
/*________________________________________________________*/


int size()
{
//cout <<"no sense";
return 0;
}

/*________________________________________________________*/

KElement* fromString (string source)
{
throw NonImplemented("KElement::fromString (string source)");
 };




};// end class

 /*______________________________________________________*/

     ostream& operator<<(ostream& out, KElement& p)
{
out << "[Class: " << p.GetClas();
out << ", Element pos: " << p.kNode.elementPos;
cout << ", distance: " << p.kNode.distance <<"] \n";
	return out;
};

typedef Vector<KElement*>::Class KElementVector;

}; 
 // Fin del Namespace

#endif

/* Fin Fichero: KElement.h */
