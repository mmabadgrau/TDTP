#ifndef __FachadeClassifier_h__ 
#define __FachadeClassifier_h__ 

#include "TestModeClass.h"

#include "ClassificationResults.h"
#include "ClassificationFinalResults.h"

//#include "../BN/GBN.cpp"
#include "Classifier.h"

#include "knn/FachadeClassifierknn.h"
#include "c45/FachadeClassifierc45.h"
#include "BN/FachadeClassifierBN.h"
#include "AlgTypeClass.h"

#include "MIDistances.h"
//#include "Classifier.cpp"
#include "CompleteMissing.h"
#include "ClassifierTest.h"
#include "EM/FachadeClassifierEM.h"

#endif
