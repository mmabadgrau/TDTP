#ifndef __FachadeuserInterface_h__ 
#define __FachadeUserInterface_h__ 




#include "VerbosityClass.h"
#include "InputTUI.h"



//#include "sample/FachadeSample.h"
//#include "BN/FachadeBN.h"
// end namespace

//#include "Front.cpp"
#endif
