/***************************************************************************
 *   Copyright (C) 2005 by M. Mar Abad Grau 				   *
 *   mabad@ugr.es  						           *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/


#ifndef __prueba_cpp__
#define __prueba_cpp__


#include "FachadeML.h"




using namespace BIOS;

int main(int argc, char *argv[])
{
/*
int total=1000;
int m=3;
double* probs=Initialize(m, (double)0.0);
int *counts=Initialize(m, 0);
probs[0]=0.3333;
probs[1]=0.3333;
Multinomial * md=new Multinomial(m, probs);
int results=md->getValues(total);
zap(md);
for (int i=0;i<total;i++)
 counts[results[i]]++;
for (int i=0;i<m;i++)
cout << "\n" counts[i];
*/
Multinomial* b;
int* freqs;

int m=3;
double* probs=Initialize(m, (double)0.0);
probs[0]=0;
probs[1]=0.6666;

for (int i=0;i<20;i++)
{
b=new Multinomial(1000,m, probs);
freqs=b->getFrequencies();
for (int j=0;j<m;j++)
cout <<" " << freqs[j];
cout <<"\n";
//for (int j=0;j<100;j++)
//cout <<" " << b->getNextValue();
//cout <<"\n";
zap(b);
}
};


#endif




